import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MultiusuarioService } from 'src/app/services/multiusuario.service';
import { NewMultiusuarioComponent } from '../dialogs/new-multiusuario/new-multiusuario.component';

@Component({
  selector: 'app-multiusuarios',
  templateUrl: './multiusuarios.component.html',
  styleUrls: ['./multiusuarios.component.css']
})
export class MultiusuariosComponent implements OnInit {

  users: any[] = [];
  totalPaginas: number;
  cantidad: number = 4;
  paginaActiva: number = 1;
  paginas: any[] = [];
  search: string = '';
  init: boolean = false;
  isChecked: boolean;
  timer: any;

  constructor(private wsMulti: MultiusuarioService,
    private dialog: MatDialog) { }

  ngOnInit(): void {
    this.getUsuarios(1, this.cantidad, this.search);
  }

  searchUser() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.timer =
        this.init = false;
      this.getUsuarios(1, this.cantidad, this.search);
    }, 500);
  }

  async getUsuarios(pagina: number = 1, cantidad, search: string = '') {
    this.users = [];
    this.wsMulti.getMultiUsuarios(pagina, cantidad, search).subscribe((data: any) => {
      console.log(data)
      if (!data.ok) {
        return;
      }
      this.users = data.data;
      if (this.init == false) {
        this.init = true;
        this.totalPaginas = Math.ceil(data.total / this.cantidad);
        console.log(this.totalPaginas)
        this.paginaActiva = 1;
        this.paginas = [];
      } else {
        return;
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if (i > 5) {
          return;
        }
        this.paginas.push(i);
      }
    });
  }

  async verPagina(pagina) {
    if (this.paginaActiva == pagina) {
      return;
    }
    this.paginaActiva = pagina;
    await this.getUsuarios(pagina, this.cantidad, this.search);
    if (this.totalPaginas <= 5) {
      return;
    }
    this.paginas = [];
    if (pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1) {
      for (let i = pagina - 2; i <= pagina + 2; i++) {
        this.paginas.push(i);
      }
    }
    if (pagina >= 3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1) {
      for (let i = pagina - 3; i <= pagina + 1; i++) {
        this.paginas.push(i);
      }
    }
    if (pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1) {
      for (let i = pagina - 1; i <= pagina + 3; i++) {
        this.paginas.push(i);
      }
    }

    if (pagina == this.totalPaginas && this.totalPaginas > 5) {
      for (let i = pagina - 4; i <= pagina; i++) {
        this.paginas.push(i);
      }
    }

    if (pagina == 1 && this.totalPaginas > 5) {
      for (let i = pagina; i <= pagina + 4; i++) {
        this.paginas.push(i);
      }
    }

  }

  newUsuario() {
    const dialogRef = this.dialog.open(NewMultiusuarioComponent, {
      width: '800px',
      data: {
        view: 'newUsuario',
      }
    });

    dialogRef.afterClosed().subscribe((data: any) => {
      if (data.usuario) {
        this.init = false;
        this.getUsuarios(this.paginaActiva, this.cantidad, this.search)
      }
    });
  }

  editUsuario(user: any) {
    const dialogRef = this.dialog.open(NewMultiusuarioComponent, {
      width: '800px',
      data: {
        view: 'editUsuario',
        user
      }
    });

    dialogRef.afterClosed().subscribe((data: any) => {
      if (data.usuario) {
        this.init = false;
        this.getUsuarios(this.paginaActiva, this.cantidad, this.search)
      }
    });
  }

  status(event, idusuario) {
    let activo = (event.checked) ? 1 : 0;
    this.wsMulti.status(idusuario, activo).subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      let i = this.users.findIndex(element => element.id_usuarioad == idusuario);
      this.users[i].activo = activo;
    })
  }

  borrar(idusuario) {
    this.wsMulti.borrar(idusuario).subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.init = false;
      this.getUsuarios(this.paginaActiva, this.cantidad, this.search)
    })
  }

}
