import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ServiciosService } from 'src/app/services/servicios.service';

@Component({
  selector: 'app-rastreo',
  templateUrl: './rastreo.component.html',
  styleUrls: ['./rastreo.component.css']
})
export class RastreoComponent implements OnInit {

  paqueterias:Array<any> = [];
  paqueteria:string = 'estafeta';
  tracking:string = '';
  rastreo:any;
  loading: boolean = false;
  isOk: boolean = false;

  constructor(private wsServicio: ServiciosService,
    private snackCtrl: MatSnackBar) { }

  ngOnInit(): void {
    this.getPaqueterias();
  }

  cambiarPaqueteria(paqueteria:string){
    this.paqueteria = paqueteria;
  }

  getPaqueterias(){
    this.wsServicio.getPaqueteriasAsociado().subscribe((data:any) => {
      if(!data.ok){ 
        return;
      } 
      this.paqueterias = data.data;
    })
  }
  
  getTracking(){
    if(this.tracking.trim() == ''){
      this.msgSnack('Se necesita un numero de rastreo');
      return;
    }
    this.loading = true;
    this.isOk = false;
    this.wsServicio.getTracking(this.paqueteria, this.tracking.trim()).subscribe((data:any) => {
      console.log(data);
      this.loading = false;
      if(!data.ok){
        this.msgSnack(data.message);
        return;
      }
      this.isOk = true;
      this.rastreo = data.data
    });
  }

  msgSnack(message:string){
    this.snackCtrl.open(message, 'Ok', {
      horizontalPosition: 'right',
      verticalPosition: 'top',
      duration: 4000
    })
  }

}
