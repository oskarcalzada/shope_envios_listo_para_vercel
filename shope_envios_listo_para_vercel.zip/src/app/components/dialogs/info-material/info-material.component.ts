import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-info-material',
  templateUrl: './info-material.component.html',
  styleUrls: ['./info-material.component.css']
})
export class InfoMaterialComponent implements OnInit {

  constructor(private dialogRef:MatDialogRef<InfoMaterialComponent>,
    @Inject(MAT_DIALOG_DATA) public data:any) { }

  ngOnInit(): void {
  }

  cerrar(){
    this.dialogRef.close();
  }

}
