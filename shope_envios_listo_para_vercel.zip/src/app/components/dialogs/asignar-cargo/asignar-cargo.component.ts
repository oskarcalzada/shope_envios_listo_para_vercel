import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { CotizadorService } from 'src/app/services/cotizador.service';
import { ServiciosService } from 'src/app/services/servicios.service';

@Component({
  selector: 'app-asignar-cargo',
  templateUrl: './asignar-cargo.component.html',
  styleUrls: ['./asignar-cargo.component.css']
})
export class AsignarCargoComponent implements OnInit {

  forma: FormGroup;
  cargos: Array<any> = [];
  loading: boolean = false;
  filteredOptions!: Observable<any[]>;
  idasociado!:number;
  msgError:string = '';
  msgOk:string = '';

  constructor(private wsServicio: ServiciosService,
    private wsCotizador:CotizadorService,
    private dialogRef: MatDialogRef<AsignarCargoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.forma = new FormGroup({
      'cargo': new FormControl('', Validators.required),
      'precio': new FormControl(''),
      'referencia': new FormControl('', Validators.required),
      'cantidad': new FormControl('', [Validators.required, Validators.min(1)])
    });
  }

  ngOnInit(): void {
    this.getCargos();
    this.filteredOptions = this.forma.get('cargo')!.valueChanges.pipe(
      startWith(''),
      map(value => typeof value === 'string' ? value : value.descripcion),
      map(descripcion => descripcion ? this._filter(descripcion) : this.cargos.slice())
    );
    this.forma.get('cargo')!.valueChanges.subscribe((value:any) => {
      console.log(value)
      if(!value?.id_servicio){
        this.forma.get('precio')!.setValue(0);
        return;
      }
      let cargo = this.cargos.find(element => element.id_servicio == value.id_servicio);
      this.forma.get('precio')!.setValue(cargo.precio);
    });
    this.idasociado = this.data.idasociado
  }

  getCargos() {
    this.loading = false;
    this.wsServicio.getAllCargos().subscribe((data: any) => {
      this.loading = true;
      if (!data.ok) {
        return;
      }
      this.cargos = data.data;
      console.log(this.cargos)
    });
  }

  asignar() {
    console.log(this.forma.value);
    let sendData = {
      cantidad: this.forma.value.cantidad,
      forma_pago: 1,
      id_servicio: this.forma.value.cargo.id_servicio,
      idasociado: this.idasociado,
      monto: this.forma.value.precio,
      status: 1,
      referencia: this.forma.value.referencia,
      tipo: 'CARGO'
    }
    this.msgOk = '';
    this.msgError = '';
    this.wsCotizador.nuevoCargoUser(sendData).subscribe((data:any) => {
      console.log(data);
      if(!data.ok){
        this.msgError = data.message;
        return;
      }
      this.msgOk = 'El cargo fue asignado correctamente'
      this.forma.reset();
    });
  }

  displayFn(cargo: any): string {
    return cargo && cargo.descripcion ? cargo.descripcion : '';
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.cargos.filter(cargo => cargo.descripcion.toLowerCase().includes(filterValue));
  }

}
