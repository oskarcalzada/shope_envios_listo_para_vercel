import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AsociadoService } from 'src/app/services/asociado.service';
import { CotizadorService } from 'src/app/services/cotizador.service';
import { CreditoService } from 'src/app/services/credito.service';

@Component({
  selector: 'app-comprar',
  templateUrl: './comprar.component.html',
  styleUrls: ['./comprar.component.css']
})
export class ComprarComponent implements OnInit {

  metodo: string = '1';
  saldo:number = 0;
  asociado:any;
  loading:boolean = false;

  constructor(private wsCotizador: CotizadorService,
    private wsCredito: CreditoService,
    private wsAsociado: AsociadoService,
    private dialogRef: MatDialogRef<ComprarComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
    this.getAsociado();
    this.getSaldo();
  }

  getAsociado(){
    this.loading = false;
    this.wsAsociado.getAsociadoClient().subscribe((data:any) => {
      this.loading = true;
      console.log(data)
      if(!data.ok){
        return;
      }
      this.asociado = data.data;
    });
  }
  
  validarSaldo(){
    this.getSaldo();
  }

  async getSaldo(){
    if(this.metodo == '1'){
      await new Promise((resolve) => {
        this.wsCotizador.getSaldo().subscribe((data:any) => {
          console.log(data)
          if(!data.ok){
            return;
          }
          this.saldo = data.data.disponible;
          resolve({ok: true});
        });
      });
    }
    if(this.metodo == '2'){
      this.wsCredito.getSaldoCredito().subscribe((data: any) => {
        if (!data.ok) {
          return;
        }
        if(data.data.activo == 0){
          this.saldo = 0;
          return;
        }
        this.saldo = data.data.disponible;
      });
    }
  }

  cerrar() {
    this.dialogRef.close({ok: false});
  }

  comprar() {
    this.data.forma_pago = this.metodo;
    this.wsCotizador.nuevoCargo(this.data).subscribe((data: any) => {
      console.log(data);
      if(!data.ok){
        this.dialogRef.close({ok: false, message: data.message, requerido: data.requerido});
      }
      this.dialogRef.close({ok: true, id_movimiento: data.data.id_movimiento});
    });
  }

}
