import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ServiciosService } from 'src/app/services/servicios.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-new-servicio',
  templateUrl: './new-servicio.component.html',
  styleUrls: ['./new-servicio.component.css']
})
export class NewServicioComponent implements OnInit {

  forma: FormGroup;
  matcher = new MyErrorStateMatcher();
  paqueterias!: any[];
  errorNuevo: boolean = false;
  errorMsg: string = '';

  constructor(private wsServicio: ServiciosService,
    public dialogRef: MatDialogRef<NewServicioComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.forma = new FormGroup({
      'paqueteria': new FormControl('', Validators.required),
      'tipo': new FormControl('', Validators.required),
      'peso': new FormControl('', [Validators.required, Validators.maxLength(3)]),
      'costo': new FormControl('', Validators.required),
      'precio': new FormControl('', Validators.required),
      'tiempo': new FormControl('', Validators.required)
    });

    // this.forma.valueChanges.subscribe((data:any) => {
    //   console.log(this.forma)
    // });

  }

  ngOnInit() {
    this.getPaqueterias();
  }

  getPaqueterias() {
    this.wsServicio.getPaqueterias().subscribe((data: any) => {
      console.log(data);
      if (!data.ok) {
        return
      }
      this.paqueterias = data.data;
    })
  }

  agregarServicio() {
    let paqueteria = this.forma.value.paqueteria;
    let tipo = this.forma.value.tipo;
    let peso = this.forma.value.peso;
    let sendData = {
      paqueteria,
      tipo,
      peso,
      costo: this.forma.value.costo,
      precio: this.forma.value.precio,
      descripcion: `GUIA ELEC ${(paqueteria == 'MINUTES') ? '99 MINUTOS' : paqueteria} ${peso} KG ${tipo}`,
      activo: "0",
      activo_generar: "0",
      tiempo: this.forma.value.tiempo
    }
    console.log(sendData);
    this.wsServicio.newServicio(sendData).subscribe((data: any) => {
      console.log(data);
      if (!data.ok) {
        this.errorNuevo = true;
        this.errorMsg = data.message;
        return;
      }
      this.dialogRef.close({ sendData });
    });
  }
}

