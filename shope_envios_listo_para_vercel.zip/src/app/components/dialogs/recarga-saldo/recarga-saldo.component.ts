import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CotizadorService } from 'src/app/services/cotizador.service';
import { PaymentService } from 'src/app/services/payment.service';
import { PaymentCard, PaymentCash } from '../../../interfaces/payment';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-recarga-saldo',
  templateUrl: './recarga-saldo.component.html',
  styleUrls: ['./recarga-saldo.component.css']
})
export class RecargaSaldoComponent implements OnInit {

  monto: number = 0;
  tipoPago: string = '1';
  msgError: string = '';
  msgSuccess: string = '';
  forma: FormGroup;
  formCard: FormGroup;
  formCash: FormGroup;
  loading: boolean = false;

  constructor(private wsCotizador: CotizadorService,
    private dialog: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private paymentService: PaymentService) {

    this.forma = new FormGroup({
      'monto': new FormControl('', [Validators.required, Validators.min(500)]),
      'tipoPago': new FormControl('2', Validators.required)
    });

    this.formCard = new FormGroup({
      amount: new FormControl('500', [Validators.required, Validators.min(500)]),
      holder_name: new FormControl('', Validators.required),
      card_number: new FormControl('', [Validators.required, Validators.maxLength(16), Validators.minLength(10)]),
      expiration_month: new FormControl('', [Validators.required, Validators.minLength(2)]),
      expiration_year: new FormControl('', [Validators.required, Validators.minLength(2)]),
      cvv: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(4)]),
    });

    this.formCash = new FormGroup({
      amount: new FormControl('500', [Validators.required, Validators.min(500)]),
    })
  }

  ngOnInit(): void {
  }

  cerrar() {
    this.dialog.close({ ok: false })
  }

  recargar() {
    let sendData = {
      forma_pago: this.data.metodo,
      cantidad: 1,
      monto: this.forma.value.monto,
      tipo: 'ABONO',
      id_servicio: 0,
      status: 0
    };
    this.msgError = '';
    this.msgSuccess = '';
    this.wsCotizador.nuevoCargo(sendData).subscribe((data: any) => {
      console.log(data);
      if (!data.ok) {
        this.msgError = data.message;
        return;
      }
      this.msgSuccess = `La solicitud se envio correctamente`;
      this.forma.get('monto').setValue(0);
      this.dialog.close({ ok: true });
    });
  }

  paymentCard() {
    const request: PaymentCard = {
      ...this.formCard.value,
      description: this.data.metodo == 1 ? 'Recarga de saldo' : 'Pago de credito'
    }
    this.msgError = '';
    this.loading = true;
    this.paymentService.paymentByCard(request).subscribe((data: any) => {
      this.loading = false;
      if (!data.ok) {
        this.msgError = data.message;
        return;
      }
      Swal.fire({
        title: 'El pago se acredito correctamente',
        icon: 'success',
        confirmButtonColor: '#2090f1',
        confirmButtonText: 'Aceptar',
        allowOutsideClick: false,
      });
      this.dialog.close({ ok: true })
    });
  }

  paymentCash() {
    const request: PaymentCash = {
      ...this.formCash.value,
      description: this.data.metodo == 1 ? 'Recarga de saldo' : 'Pago de credito'
    }
    this.msgError = '';
    this.loading = true;
    this.paymentService.paymentByCash(request).subscribe((data: any) => {
      this.loading = false;
      if (!data.ok) {
        this.msgError = data.message;
        return;
      }
      Swal.fire({
        title: 'La referencia de pago se creó correctamente',
        icon: 'success',
        confirmButtonColor: '#2090f1',
        confirmButtonText: 'Aceptar',
        allowOutsideClick: false,
        html: `
              <p>
                <a href="${data.data.link}" target="_blank">
                  <span class="text-center fw-bold">Imprimir referencia de pago</span>
                </a>
              </p>`
      });
      this.dialog.close({ ok: true });
    });
  }

}
