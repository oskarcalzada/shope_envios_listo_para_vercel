import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EnvioService } from 'src/app/services/envio.service';

@Component({
  selector: 'app-direccion',
  templateUrl: './direccion.component.html',
  styleUrls: ['./direccion.component.css']
})
export class DireccionComponent implements OnInit {

  keyword:string = '';
  direcciones:Array<any> = [];
  iddireccion:number = 0;

  constructor(private wsEnvio:EnvioService,
    public dialogRef: MatDialogRef<DireccionComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
  }

  buscar(){
    this.wsEnvio.getDireccion(this.keyword, this.data.paqueteria).subscribe((data:any) => {
      console.log(data);
      if(!data.ok){
        return;
      }
      this.direcciones = data.data;
    });
  }

  selDireccion(iddireccion:any){
    this.iddireccion = iddireccion;
  }

  usarDireccion(){
    let direccion = this.direcciones.find((element:any) => element.id_direccion == this.iddireccion);
    this.dialogRef.close({ok: true, direccion});
  }

  cerrar(){
    this.dialogRef.close({ok: false})
  }


}
