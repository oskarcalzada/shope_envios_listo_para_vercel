import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';
import { AsociadoService } from 'src/app/services/asociado.service';
import { FilesService } from 'src/app/services/files.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-api',
  templateUrl: './api.component.html',
  styleUrls: ['./api.component.css']
})
export class ApiComponent implements OnInit {

  msgToolTip:string = 'Haz clic para copiar';
  tokens:Array<any> = [];
  loading:boolean = false;
  info: any;

  constructor(private wsApi: ApiService,
    private wsAsociado: AsociadoService,
    private wsFile: FilesService) { }

  ngOnInit(): void {
    this.getTokens();
    this.getAsociado();
  }

  getAsociado() {
    this.wsAsociado.getAsociadoClient().subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.info = data.data;
      console.log(this.info)
    })
  }

  copiarToken(){
    this.msgToolTip = '¡Copiado!';
    setTimeout(() => {
       this.msgToolTip = 'Haz clic para copiar';
    }, 2000);
  }

  getTokens(){
    this.wsApi.getTokens().subscribe((data:any) => {
      this.loading = true;
      console.log(data);
      if(!data.ok){
        return;
      }
      this.tokens = data.data;
    });
  }

  status(id:number, status:number){
    console.log(id, status)
    this.wsApi.statusToken(status, id).subscribe((data:any) => {
      console.log(data)
      if(!data.ok){
        return;
      }
      let i = this.tokens.findIndex(element => element.id_token == id);
      this.tokens[i].activo = status;
    });
  }

  borrar(id:number){
    Swal.fire({
      title: '¿Deseas continuar?',
      text: "El token api sera borrado completamente",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Continuar',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        this.wsApi.borrarToken(id).subscribe((data:any) => {
          if(!data.ok){
            return;
          }
          let i = this.tokens.findIndex(element => element.id_token == id);
          this.tokens.splice(i, 1);
        });
      }
    })
    
  }

  generar(){
    this.wsApi.nuevoToken().subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      this.tokens.push(data.data);
    });
  }

  downloadPlugin(namePlugin: string){
    this.wsFile.getPlugin(namePlugin).subscribe((data:Blob) => {
      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'mdShopeEnvios.zip';
      a.click();
      console.log(data);
    });
  }

  downloadDoc(plugin: string){
    this.wsFile.getDocs(plugin);
  }

}
