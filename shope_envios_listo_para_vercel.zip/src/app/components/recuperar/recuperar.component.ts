import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { AsociadoService } from 'src/app/services/asociado.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-recuperar',
  templateUrl: './recuperar.component.html',
  styleUrls: ['./recuperar.component.css']
})
export class RecuperarComponent implements OnInit {
  
  matcher = new MyErrorStateMatcher();
  forma: FormGroup
  loading: boolean = false;
  msgEnvio: string = '';
  msgError: string = '';

  constructor(private wsAsociado: AsociadoService) { 
    this.forma = new FormGroup({
      'email': new FormControl('', [Validators.required, Validators.email])
    })
  }

  ngOnInit() {
  }

  enviar(){
    this.loading = true;
    this.msgEnvio = '';
    this.msgError = '';
    this.wsAsociado.recuperarPass(this.forma.value.email).subscribe((data:any) => {
      this.loading = false;
      if(!data.ok){
        this.msgError = data.message;
        return;
      }
      this.msgEnvio = 'Verifica el correo que enviamos para continuar recuperando tu cuenta'
      console.log('enviando')
    });

  }

}