import { MediaMatcher } from '@angular/cdk/layout';
import { Component, OnInit, ChangeDetectorRef, OnDestroy, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  mobileQuery: MediaQueryList;
  usuario: any;
  sidebar: boolean;
  private _mobileQueryListener: () => void;
  loadingNotifications: boolean = false;
  countNotifications:number = 0;
  hasNoActivos = false;
  noActivos: any[] = [];
  viewNoti:boolean = false;

  constructor(private router: Router,
    changeDetectorRef: ChangeDetectorRef, media: MediaMatcher,
    public wsUser: UserService,
    private userService: UserService) {
    let datos: any = JSON.parse(localStorage.getItem('user'));
    console.log(datos)
    this.usuario = datos;
    this.mobileQuery = media.matchMedia('(max-width: 980px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.wsUser.getUser().subscribe((data:any) => {
      if(!data.ok){
        return;
      }
    })
  }

  ngOnInit() {
    this.getNotifications();
  }

  @HostListener('document:click', ['$event'])
  clickout(event) {
    for(let i in event.path){
      if(event.path[i].className === undefined){
        continue;
      }
      if(event.path[i].className.includes('notifications')){
        return;
      }
    }
    if(event.target.getAttribute('data-id') == null){
      this.viewNoti = false;
      return;
    }

  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  salir() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.router.navigate(['dashboard/login']);
  }

  getNotifications(){
    this.loadingNotifications = true;
    this.userService.getNoActivos().subscribe((resp:any) => {
      this.loadingNotifications = false;
      if(!resp.ok){
        this.hasNoActivos = false;
        return;
      }
      this.hasNoActivos = true;
      this.noActivos = resp.data;
      console.log(resp);
    })
  }

  deleteNoti(index){
    this.noActivos.splice(index, 1);
  }

  openNoti(){
    this.viewNoti = !this.viewNoti
  }

}