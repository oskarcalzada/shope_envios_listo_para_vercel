import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ServiciosService } from 'src/app/services/servicios.service';
import { NewCargoComponent } from '../../dialogs/new-cargo/new-cargo.component';

@Component({
  selector: 'app-cargos',
  templateUrl: './cargos.component.html',
  styleUrls: ['./cargos.component.css']
})
export class CargosComponent implements OnInit {
  cargos: any[] = [];
  totalPaginas: number;
  cantidad: number = 4;
  paginaActiva: number = 1;
  paginas: any[] = [];
  search: string = '';
  init: boolean = false;
  loading: boolean = false;
  editar: boolean = false;
  carga: boolean = false;
  timer:any;

  constructor(private wsServicios:ServiciosService,
    public dialog: MatDialog) { }

  ngOnInit() {
    this.recargarTabla();
  }

  recargarTabla(){
    this.init = false;
    this.getServicios(1, this.search);
    this.carga = true;
  }

  async getServicios(pagina: number = 1, search: string = '') {
    this.cargos = [];
    this.wsServicios.getCargos(pagina, this.cantidad, search).subscribe((data: any) => {
      console.log(data);
      if (!data.ok) {
        return;
      }
      for(let i in data.data){
        data.data[i].editar = false;
      }
      this.cargos = data.data;
      if(this.init == false){
        this.init = true;
        this.totalPaginas = Math.ceil(data.total / this.cantidad);
        console.log(this.totalPaginas)
        this.paginas = [];
      }else{
        return;
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if(i > 5){
          return;
        }
        this.paginas.push(i);
      }
    });
  }

  async verPagina(pagina) {
    if(this.paginaActiva == pagina){
      return;
    }
    this.paginaActiva = pagina;
    await this.getServicios(pagina, this.search);
    if(this.totalPaginas <= 5){
      return;
    }
    this.paginas = [];
    if(pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina-2; i <= pagina + 2; i++){
        this.paginas.push(i);
      }
    }
    if(pagina >=3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1){
      for(let i = pagina - 3; i <= pagina + 1; i++){
        this.paginas.push(i);
      }
    }
    if(pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina - 1; i <= pagina + 3; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == this.totalPaginas && this.totalPaginas > 5){
      for(let i = pagina - 4; i <= pagina; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == 1 && this.totalPaginas > 5){
      for(let i = pagina; i <= pagina + 4; i++){
        this.paginas.push(i);
      }
    }

  }

  guardarCambios(id, costo, precio, activo){
    let sendData = {
      costo,
      precio,
      activo: (activo._checked) ? 1 : 0,
    };
    console.log(sendData);
    this.wsServicios.updateServicio(id, sendData).subscribe((data:any) => {
      console.log(data);
      return false;
    });
  }

  buscar(texto){
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.timer = 
      this.init = false;
      this.getServicios(1, texto)
    }, 500);
  }

  newCargo(){
    const dialogRef = this.dialog.open(NewCargoComponent, {
      width: '800px',
      data: {
        view: 'newCargo'
      }
    });

    dialogRef.afterClosed().subscribe((data: any) => {
      console.log(data);
      this.recargarTabla();
    });
  }


}
