import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  forma: FormGroup;
  errorLogin: boolean = false;
  msgError: string = '';

  constructor(private wsLogin: LoginService) {
    this.forma = new FormGroup({
      'user': new FormControl('', Validators.required),
      'pass': new FormControl('', Validators.required),
    });
  }

  ngOnInit() {
  }

  ingresar() {
    console.log(this.forma);
    let user = this.forma.value.user;
    let pass = this.forma.value.pass;
    this.wsLogin.ingresarUser(user, pass)
      .subscribe((data: any) => {
        console.log(data)
        if (!data.ok) {
          this.errorLogin = true;
          this.msgError = data.message;
          return
        }
          this.errorLogin = false;
          this.wsLogin.guardarSesionUser(data.data);
      }, (err) => {
        console.log(err);
        this.errorLogin = true;
        this.msgError = err.error.error;
      });
  }

}
