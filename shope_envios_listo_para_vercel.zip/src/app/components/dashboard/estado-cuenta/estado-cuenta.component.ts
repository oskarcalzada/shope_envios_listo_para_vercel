import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { AsociadoService } from 'src/app/services/asociado.service';
import { CotizadorService } from 'src/app/services/cotizador.service';
import { CreditoService } from 'src/app/services/credito.service';
import Swal from 'sweetalert2';
import { AsignarAbonoComponent } from '../../dialogs/asignar-abono/asignar-abono.component';
import { AsignarCargoComponent } from '../../dialogs/asignar-cargo/asignar-cargo.component';

@Component({
  selector: 'app-estado-cuenta',
  templateUrl: './estado-cuenta.component.html',
  styleUrls: ['./estado-cuenta.component.css']
})
export class EstadoCuentaDashComponent implements OnInit {

  idasociado:number = 0;
  saldo:number = 0;
  credito: any = {};
  loading:boolean = false;
  asociado:any;

  movimientos:Array<any> = [];
  totalPaginas: number;
  totalRegistros:number = 0;
  cantidad: number = 4;
  paginaActiva: number = 1;
  paginas: any[] = [];
  init: boolean = false;
  error: boolean = false;
  errMsg:string = '';
  loading2:boolean = false;
  isLoadCredito: boolean = false;

  diasCorte:Array<any>;

  limite:number = 0;
  diaCorte:number = 0;

  constructor(private active: ActivatedRoute,
    private wsCotizador: CotizadorService,
    private wsCredito: CreditoService,
    private wsAsociado: AsociadoService,
    private dialog: MatDialog) { 
    this.active.params.subscribe((params:any) => {
      this.idasociado = params.id;
    });
    this.diasCorte = new Array(20);
  }

  async ngOnInit(){
    await this.getAsociado();
    this.getSaldo();
    if(this.asociado.credito == 1){
      console.log('si')
      this.getSaldoCredito();
    }else{
      this.loading = true;
    }
    this.getMovimientos(1, this.cantidad)
  }

  async getAsociado(){
    await new Promise((resolve, reject) => {
      this.wsAsociado.getAsociado(this.idasociado).subscribe((data:any) => {
        console.log(data)
        if(!data.ok){
          reject('');
          return;
        }
        this.asociado = data.data;
        resolve('');
      });
    });

  }

  getSaldo(){
    this.wsCotizador.getSaldoU(this.idasociado).subscribe((data:any) => {
      console.log(data)
      if(!data.ok){
        return;
      }
      this.saldo = data.data.disponible;  
    });
  }

  getSaldoCredito(){
    this.loading = false;
    this.wsCredito.getSaldoCreditoU(this.idasociado).subscribe((data:any) => {
      this.loading = true;
      console.log(data)
      if(!data.ok){
        return;
      }
      this.isLoadCredito = true;
      this.credito = data.data;
      this.limite = this.credito.limite;
      this.diaCorte = this.credito.dia_corte;
    });
  }

  async getMovimientos(pagina: number = 1, cantidad) {
    this.movimientos = [];
    this.loading2 = true;
    this.error = false;
    this.wsCotizador.getMovimientosU(pagina, cantidad, this.idasociado).subscribe((data: any) => {
      console.log(data)
      this.loading2 = false;
      if (!data.ok) {
        this.error = true;
        this.errMsg = data.message;
        this.paginas = [];
        return;
      }
      for(let i in data.data){
        data.data[i].editar = false;
      }
      this.movimientos = data.data;
      if(this.init == false){
        this.init = true;
        this.totalPaginas = Math.ceil(data.total / this.cantidad);
        this.totalRegistros = data.total;
        console.log(this.totalPaginas)
        this.paginas = [];
        this.paginaActiva = 1;
      }else{
        return;
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if(i > 5){
          return;
        }
        this.paginas.push(i);
      }
    });
  }

  async verPagina(pagina) {
    if(this.paginaActiva == pagina){
      return;
    }
    this.paginaActiva = pagina;
    await this.getMovimientos(pagina, this.cantidad);
    if(this.totalPaginas <= 5){
      return;
    }
    this.paginas = [];
    if(pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina-2; i <= pagina + 2; i++){
        this.paginas.push(i);
      }
    }
    if(pagina >=3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1){
      for(let i = pagina - 3; i <= pagina + 1; i++){
        this.paginas.push(i);
      }
    }
    if(pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina - 1; i <= pagina + 3; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == this.totalPaginas && this.totalPaginas > 5){
      for(let i = pagina - 4; i <= pagina; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == 1 && this.totalPaginas > 5){
      for(let i = pagina; i <= pagina + 4; i++){
        this.paginas.push(i);
      }
    }

  }

  activarCredito(){
    let sendData = {
      id_asociado: this.idasociado,
      limite: 5000,
      corte: 2,
      fecha_limite: moment().format('YYYY-MM-DD') 
    }
    this.wsCredito.activarCredito(sendData).subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      this.asociado.credito = 1;
      this.getSaldoCredito();
    })
  }

  guardarCambios(){
    let sendData = {
      id_asociado: this.idasociado,
      limite: this.limite,
      corte: this.diaCorte,
      fecha_limite: moment().startOf('month').add(this.diaCorte, 'days').format('YYYY-MM-DD')
    }
    this.wsCredito.updateCredito(sendData).subscribe((data:any) => {
      if(!data.ok){
        Swal.fire({
          icon: 'error',
          title: 'No se logro actualizar la linea de credito'
        })
        return;
      }
      this.getSaldoCredito();
      Swal.fire({
        icon: 'success',
        title: 'Se actualizo correctamente la linea de credito'
      })
    });
  }

  status(event:any){
    let activo = (event.checked) ? 1 : 0;
    this.wsCredito.statusCredito(activo, this.idasociado).subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      this.credito.activo = activo;
    })
  }

  nuevoCargo(){
    const dialogRef = this.dialog.open(AsignarCargoComponent, {
      width: '800px',
      data: {
        idasociado: this.idasociado
      }
    });

    dialogRef.afterClosed().subscribe((data:any) => {
      this.init = false;
      this.getMovimientos(1, this.cantidad);
      this.getSaldo();
    });
  }

  nuevoAbono(){
    const dialogRef = this.dialog.open(AsignarAbonoComponent, {
      width: '800px',
      data: {
        idasociado: this.idasociado
      }
    });

    dialogRef.afterClosed().subscribe((data:any) => {
      this.init = false;
      this.getMovimientos(1, this.cantidad);
      this.getSaldo();
    });
  }


}
