import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ServiciosService } from 'src/app/services/servicios.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-comprobantes-dash',
  templateUrl: './comprobantes-dash.component.html',
  styleUrls: ['./comprobantes-dash.component.css']
})
export class ComprobantesDashComponent implements OnInit {

  comprobantes: any[] = [];
  totalPaginas: number;
  cantidad: number = 4;
  paginaActiva: number = 1;
  paginas: any[] = [];
  search: string = '';
  init: boolean = false;
  status:string = 'PENDIENTE';
  loading:boolean = false;
  urlBack:string = environment.urlBack;

  constructor(private wsServicio: ServiciosService,
    private snackCtrl: MatSnackBar) { }

  ngOnInit() {
    this.getComprobantes(1);
  }

  getCom(){
    this.init = false;
    this.getComprobantes(1)
  }

  async getComprobantes(pagina: number = 1) {
    this.comprobantes = [];
    this.loading = true;
    this.wsServicio.getComprobantes(pagina, this.cantidad, this.status).subscribe((data: any) => {
      this.loading = false;
      console.log(data);
      if (!data.ok) {
        return;
      }
      for(let i in data.data){
        data.data[i].aceptar = false;
        data.data[i].rechazar = false;
      }
      this.comprobantes = data.data;
      if(this.init == false){
        this.init = true;
        this.totalPaginas = Math.ceil(data.total / this.cantidad);
        console.log(this.totalPaginas)
        this.paginas = [];
        this.paginaActiva = 1;
        if(this.comprobantes.length <= 0){
          this.msgSnack('No se encontraron resultados');
        }
      }else{
        return;
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if(i > 5){
          return;
        }
        this.paginas.push(i);
      }
    });
  }

  async verPagina(pagina) {
    if(this.paginaActiva == pagina){
      return;
    }
    this.paginaActiva = pagina;
    await this.getComprobantes(pagina);
    if(this.totalPaginas <= 5){
      return;
    }
    this.paginas = [];
    if(pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina-2; i <= pagina + 2; i++){
        this.paginas.push(i);
      }
    }
    if(pagina >=3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1){
      for(let i = pagina - 3; i <= pagina + 1; i++){
        this.paginas.push(i);
      }
    }
    if(pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina - 1; i <= pagina + 3; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == this.totalPaginas && this.totalPaginas > 5){
      for(let i = pagina - 4; i <= pagina; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == 1 && this.totalPaginas > 5){
      for(let i = pagina; i <= pagina + 4; i++){
        this.paginas.push(i);
      }
    }

  }

  aceptarComprobante(id_estado:number){
    let i = this.comprobantes.findIndex(element => element.id_estado == id_estado);
    this.comprobantes[i].aceptar = true;
    this.wsServicio.aceptarComprobante(id_estado).subscribe((data:any) => {
      console.log(data);
      this.comprobantes[i].aceptar = false;
      if(!data.ok){
        Swal.fire({
          icon: 'error',
          title: 'No se logro procesar el pago'
        });
        return;
      }
      Swal.fire({
        icon: 'success',
        title: 'Se acredito correctamente el pago',
        html: `<b>El dinero se abono a la cuenta del cliente</b>`
      });
      this.comprobantes.splice(i, 1);
    })
  }

  rechazarComprobante(id_estado:number){
    let i = this.comprobantes.findIndex(element => element.id_estado == id_estado);
    this.comprobantes[i].rechazar = true;
    this.wsServicio.rechazarComprobante(id_estado).subscribe((data:any) => {
      console.log(data);
      this.comprobantes[i].rechazar = false;
      if(!data.ok){
        Swal.fire({
          icon: 'error',
          title: 'No se logro rechazar el pago'
        });
        return;
      }
      Swal.fire({
        icon: 'info',
        title: 'Se rechazo el pago',
      });
      this.comprobantes.splice(i, 1);
    })
  }


  msgSnack(message:string){
    this.snackCtrl.open(message, 'Ok', {
      horizontalPosition: 'end',
      verticalPosition: 'bottom',
      duration: 4000
    })
  }


}
