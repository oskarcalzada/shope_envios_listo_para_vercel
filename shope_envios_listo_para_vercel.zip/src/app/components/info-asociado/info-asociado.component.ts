import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AsociadoService } from 'src/app/services/asociado.service';
import { EditAsociadoComponent } from '../dialogs/edit-asociado/edit-asociado.component';

@Component({
  selector: 'app-info-asociado',
  templateUrl: './info-asociado.component.html',
  styleUrls: ['./info-asociado.component.css']
})
export class InfoAsociadoComponent implements OnInit {

  info:any;
  loading:boolean = false;

  constructor(private dialog:MatDialog,
    private wsAsociado: AsociadoService) { }

  ngOnInit(): void {
    this.getInfo();
  }

  edit(info, tipoVista: string){
    const dialogRef = this.dialog.open(EditAsociadoComponent, {
      width: '800px',
      data: {
        info,
        tipoVista
      }
    });

    dialogRef.afterClosed().subscribe((result:any) => {
      if(result == 0 || result == undefined){
        return;
      }
      if(result.validar){
        this.info.valid_phone = 1;
        return;
      }
      this.info = result;
    });
  }

  getInfo(){
    this.wsAsociado.getAsociadoClient().subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      this.loading = true;
      this.info = data.data;
      console.log('info', this.info);
    });
  }

}
