import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aviso-privacidad',
  templateUrl: './aviso-privacidad.component.html',
  styleUrls: ['./aviso-privacidad.component.css']
})
export class AvisoPrivacidadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
