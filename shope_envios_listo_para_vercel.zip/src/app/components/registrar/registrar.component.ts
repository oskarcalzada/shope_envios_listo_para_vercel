import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { Router } from '@angular/router';
import { AsociadoService } from 'src/app/services/asociado.service';
import { environment } from 'src/environments/environment';
import Swal from 'sweetalert2';

interface ErrorValidate{
  [s: string]: boolean
}

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-registrar',
  templateUrl: './registrar.component.html',
  styleUrls: ['./registrar.component.css']
})
export class RegistrarComponent implements OnInit {

  urlBack: string = environment.urlBack;
  forma: FormGroup;
  matcher = new MyErrorStateMatcher();
  userNew:any;

  constructor(private route: Router,
    private wsAsociado: AsociadoService) {
    this.forma = new FormGroup({
      nombre: new FormControl('', Validators.required),
      apellido: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      email2: new FormControl(''),
      telefono: new FormControl('', [Validators.required, Validators.maxLength(10)]),
      rfc: new FormControl('', [Validators.required, Validators.minLength(12)]),
      terminos: new FormControl('', [Validators.requiredTrue]),
      tipo: new FormControl('email', Validators.required),
      envios: new FormControl('', Validators.required)
    });

    if(localStorage.getItem('userNew')){
      this.userNew = JSON.parse(localStorage.getItem('userNew'));
      console.log(this.userNew);
      this.forma.get('nombre').setValue(this.userNew.nombre);
      this.forma.get('email').setValue(this.userNew.email);
      this.forma.get('email').disable();
      this.forma.get('email2').setValue(this.userNew.email);
      this.forma.get('email2').disable();
      this.forma.get('tipo').setValue(this.userNew.type);
    }

  }

  ngOnInit(): void {

  }

  validarEmail(control: FormControl): ErrorValidate {
    // console.log(this.forma)
    if (control.value !== this.forma.controls['email'].value) {
      return { error: true };
    }
    return {};
  }

  registrar(){
    let value = this.forma.getRawValue();
    let sendData = {
      nombre: value.nombre,
      apellido: value.apellido,
      email: value.email,
      telefono: value.telefono,
      rfc: value.rfc,
      tipo: value.tipo,
      envios: value.envios
    }
    console.log(sendData);
    this.wsAsociado.newAsociado(sendData).subscribe(data => {
      console.log(data);
      if(!data.ok){
        Swal.fire({
          icon: 'error',
          title: 'No se logro enviar la solicitud de registro',
          allowOutsideClick: false,
          confirmButtonText: 'Aceptar',
        });
        return;
      }
      localStorage.removeItem('userNew');
      Swal.fire({
        icon: 'success',
        title: '¡Registro Completo!',
        html: `<h4 class="fw-bold">Se te enviara un correo con tu usuario y contraseña</h4>
              <h5>Para dar seguimiento a la activación de tu cuenta, favor de mandar correo a<br>
              <a href="mailto:contacto@shopeenvios.com.mx">contacto@shopeenvios.com.mx</a></h5>`,
        allowOutsideClick: false,
        confirmButtonText: 'Aceptar',
      }).then((result:any) => {
        if(result.isConfirmed){
          this.route.navigate(['/login']);
        }
      })
    });
  }

}
