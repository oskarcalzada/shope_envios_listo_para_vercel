import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CotizadorService } from 'src/app/services/cotizador.service';
import { RecargaSaldoComponent } from '../dialogs/recarga-saldo/recarga-saldo.component';

@Component({
  selector: 'app-estado-cuenta',
  templateUrl: './estado-cuenta.component.html',
  styleUrls: ['./estado-cuenta.component.css']
})
export class EstadoCuentaComponent implements OnInit {

  saldo:number = 0;
  refresh:number = 0;

  constructor(private wsCotizador: CotizadorService,
    private dialog: MatDialog,
    private snackCtrl: MatSnackBar) { }

  ngOnInit(): void {
    this.getSaldo();
  }

  getSaldo(){
    this.wsCotizador.getSaldo().subscribe((data:any) => {
      if(!data.ok){
        return
      }
      this.saldo = data.data.disponible
    });
  }

  recargar(){
    const dialogRef = this.dialog.open(RecargaSaldoComponent, {
      width: '800px',
      disableClose: true,
      data: {
        metodo: 1
      }
    });

    dialogRef.afterClosed().subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      this.msgSnack('El pedido se genero correctamente');
      this.refresh += 1;
    });
  }

  msgSnack(message:string){
    this.snackCtrl.open(message, 'Ok', {
      horizontalPosition: 'end',
      verticalPosition: 'bottom',
      duration: 4000
    })
  }

  recargarM(evento){
    console.log('evento', evento)
    this.refresh += 1;
  }
}
