import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AsociadoService } from 'src/app/services/asociado.service';
import { CreditoService } from 'src/app/services/credito.service';
import { RecargaSaldoComponent } from '../../dialogs/recarga-saldo/recarga-saldo.component';

@Component({
  selector: 'app-credito',
  templateUrl: './credito.component.html',
  styleUrls: ['./credito.component.css']
})
export class CreditoComponent implements OnInit {

  credito: any = {};
  loading: boolean = false;
  asociado:any = {};

  @Output() recargar:EventEmitter<any> = new EventEmitter();

  constructor(private wsCredito: CreditoService,
    private dialog:MatDialog,
    private snackCtrl: MatSnackBar,
    private wsAsociado:AsociadoService) { }

  ngOnInit(): void {
    this.wsAsociado.getAsociadoClient().subscribe((data:any) => {
      console.log(data)
      if(!data.ok){
        return;
      }
      this.asociado = data.data;
      console.log('asociado', this.asociado);
      if(data.data.credito == 1){
        this.getCredito();
      }else{
        this.loading = true;
      }
    });
  }

  getCredito() {
    this.loading = false;
    this.wsCredito.getSaldoCredito().subscribe((data: any) => {
      this.loading = true;
      if (!data.ok) {
        return;
      }
      this.credito = data.data;
      console.log(this.credito)
    });
  }

  pagarCredito(){
    const dialogRef = this.dialog.open(RecargaSaldoComponent, {
      width: '800px',
      data: {
        metodo: 2
      }
    });

    dialogRef.afterClosed().subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      this.msgSnack('El pedido se genero correctamente');
      this.recargar.emit({});
    })
  }

  msgSnack(message:string){
    this.snackCtrl.open(message, 'Ok', {
      horizontalPosition: 'end',
      verticalPosition: 'bottom',
      duration: 4000
    })
  }

  solicitarCredito(){
    this.wsCredito.solicitarCredito().subscribe((data:any) => {
      console.log(data)
      if(!data.ok){
        return;
      }
      this.asociado.solicitud_credito = 1;
    })
  } 

}
