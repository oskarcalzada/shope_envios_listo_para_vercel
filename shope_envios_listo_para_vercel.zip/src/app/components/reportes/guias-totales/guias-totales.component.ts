import { Component, ElementRef, HostListener, Input, OnChanges } from '@angular/core';
import { ReportesService } from '../../../services/reportes.service';
import * as moment from 'moment';

@Component({
  selector: 'app-guias-totales',
  templateUrl: './guias-totales.component.html',
  styleUrls: ['./guias-totales.component.css']
})
export class GuiasTotalesComponent implements OnChanges {


  @Input() inicio: string = '';
  @Input() fin: string = '';

  ver: boolean = true;
  paqueteria: string = '';
  guiasPaq: Array<any> = [];
  loading: boolean = false;
  loading2: boolean = false;
  multi = [];
  totalRegistros: number = 0;
  viewPaqTotal: boolean = false;

  view: any[] = [1000, 600];

  // options
  legend: boolean = true;
  legendTitle: string = 'Estados';
  legendPosition: string;
  showLabels: boolean = true;
  animations: boolean = true;
  xAxis: boolean = true;
  yAxis: boolean = true;
  showYAxisLabel: boolean = true;
  showXAxisLabel: boolean = true;
  xAxisLabel: string = 'Días';
  yAxisLabel: string = 'Guías';
  timeline: boolean = true;

  colorScheme = {
    domain: ['#5AA454', '#E44D25', '#CFC0BB', '#7aa3e5', '#a8385d', '#aae3f5']
  };

  // Number Card
  single: any[];
  viewCard: any[] = [300, 200];
  cardColor: string = '#232837';

  constructor(private wsReportes: ReportesService, private elementRef: ElementRef) {
    this.onResize(event);
  }

  ngOnChanges() {
    this.getReportesPaqueterias();
  }

  onSelect(data): void {
    this.paqueteria = JSON.parse(JSON.stringify(data));
    this.getGuiasPaqTotal();
    this.ver = true;
  }

  @HostListener('document:click', ['$event'])
  clickout(event: MouseEvent) {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      const fix = document.getElementById('fix');
      if (fix) {
        this.ver = false;
      }
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    if (window.innerWidth <= 768) {
      this.view = [500, 300];
      this.legendPosition = 'below';
      return;
    }
    if (window.innerWidth <= 992) {
      this.view = [800, 400];
      this.legendPosition = 'below';
      return;
    }
    if (window.innerWidth <= 1200) {
      this.view = [800, 400];
      this.legendPosition = 'right';
      return;
    }
    this.view = [1000, 600];
    this.legendPosition = 'right';
  }

  getReportesPaqueterias() {
    let inicioFormat = moment(this.inicio).format('YYYY-MM-DD');
    let finFormat = moment(this.fin).format('YYYY-MM-DD');
    this.wsReportes.getGuiasPaqueteria(inicioFormat, finFormat).subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.guiasPaq = data.data;
      for (const guia of this.guiasPaq) {
        guia['fecha'] = moment(guia['fecha'].substring(0, 10));
        const fechaFormateada = guia['fecha'].format("DD/MMM");
        guia['fecha'] = fechaFormateada;
      }

      const resulGuiasPaqueteria = this.guiasPaq.reduce((prev: any[], current) => {
        if (prev.findIndex(element => element.name === current.paqueteria) < 0) {
          prev.push({
            name: current.paqueteria,
            series: []
          });
          const i = prev.findIndex(element => element.name === current.paqueteria);
          if (i < 0) {
            return prev;
          }
          prev[i].series.push({ name: current.fecha, value: current.conteo });
          return prev;
        }
        const i = prev.findIndex(element => element.name === current.paqueteria);
        if (i < 0) {
          return prev;
        }
        prev[i].series.push({ name: current.fecha, value: current.conteo });
        return prev;
      }, []);
      this.multi = resulGuiasPaqueteria;
      this.loading2 = true;
    });
  }

  async getGuiasPaqTotal() {
    let inicioFormat = moment(this.inicio).format('YYYY-MM-DD');
    let finFormat = moment(this.fin).format('YYYY-MM-DD');
    this.wsReportes.getGuiasPaqTotal(inicioFormat, finFormat, this.paqueteria).subscribe(async (data: any) => {
      this.loading = false;
      if (!data.ok) {
        return;
      }
      this.totalRegistros = await data.total[0].conteo;
      this.asignarTotal();
      this.loading = true;
    });
    this.viewPaqTotal = true;
  }

  async asignarTotal() {
    this.single = [{
      "name": this.paqueteria,
      "value": this.totalRegistros
    }];
  }
}