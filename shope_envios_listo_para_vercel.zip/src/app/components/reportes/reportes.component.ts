import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { AsociadoService } from '../../services/asociado.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reportes',
  templateUrl: './reportes.component.html',
  styleUrls: ['./reportes.component.css']
})
export class ReportesComponent implements OnInit {

  inicio: string = '';
  fin: string = '';
  inicioInput: string = '';
  finInput: string = '';
  loading: boolean = false;
  opcionSeleccionada: number = 1;
  info: any;

  constructor(private wsAsociado: AsociadoService,
    private router: Router) { }

  ngOnInit(): void {
    this.getAsociado();
  }

  cambiarVista(opcion: number) {
    this.opcionSeleccionada = opcion;
  }

  getAsociado(){
    this.wsAsociado.getAsociadoClient().subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      this.info = data.data
      if(this.info?.kpis !== 1){
        this.router.navigate(['/menu/inicio'])
      } 
    });
  }

  enviarDatosAComponente() {
    this.loading = true;
    this.inicio = moment(this.inicioInput).format('YYYY-MM-DD');
    this.fin = moment(this.finInput).format('YYYY-MM-DD');
  }
}