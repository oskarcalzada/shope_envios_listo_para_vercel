import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ReportesService } from 'src/app/services/reportes.service';
import { ServiciosService } from 'src/app/services/servicios.service';

@Component({
  selector: 'app-recolecciones-pendientes',
  templateUrl: './recolecciones-pendientes.component.html',
  styleUrls: ['./recolecciones-pendientes.component.css']
})
export class RecoleccionesPendientesComponent implements OnInit {

  loading: boolean = false;
  recoleccionesPendientes: Array<any> = [];
  selectedPaqueteria: string = '';
  filteredData: any[] = [];
  paqueterias: Array<any> = [];
  paqueteria: string = 'estafeta';
  isPaquete: boolean = true;

  constructor(private wsReportes: ReportesService, private wsServicio: ServiciosService) { }

  ngOnInit(): void {
    this.getPaqueterias();
    this.getReportesPaqueterias();
  }

  getReportesPaqueterias() {
    this.wsReportes.getRecoleccionesPendientes().subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.recoleccionesPendientes = data.data;
      this.loading = true;
      for (const fecha of this.recoleccionesPendientes) {
        fecha['fecha_recoleccion'] = moment(fecha['fecha_recoleccion']).format('YYYY-MM-DD');
      }
    });
  }

  filterByPaqueteria(paqueteria: string) {
    this.selectedPaqueteria = paqueteria;
    this.filteredData = this.recoleccionesPendientes.filter(item => item.paqueteria === paqueteria);
  }

  getPaqueterias() {
    this.wsServicio.getPaqueteriasAsociado().subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.paqueterias = data.data;
      this.paqueterias = this.paqueterias.filter((paq: any) => paq.descripcion != 'MINUTES');
    })
  }

  cambiarPaqueteria(paqueteria: string) {
    this.paqueteria = paqueteria;
    if (this.paqueteria == 'estafeta') {
      this.isPaquete = true;
    } else {
      this.isPaquete = false;
    }
  }

}
