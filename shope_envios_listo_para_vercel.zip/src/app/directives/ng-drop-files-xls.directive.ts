import { Directive, EventEmitter, HostListener, Input, Output } from '@angular/core';

@Directive({
  selector: '[appNgDropFilesXls]'
})
export class NgDropFilesXlsDirective {

  @Input() archivos!: File;
  @Output() mouseSobre: EventEmitter<any> = new EventEmitter();
  @Output() clickImg: EventEmitter<any> = new EventEmitter();

  constructor() { 
  }

  @HostListener('click', ['$event'])
  public onClick(event: any) {
    this.clickImg.emit({ok: true});
  }

  @HostListener('dragover', ['$event'])
  public onDragEnter(event: any) {
    this.mouseSobre.emit({ok: true});
    this._prevenirDetener(event);
  }

  @HostListener('dragleave', ['$event'])
  public onDragLeave(event: any) {
    this.mouseSobre.emit({ok: false});
  }

  @HostListener('drop', ['$event'])
  public onDrop(event: any) {
    this._prevenirDetener(event);
    const transferencia = this._getTransferencia(event);
    if (!transferencia) {
      return;
    }
    this.mouseSobre.emit({ok: false, file: this._extraerArchivos(transferencia.files)});
  }

  private _getTransferencia(event: any) {
    return event.dataTransfer ? event.dataTransfer : event.originalEvent.dataTransfer;
  }

  private _extraerArchivos(archivosLista: FileList) {
    
    if (!this._soloUnArchivo(archivosLista)) {
      return [];
    }

    for(const propiedad in Object.getOwnPropertyNames(archivosLista)){
      const archivoTemporal = archivosLista[propiedad];
      if(this._archivoPuedeSerCargado(archivoTemporal)){
        this.archivos = archivoTemporal;
        console.log('archivo', this.archivos)
        return this.archivos;
      }
    }

    return [];

  }

  //Validaciones

  private _archivoPuedeSerCargado(archivo: File): boolean {
   
    if (this._esExcel(archivo.type)) {
      return true;
    } else {
      return false;
    }
  }

  private _soloUnArchivo(archivos: FileList): boolean {
    if (archivos.length > 1) {
      return false;
    }
    return true;
  }

  private _prevenirDetener(event:any) {
    event.preventDefault();
    event.stopPropagation();
  }

  private _esExcel(tipoArchivo: string): boolean {
    return (tipoArchivo === '' || tipoArchivo === undefined) ? false : tipoArchivo.startsWith('application/vnd');
  }

}
