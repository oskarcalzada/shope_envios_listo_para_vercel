import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  headers:any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) { }

  getTokens(){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '' ;
    return this.app.get('/tokens', this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  nuevoToken(){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.post('/tokens', this.headers, {}).pipe(map((data:any) => {
      return data;
    }));
  }

  statusToken(status:number, id_token:number){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.put('/tokens', this.headers, {status, id_token}).pipe(map((data:any) => {
      return data;
    }));
  }

  borrarToken(id_token:number){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.delete(`/tokens?id_token=${id_token}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

}
