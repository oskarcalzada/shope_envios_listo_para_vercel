import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class MultiusuarioService {

  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) { }

  getMultiUsuarios(pagina:number, cantidad:number, search:string) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/multiusuarios?pagina=${pagina}&cantidad=${cantidad}&search=${search}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getUserName(username: string) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/multiusuarios/username?username=${username}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  addMultiUser(body: any) {
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    this.auth.activateClient();
    return this.app.post(`/multiusuarios`, this.headers, body).pipe(map((data: any) => {
      return data;
    }));
  }

  editMultiUser(body: any) {
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    this.auth.activateClient();
    return this.app.put(`/multiusuarios`, this.headers, body).pipe(map((data: any) => {
      return data;
    }));
  }

  status(idusuario:number, status:any){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient');
    return this.app.delete(`/multiusuarios?idusuario=${idusuario}&activo=${status}`, this.headers).pipe(map((data:any) => {
      return data;
    }))
  }

  borrar(idusuario:number){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient');
    return this.app.delete(`/multiusuarios/borrar?idusuario=${idusuario}`, this.headers).pipe(map((data:any) => {
      return data;
    }))
  }

}
