import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  tokenUser: string = '';
  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) {
  }

  getUsers(pagina:number, cantidad:number, search:string) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/usuario?pagina=${pagina}&cantidad=${cantidad}&search=${search}`, this.headers)
      .pipe(map((data: any) => {
        return data;
      }));
  }

  getUser(){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/usuario/info`, this.headers).pipe(map((data:any) => {
      return data;
    }))
  }

  addUser(body: any) {
    this.headers['Authorization'] = localStorage.getItem('token');
    this.auth.activate();
    return this.app.post(`/usuario`, this.headers, body).pipe(map((data: any) => {
      return data;
    }))
  }

  editUser(body: any) {
    this.headers['Authorization'] = localStorage.getItem('token');
    this.auth.activate();
    return this.app.put(`/usuario`, this.headers, body).pipe(map((data: any) => {
      return data;
    }))
  }

  getPerfil(){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get('/usuario/perfil', this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  getUserName(username:string){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/usuario/username?username=${username}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  status(idusuario:number, status:any){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.delete(`/usuario?idusuario=${idusuario}&activo=${status}`, this.headers).pipe(map((data:any) => {
      return data;
    }))
  }

  getNoActivos(){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/notifications/no-activos`, this.headers).pipe(map((data:any) => {
      return data;
    }))
  }

}
