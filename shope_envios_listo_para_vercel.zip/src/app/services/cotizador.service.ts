import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class CotizadorService {

  headers:any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) { }

  getServicios(data:any) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.post('/cotizador', this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }

  nuevoCargo(data:any){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.post('/servicio/movimiento', this.headers, data).pipe(map((data:any) => {
      return data;
    }))
  }

  nuevoCargoUser(data:any){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token') || '';
    return this.app.post('/servicio/usuario/movimiento', this.headers, data).pipe(map((data:any) => {
      return data;
    }))
  }

  getSaldo(){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get('/servicio/saldo', this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  getMovimientos(pagina:number, cantidad:number){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/movimientos?pagina=${pagina}&cantidad=${cantidad}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  sendComprobante(data:any){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.post(`/comprobante`, this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }

  getSaldoU(idasociado:number){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/usuario/servicio/saldo?id_asociado=${idasociado}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  getMovimientosU(pagina:number, cantidad:number, idasociado:number){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/usuario/movimientos?pagina=${pagina}&cantidad=${cantidad}&id_asociado=${idasociado}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  getCobertura(origen:string, destino:string, paqueteria:string){
    return this.app.get(`/${paqueteria.toLowerCase()}/cobertura?origen=${origen}&destino=${destino}`, {}).pipe(map((data:any) => {
      return data;
    }));
  }

  getServiciosGenerales(data:any) {
    return this.app.post('/cotizador/general', this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }

}
