import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class ServiciosService {
  token: string
  headers: any;

  constructor(private app:Peticiones,
    private auth:AuthenticatedService) {
    this.token = localStorage.getItem('token') || '';
    this.headers = {
      'Authorization': this.token
    }
  }

  getServicios(pagina:number, cantidad:number, search:string, paqueteria:string){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/usuario/servicios/${paqueteria}?pagina=${pagina}&cantidad=${cantidad}&search=${search}`, this.headers).pipe(map((data) => { 
      return data;
    }));
  }

  getCargos(pagina:number, cantidad:number, search:string){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/usuario/cargos?pagina=${pagina}&cantidad=${cantidad}&search=${search}`, this.headers).pipe(map((data) => { 
      return data;
    }));
  }

  updateServicio(idservicio:number, data:any){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.put(`/servicios/${idservicio}`, this.headers, data).pipe(map((data:any) => {
      return data;
    }))
  }

  getPaqueterias(){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/usuario/paqueterias`, this.headers).pipe(map((data:any) => {
      return data;
    }))
  }

  getPaqueteriasAsociado(){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/paqueterias`, this.headers).pipe(map((data:any) => {
      return data;
    }))
  }

  newServicio(data:any){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.post('/servicios', this.headers, data).pipe(map((data:any) => {
      return data;
    }))
  }

  newCargo(data:any){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.post('/cargos', this.headers, data).pipe(map((data:any) => {
      return data;
    }))
  }

  getComprobantes(pagina:number, cantidad:number, status:string){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/comprobante?pagina=${pagina}&cantidad=${cantidad}&status=${status}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  aceptarComprobante(id_estado:number){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.post(`/comprobante/aceptar`, this.headers, {id_estado}).pipe(map((data:any) => {
      return data;
    }));
  }

  rechazarComprobante(id_estado:number){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.delete(`/comprobante/rechazar?id_estado=${id_estado}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  getAllServicios(){
    this.auth.activate();
    return this.app.get('/servicios/all', this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  getAllCargos(){
    this.auth.activate();
    return this.app.get('/cargos/all', this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  setServiceCustom(data:any){
    this.auth.activate();
    return this.app.post('/servicios/custom', this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }

  getServiceCustom(idasociado:number){
    this.auth.activate();
    return this.app.get(`/servicios/custom?idasociado=${idasociado}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }
  
  deleteServicio(idasociado:number, idservicio:number){
    this.auth.activate();
    return this.app.delete(`/servicios/custom?idasociado=${idasociado}&idservicio=${idservicio}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  enviarContacto(data:any){
    return this.app.post(`/mail/contacto`, this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }
  deleteDir(data:any){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.put(`/direccion/borrar`,this.headers,data).pipe(map((data:any) =>{
      return data
    }))
  }
  guardarDir(data:any){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '' ;
    return this.app.post(`/direccion/guardar`, this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }
  actualizarDir(data:any){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '' ;
    return this.app.post(`/direccion/actualizar`, this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }
  getDirecciones(pagina:number,cantidad:number){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '' ;
    return this.app.get(`/direcciones?pagina=${pagina}&cantidad=${cantidad}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }
  getDireccionesIdDir(id:number){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '' ;
    return this.app.get(`/direcciones/id_dir?id=${id}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }
  cargarDir(data:any){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '' ;
    return this.app.post(`/direccion/cargar`, this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }

  getTracking(paqueteria:string, tracking:string){
    return this.app.get(`/${paqueteria}/tracking/${tracking}`, this.headers).pipe((data:any) => {
      return data;
    });
  }

}
