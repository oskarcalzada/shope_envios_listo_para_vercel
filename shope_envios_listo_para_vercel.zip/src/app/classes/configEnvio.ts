import { Validators } from '@angular/forms';

export const configEnvio = (paqueteria: string) => {
    switch (paqueteria) {
        case 'estafeta':
            return {
                nombre: [Validators.required, Validators.maxLength(30), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_\-]*)([^\s])$/)],
                compania: [Validators.required, Validators.maxLength(50), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_\-]*)([^\s])$/)],
                calle: [Validators.required, Validators.maxLength(50), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_.\-]*)([^\s])$/)],
                ciudad: [Validators.required, Validators.maxLength(50)],
                cp: [Validators.required],
                colonia: [Validators.required],
                estado: [Validators.required],
                telefono: [Validators.required, Validators.minLength(1), Validators.max(9999999999)],
                contenido: [Validators.required, Validators.maxLength(25)],
                referencia: [Validators.maxLength(30)]
            };
        case 'fedex':
            return {
                nombre: [Validators.required, Validators.maxLength(29), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_\-]*)([^\s])$/)],
                compania: [Validators.required, Validators.maxLength(35), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_\-]*)([^\s])$/)],
                calle: [Validators.required, Validators.maxLength(35), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_.\-]*)([^\s])$/)],
                ciudad: [Validators.required, Validators.maxLength(35)],
                cp: [Validators.required],
                colonia: [Validators.required],
                estado: [Validators.required],
                telefono: [Validators.required, Validators.minLength(1), Validators.max(9999999999)],
                contenido: [Validators.maxLength(30)],
                referencia: [Validators.maxLength(35)]
            };
        case 'minutes':
            return {
                nombre: [Validators.required, Validators.maxLength(29), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_\-]*)([^\s])$/)],
                compania: [Validators.required, Validators.maxLength(35), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_\-]*)([^\s])$/)],
                calle: [Validators.required, Validators.maxLength(35), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_.\-]*)([^\s])$/)],
                ciudad: [Validators.required, Validators.maxLength(35)],
                cp: [Validators.required],
                colonia: [Validators.required],
                estado: [Validators.required],
                telefono: [Validators.required, Validators.minLength(1), Validators.max(9999999999)],
                contenido: [Validators.maxLength(30)],
                referencia: [Validators.maxLength(35)],
                email: [Validators.required, Validators.email],
            };
        case 'dhl':
            return {
                nombre: [Validators.required, Validators.maxLength(29), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_\-]*)([^\s])$/)],
                compania: [Validators.required, Validators.maxLength(35), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_\-]*)([^\s])$/)],
                calle: [Validators.required, Validators.maxLength(45), Validators.pattern(/^([^\s])([\sa-zA-Z0-9_.\-]*)([^\s])$/)],
                ciudad: [Validators.required, Validators.maxLength(35)],
                cp: [Validators.required],
                colonia: [Validators.required],
                estado: [Validators.required],
                telefono: [Validators.required, Validators.minLength(1), Validators.max(9999999999)],
                contenido: [Validators.maxLength(30)],
                referencia: [Validators.maxLength(35)]
            };
        default:
            return null;
    }
}