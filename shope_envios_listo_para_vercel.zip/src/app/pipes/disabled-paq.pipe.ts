import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'disabledPaq'
})
export class DisabledPaqPipe implements PipeTransform {

  transform(value: string, servicio:any): boolean {
    console.log(value, servicio)
    if(value == 'FEDEX' && servicio?.fedex){
        return false;
    }
    if(value == 'ESTAFETA' && servicio?.estafeta){
      return false;
    }
    if(value == 'MINUTES' && servicio['minutes']){
      return false;
    }
    if(value == 'DHL' && servicio['dhl']){
      return false;
    }
    return true;
  }

}
