import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Pipe({
  name: 'colorPack'
})
export class ColorPackPipe implements PipeTransform {

  constructor(private sanitizer: DomSanitizer) { }

  transform(paqueteria: string) {

    console.log({ paqueteria })

    switch (paqueteria) {
      case 'FEDEX':
        return this.sanitizer.bypassSecurityTrustHtml(`<b style="background-color: #491385;color: white;padding: 5px;border-radius: 5px">${paqueteria}</b>`);
      case 'ESTAFETA':
        return this.sanitizer.bypassSecurityTrustHtml(`<b style="background-color: #C00D0D;color: white;padding: 5px;border-radius: 5px">${paqueteria}</b>`);
      case '99 MINUTOS':
        return this.sanitizer.bypassSecurityTrustHtml(`<b style="background-color: #85C440;color: white;padding: 5px;border-radius: 5px">${paqueteria}</b>`);
      case 'DHL':
        return this.sanitizer.bypassSecurityTrustHtml(`<b style="background-color: #FECC00;padding: 5px;border-radius: 5px;color: #D50029 !important;">${paqueteria}</b>`);
      default:
        return this.sanitizer.bypassSecurityTrustHtml(paqueteria);
    }

  }

}
