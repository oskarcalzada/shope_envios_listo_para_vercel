import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'zonaext'
})
export class ZonaextPipe implements PipeTransform {

  transform(item: any, servicio: any): string {

    switch (item.paqueteria.toLowerCase()) {
      case 'estafeta':
        return (servicio.estafeta_extendida) ? 'SI' : 'NO';
      case 'fedex':
        return (servicio.fedex_extendida) ? 'SI' : 'NO';
      case 'minutes':
        return (servicio.minutes_extendida) ? 'SI' : 'NO';
      case 'dhl':
        return (servicio.dhl_extendida) ? 'SI' : 'NO';
      default:
        return '';
    }
  }

}
