import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'reexpedicion'
})
export class ReexpedicionPipe implements PipeTransform {

  transform(value: any) {
    let precio = 0;
    if(value == 'FEDEX'){
      precio = 190
    }
    if(value ==  'ESTAFETA'){
      precio = 150
    }
    if(value ==  'DHL'){
      precio = 150
    }
    return `Si la cobertura es zona extendida se hara un cobro adicional por MXN $${precio}`;
  }

}
