import { ExtraOptions, Route, RouterModule } from "@angular/router";
import { AuthGuardClientService } from './auth/auth-guard-client.service';
import { AuthRouteService } from './auth/auth-route.service';
import { ROUTES_DASH } from "./components/dashboard/dashboard.routes";
import { HomeComponent } from "./components/home/home.component";
import { NavComponent } from "./components/nav/nav.component";
import { ViewRecuperarComponent } from "./components/view-recuperar/view-recuperar.component";
import { MENU_ROUTES } from "./menu.routing";
import { ApiDocsComponent } from './components/api-docs/api-docs.component';

const routerOptions: ExtraOptions = {
    scrollPositionRestoration: 'enabled',
    anchorScrolling: 'enabled',
    scrollOffset: [0, 64],
};

export const ROUTES: Route[] = [
    {path: 'menu', component: NavComponent, children: MENU_ROUTES},
    { path: 'dashboard', children: ROUTES_DASH },
    { path: 'recuperar/:token', component: ViewRecuperarComponent },
    { path: 'api-docs', component: ApiDocsComponent, canActivate: [AuthGuardClientService, AuthRouteService] },
    {path: '**', pathMatch: 'full', redirectTo: 'menu'},
];

export const APP_ROUTES = RouterModule.forRoot(ROUTES, routerOptions);