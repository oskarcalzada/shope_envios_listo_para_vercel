import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'descripcion'
})
export class DescripcionPipe implements PipeTransform {

  transform(value: any): unknown {



    if(value.descripcion == null && value.referencia == null){
      return (value.id_pago == 1) ? 'RECARGA DE SALDO' : 'PAGO DE CREDITO';
    }
    if(value.descripcion == null && value.referencia != null){
      return value.referencia;
    }
    if(value.descripcion.includes('LTL')){
      return `GUIA ELEC ${value.paqueteria} ${value.tipoP}`;
    }

    if(value.descripcion.includes('GUIA ELEC')){
      return `${value.descripcion}`;
    }
    else{
      return `${value.descripcion} ${value.paqueteria}`;
    }

  }

}
