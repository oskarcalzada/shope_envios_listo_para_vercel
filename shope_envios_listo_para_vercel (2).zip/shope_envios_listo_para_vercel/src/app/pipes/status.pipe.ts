import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'status'
})
export class StatusPipe implements PipeTransform {

  transform(value: unknown, tipo: string): unknown {
    if (tipo == 'pago') {
      switch (value) {
        case 1:
          return 'PAGADO'
        case 0:
          return 'PENDIENTE'
        case 2:
          return 'CANCELADO';
      }
    }else{
      switch (value) {
        case 0:
          return 'Guia generada';
        case 5:
          return 'Guia Cancelada'
      }
    }
    return null;
  }

}
