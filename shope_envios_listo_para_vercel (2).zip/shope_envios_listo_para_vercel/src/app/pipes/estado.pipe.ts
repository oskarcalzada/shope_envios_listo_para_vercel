import { Pipe, PipeTransform } from '@angular/core';
import { estados } from '../classes/estados';

@Pipe({
  name: 'estado'
})
export class EstadoPipe implements PipeTransform {

  transform(value: string): string{
    let resultado = estados.find(elemento => elemento.estado === value);
    return resultado!.aestado;
  }

}
