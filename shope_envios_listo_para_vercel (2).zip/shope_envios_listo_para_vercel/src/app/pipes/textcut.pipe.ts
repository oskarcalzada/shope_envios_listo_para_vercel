import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'textcut'
})
export class TextcutPipe implements PipeTransform {

  transform(value: string, length:number) {

    if(value.length > 30){
      let nuevotexto = value.substr(0, length) + '...';
      return nuevotexto;
    }else{
      return value;
    }

  }

}
