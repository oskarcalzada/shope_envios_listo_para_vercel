import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'imgPaq'
})
export class ImgPaqPipe implements PipeTransform {

  transform(value: string): unknown {
    switch(value){
      case 'ESTAFETA':
        return '../../../assets/img/estafeta.jpg';
        case 'FEDEX':
          return '../../../assets/img/fedex.png';
    }
    return null;
  }

}
