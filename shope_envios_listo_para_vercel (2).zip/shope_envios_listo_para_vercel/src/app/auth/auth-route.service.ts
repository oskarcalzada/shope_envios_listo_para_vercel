import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthRouteService implements CanActivate {

  constructor(public router: Router) { }


  canActivate(): boolean {
    if(!this.isPrincipal()){
      this.router.navigate(['/menu/inicio']);
    }
    return this.isPrincipal();
  }

  isPrincipal(): boolean {
    const token = localStorage.getItem('tokenClient') || '';
    if (token) {
      let parse = this.parseJwt(token);
      if (parse.multi > 0) {
        console.log(parse)
        return false;
      }
      return true;
    } else {
      return false;
    }
  }

  parseJwt(token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
  };

}
