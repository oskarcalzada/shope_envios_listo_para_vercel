import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AuthenticatedService } from './authenticated.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardClientService implements CanActivate {

  constructor(public auth: AuthenticatedService,
    public router: Router) { }

  canActivate(): boolean {
    if(!this.auth.activateClient()){
      this.router.navigate(['/menu/inicio']);
    }
    return this.auth.activateClient();
  }
  
}
