import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { LoginService } from '../services/login.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticatedService {

  constructor(public jwtHelper: JwtHelperService,
    private wsLogin: LoginService,
    private router: Router) { }

  isAuthenticated(): boolean {
    const token = localStorage.getItem('token');
    if (token) {
      if(!this.jwtHelper.isTokenExpired(token)){
        this.wsLogin.refreshTokenUser(token).subscribe((data:any) => {
          if(!data.ok){
            localStorage.removeItem('token');
            return;
          }
          localStorage.setItem('token', data.token);
        })
        return true;
      }
      localStorage.removeItem('token');
      return !this.jwtHelper.isTokenExpired(token);
    }
    localStorage.removeItem('token');
    return false;
  }

  activate(){
    if (!this.isAuthenticated()) {
      localStorage.removeItem('token');
      this.router.navigate(['/dashboard']);
      return false;
    }
    return true;
  }

  isAuthenticatedClient(): boolean{
    const token = localStorage.getItem('tokenClient') || '';
    if(token){
      if(!this.jwtHelper.isTokenExpired(token)){
        this.wsLogin.refreshToken(token).subscribe((data:any) => {
          if(!data.ok){
            localStorage.removeItem('tokenClient');
            return;
          }
          localStorage.setItem('tokenClient', data.token);
        });
        return true;
      }
      return !this.jwtHelper.isTokenExpired(token);
    }
    return false;
  }

  activateClient(){
    if (!this.isAuthenticatedClient()) {
      localStorage.removeItem('tokenClient');
      this.wsLogin.loginClient = false;
      return false;
    }
    this.wsLogin.loginClient = true;
    return true;
  }

}