import { ExtraOptions, Route, RouterModule } from "@angular/router";
import { AuthGuardClientService } from "./auth/auth-guard-client.service";
import { AuthGuardLoginClientService } from "./auth/auth-guard-login-client.service";
import { AuthRouteService } from "./auth/auth-route.service";
import { ApiComponent } from "./components/api/api.component";
import { AvisoPrivacidadComponent } from "./components/aviso-privacidad/aviso-privacidad.component";
import { ContactoComponent } from "./components/contacto/contacto.component";
import { CotizarComponent } from "./components/cotizar/cotizar.component";
import { DireccionesComponent } from "./components/direcciones/direcciones.component";
import { EnviosComponent } from "./components/envios/envios.component";
import { EstadoCuentaComponent } from "./components/estado-cuenta/estado-cuenta.component";
import { HomeComponent } from "./components/home/home.component";
import { InfoAsociadoComponent } from "./components/info-asociado/info-asociado.component";
import { LoginComponent } from "./components/login/login.component";
import { MultiusuariosComponent } from "./components/multiusuarios/multiusuarios.component";
import { NuevoComponent } from "./components/nuevo/nuevo.component";
import { PoliticaUsoComponent } from "./components/politica-uso/politica-uso.component";
import { PreguntasComponent } from "./components/preguntas/preguntas.component";
import { RastreoComponent } from "./components/rastreo/rastreo.component";
import { RecoleccionComponent } from "./components/recoleccion/recoleccion.component";
import { RegistrarComponent } from "./components/registrar/registrar.component";
import { ReportesComponent } from './components/reportes/reportes.component';
import { GuiasPorEstadoComponent } from './components/reportes/guias-por-estado/guias-por-estado.component';
import { GuiasTotalesComponent } from './components/reportes/guias-totales/guias-totales.component';
import { DestinosMasUtilizadosComponent } from './components/reportes/destinos-mas-utilizados/destinos-mas-utilizados.component';
import { RecoleccionesPendientesComponent } from './components/reportes/recolecciones-pendientes/recolecciones-pendientes.component';

const routerOptions: ExtraOptions = {
    scrollPositionRestoration: 'enabled',
    anchorScrolling: 'enabled',
    scrollOffset: [0, 64],
};

export const MENU_ROUTES: Route[] = [
    { path: 'inicio', component: HomeComponent },
    { path: 'registrar', component: RegistrarComponent, canActivate: [AuthGuardLoginClientService] },
    { path: 'login', component: LoginComponent, canActivate: [AuthGuardLoginClientService] },
    { path: 'cotizador', component: CotizarComponent },
    { path: 'envios', component: EnviosComponent, canActivate: [AuthGuardClientService] },
    { path: 'estado-cuenta', component: EstadoCuentaComponent, canActivate: [AuthGuardClientService, AuthRouteService] },
    { path: 'nuevo', component: NuevoComponent, canActivate: [AuthGuardClientService] },
    { path: 'aviso-de-privacidad', component: AvisoPrivacidadComponent },
    { path: 'terminos-y-condiciones', component: PoliticaUsoComponent },
    { path: 'api', component: ApiComponent, canActivate: [AuthGuardClientService, AuthRouteService] },
    { path: 'recolecciones', component: RecoleccionComponent, canActivate: [AuthGuardClientService] },
    { path: 'direcciones', component: DireccionesComponent, canActivate: [AuthGuardClientService] },
    { path: 'rastreo', component: RastreoComponent, canActivate: [AuthGuardClientService] },
    { path: 'info-asociado', component: InfoAsociadoComponent, canActivate: [AuthGuardClientService, AuthRouteService] },
    { path: 'usuarios', component: MultiusuariosComponent, canActivate: [AuthGuardClientService, AuthRouteService] },
    { path: 'reportes', component: ReportesComponent, canActivate: [AuthGuardClientService, AuthRouteService] },
    { path: 'guias-por-estado', component: GuiasPorEstadoComponent, canActivate: [AuthGuardClientService, AuthRouteService] },
    { path: 'guias-totales', component: GuiasTotalesComponent, canActivate: [AuthGuardClientService, AuthRouteService] },
    { path: 'destinos-mas-utilizados', component: DestinosMasUtilizadosComponent, canActivate: [AuthGuardClientService, AuthRouteService] },
    { path: 'recolecciones-pendientes', component: RecoleccionesPendientesComponent, canActivate: [AuthGuardClientService, AuthRouteService] },
    { path: 'contactanos', component: ContactoComponent },
    { path: 'preguntas-frecuentes', component: PreguntasComponent },
    { path: '', redirectTo: '/menu/inicio', pathMatch: 'full' }
];
