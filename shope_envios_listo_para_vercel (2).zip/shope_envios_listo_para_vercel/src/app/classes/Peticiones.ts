import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})

export class Peticiones {

    url: string;

    constructor(private http: HttpClient) {
        // this.url = 'https://app.zaferbev.club';
        this.url = environment.urlBack;
    }

    get(endpoint: string, headers:any) {
        return this.http.get(`${this.url}${endpoint}`, { headers: {...headers},});
    }

    post(endpoint: string, headers: any, body:any) {
        return this.http.post(`${this.url}${endpoint}`, body, { headers: headers });
    }

    put(endpoint: string, headers: any, body:any) {
        return this.http.put(`${this.url}${endpoint}`, body, { headers: headers });
    }

    patch(endpoint: string, headers: any, body:any) {
        return this.http.patch(`${this.url}${endpoint}`, body, { headers: headers });
    }

    delete(endpoint: string, headers: any){
        return this.http.delete(`${this.url}${endpoint}`, {headers: headers})
    }

    file(endpoint: string, headers:any) {
        return this.http.get(`${this.url}${endpoint}`, { headers: {...headers}, responseType: 'blob'});
    }
}