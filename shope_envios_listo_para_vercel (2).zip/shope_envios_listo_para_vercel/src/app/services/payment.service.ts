import { Injectable } from '@angular/core';
import { Peticiones } from '../classes/Peticiones';
import { AuthenticatedService } from '../auth/authenticated.service';
import { map } from 'rxjs/operators';
import { PaymentCard } from '../interfaces/payment';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) { }

    paymentByCard(request: PaymentCard) {
      this.auth.activateClient();
      this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
      return this.app.post(`/pagos/tarjeta`, this.headers, request).pipe(map((data: any) => {
        return data;
      }));
    }

    paymentByCash(request: any){
      this.auth.activateClient();
      this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
      return this.app.post(`/pagos/efectivo`, this.headers, request).pipe(map((data: any) => {
        return data;
      }));
    }

}
