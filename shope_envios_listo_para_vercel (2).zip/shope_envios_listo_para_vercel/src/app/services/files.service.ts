import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FilesService {

  token: string = '';
  headers: any;
  urlBack: string = environment.urlBack;

  constructor(private app:Peticiones,
    private auth:AuthenticatedService) {
    this.token = localStorage.getItem('token') || '';
    this.headers = {
      'Authorization': this.token
    }
  }

  getFormatoConf(){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.file(`/file/servicios/formato`, this.headers);
  }

  getServicios(){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.file(`/file/servicios`, this.headers);
  }

  subirConfiguracion(sendData:any, idasociado:number){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.post(`/file/servicios/${idasociado}`, this.headers, sendData).pipe(map((data:any) => {
      return data;
    }));
  }

  getFormatoGeneracion(paqueteria: string){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient');
    return this.app.file(`/${paqueteria}/file/generacion`, this.headers);
  }

  getCatalogosGeneracion(paqueteria: string){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient');
    return this.app.file(`/${paqueteria}/file/categorias`, this.headers);
  }

  generarGuia(sendData: any, paqueteria: string){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient');
    return this.app.post(`/${paqueteria}/label/file`, this.headers, sendData).pipe(map((data:any) => {
      return data;
    }));
  }

  uploadFileLabel(sendData: any, paqueteria: string){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient');
    return this.app.post(`/${paqueteria}/file/save`, this.headers, sendData).pipe(map((data:any) => {
      return data;
    }));
  }

  getPlugin(plugin: string){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient');
    return this.app.file(`/plugin/${plugin}/file`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  getDocs(plugin: string){
    window.open(`${this.urlBack}/plugin/${plugin}/doc`, '_blank');
  }

}
