import { Injectable } from '@angular/core';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MailService {

  tokenClient: string = '';
  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) {

  }

  contactar(data: any) {
    return this.app.post('/mail/contacto', this.headers, data).pipe(map((data: any) => {
      return data;
    }));
  }
}
