import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class CuentasService {

  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) { }

  getCuentas(pagina:number, cantidad:number, search:string, paqueteria:string) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/cuentas?pagina=${pagina}&cantidad=${cantidad}&search=${search}&paqueteria=${paqueteria.toUpperCase()}`, this.headers)
      .pipe(map((data: any) => {
        return data;
      }));
  }

  newCuenta(data:any, paqueteria:string){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.post(`/cuentas/${paqueteria}`, this.headers, data)
      .pipe(map((data: any) => {
        return data;
      }));
  }

  editCuenta(data:any, paqueteria:string){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.put(`/cuentas/${paqueteria}`, this.headers, data)
      .pipe(map((data: any) => {
        return data;
      }));
  }

  deleteCuenta(idcuenta:number){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.delete(`/cuentas/${idcuenta}?status=0`, this.headers)
      .pipe(map((data: any) => {
        return data;
      }));
  }



}
