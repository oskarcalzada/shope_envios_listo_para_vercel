import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class SatService {

  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) { }

  getEmbalajes() {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/paquete/embalajes`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getProductos(search:string){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/paquete/productos?search=${search}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

}
