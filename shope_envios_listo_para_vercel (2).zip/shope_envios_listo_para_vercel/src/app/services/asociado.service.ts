import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class AsociadoService {

  tokenClient: string = '';
  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) {

  }

  newAsociado(data: any) {
    return this.app.post('/asociado', {}, data).pipe(map((data: any) => {
      return data;
    }));
  }

  searchAsociado(search: string, tipo: string, pagina: number, cantidad: number) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/asociado/search?${tipo}=${search}&pagina=${pagina}&cantidad=${cantidad}`, this.headers)
      .pipe(map((data: any) => {
        return data;
      }));
  }

  activarAsociado(idasociado: number) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/asociado/activar?idasociado=${idasociado}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getAsociado(idasociado: number) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/usuario/asociado?id_asociado=${idasociado}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getAsociadoClient() {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/asociado`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getAsociadosActivos(pagina: number, cantidad: number, search: string) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/asociado/activos?pagina=${pagina}&cantidad=${cantidad}&search=${search}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  setInfoAsociado(data: any) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.put(`/asociado`, this.headers, data).pipe(map((data: any) => {
      return data;
    }));
  }


  setApi(status: number, idasociado: number) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.post(`/asociado/api`, this.headers, { status, idasociado }).pipe(map((data: any) => {
      return data;
    }));
  }

  recuperarPass(email: string) {
    return this.app.post(`/asociado/recuperar`, this.headers, { email }).pipe(map((data: any) => {
      return data;
    }));
  }

  validateToken(token: string) {
    return this.app.get(`/asociado/recuperar/${token}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  resetPass(token: string, pass: string) {
    return this.app.post(`/asociado/reset-pass`, this.headers, { token, pass }).pipe(map((data: any) => {
      return data;
    }));
  }

  enviarSms(telefono: string) {
    return this.app.post(`/nuevo-token`, this.headers, { telefono }).pipe(map(data => data));
  }

  validarCodigo(token: number) {
    return this.app.post(`/validar-token`, this.headers, { token }).pipe(map(data => data));
  }

  validarTelefono() {
    return this.app.get('/validar-telefono', this.headers).pipe(map(data => data));
  }

  getClientesFile() {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.file(`/asociado/exportar`, this.headers);
  }

  setKpis(status: number, idasociado: number) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.patch(`/permisos/kpis`, this.headers, { status, idasociado }).pipe(map((data: any) => {
      return data;
    }));
  }

  setPlugins(status: number, idasociado: number) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.patch(`/permisos/plugins`, this.headers, { status, idasociado }).pipe(map((data: any) => {
      return data;
    }));
  }

  setGenerate(status: number, idasociado: number) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.patch(`/permisos/generacion-file`, this.headers, { status, idasociado }).pipe(map((data: any) => {
      return data;
    }));
  }



}
