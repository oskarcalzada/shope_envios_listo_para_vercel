import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class CreditoService {

  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) { }

  solicitarCredito() {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/credito/solicitud`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getSaldoCredito(){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/credito`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  getSaldoCreditoU(idasociado:number){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/usuario/credito?id_asociado=${idasociado}`, this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  activarCredito(data:any){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.post(`/credito/activar`, this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }

  updateCredito(data:any){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.put(`/credito`, this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }
  

  statusCredito(status:number, idasociado:number){
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.put(`/credito/status?status=${status}&id_asociado=${idasociado}`, this.headers, {}).pipe(map((data:any) => {
      return data;
    }));
  }

}
