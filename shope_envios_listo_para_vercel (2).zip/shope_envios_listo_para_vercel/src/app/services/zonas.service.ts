import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class ZonasService {

  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) { }

  getZonas() {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.get(`/zonas`, this.headers)
      .pipe(map((data: any) => {
        return data;
      }));
  }

  modificarPrecio(idZona: number, precio: number) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    return this.app.put(`/zonas/precio`, this.headers, { idZona, precio })
      .pipe(map((data: any) => {
        return data;
      }));
  }

  cotizarZona(origen: string, destino: string) {
    return this.app.get(`/zonas/cotizar?origen=${origen}&destino=${destino}`, this.headers)
      .pipe(map((data: any) => {
        return data;
      }));
  }

}
