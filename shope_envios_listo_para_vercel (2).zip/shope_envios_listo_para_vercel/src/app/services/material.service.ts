import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class MaterialService {

  headers:any = {}

  constructor(private app:Peticiones,
    private auth:AuthenticatedService) { }

  getMaterial(){
    
    return this.app.get('/material', this.headers).pipe(map((data:any) => {
      return data;
    }));
  }

  sendMaterial(productos:any){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.post('/material/cotizar', this.headers, {productos}).pipe(map((data:any) => {
      return data;
    }));
  }

}
