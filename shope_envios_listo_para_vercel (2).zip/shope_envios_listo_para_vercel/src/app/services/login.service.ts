import { Injectable } from '@angular/core';
import { Peticiones } from '../classes/Peticiones';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  public loginClient: boolean = false;

  constructor(private app: Peticiones, private router:Router) { }

  ingresarUser(user:string, pass:string){
    let data = {user: user, pass: pass};
    let headers = { 
      'Content-Type': 'application/json; charset=utf-8'
     };
    return this.app.post(`/usuario/login`, headers, data).pipe(map((data:any) => {
      return data;
    }));
  }

  guardarSesionUser(data:any){
    if(localStorage.getItem('user')){
      localStorage.removeItem('user');
      localStorage.removeItem('token');
    }
    localStorage.setItem('user', JSON.stringify(data));
    console.log('data', data)
    localStorage.setItem('token' ,data.token);
    this.router.navigate(['/dashboard/menu']);
  }

  refreshTokenUser(token:string){
    let headers = { 
      'Authorization': token
     };
    return this.app.get('/usuario/token', headers).pipe(map((data:any) => {
      return data
    }));
  }

  ingresar(usuario:string, password:string) {
    let data = { usuario, password };
    let headers = {};
    return this.app.post('/asociado/login', headers, data).pipe(map((data: any) => {
      return data;
    }));
  }

  guardarSesion(data:any) {
    if (localStorage.getItem('user')) {
      localStorage.removeItem('userClient');
      localStorage.removeItem('tokenClient');
    }
    localStorage.setItem('userClient', JSON.stringify(data));
    console.log('data', data)
    localStorage.setItem('tokenClient', data.token);
    console.log(data.token);
    if (localStorage.getItem('generacion')) {
      this.router.navigateByUrl('/menu/nuevo');
      return;
    }
    // this.router.navigateByUrl('/menu/cotizador');
    window.location.href = '/menu/cotizador';
  }

  refreshToken(token:string) {
    let headers = {
      'Authorization': token
    };
    return this.app.get('/asociado/token', headers).pipe(map((data: any) => {
      return data;
    }));
  }

  validarRegistro(data?: any, token?: any) {
    return this.app.post(`/asociado/exists?token=${token}`, {}, data).pipe(map((data: any) => {
      return data;
    }));
  }

}
