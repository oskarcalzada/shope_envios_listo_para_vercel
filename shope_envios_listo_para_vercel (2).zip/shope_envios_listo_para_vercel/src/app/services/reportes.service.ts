import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class ReportesService {

  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) {
  }

  getGuiasEstado(inicio, fin) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/reportes?rep_inicio=${inicio}&rep_fin=${fin}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getGuiasEstadoTotal(inicio, fin, estado) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/reportes-total?rep_inicio=${inicio}&rep_fin=${fin}&estado=${estado}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getGuiasPaqueteria(inicio, fin) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/reportes-paqueteria?rep_inicio=${inicio}&rep_fin=${fin}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getGuiasPaqTotal(inicio, fin, estado) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/reportes-paq-total?rep_inicio=${inicio}&rep_fin=${fin}&estado=${estado}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getMejoresDestinos(inicio, fin) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/mejores-destinos?rep_inicio=${inicio}&rep_fin=${fin}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getRecoleccionesPendientes() {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/recolecciones-pendientes`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }
}
