import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AuthenticatedService } from '../auth/authenticated.service';
import { Peticiones } from '../classes/Peticiones';

@Injectable({
  providedIn: 'root'
})
export class EnvioService {

  headers: any = {};

  constructor(private app: Peticiones,
    private auth: AuthenticatedService) { }

  getCp(cp: string) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/cp/${cp}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getDireccion(keyword: string, paqueteria: string) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/direccion/${paqueteria}?keyword=${keyword}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getDisponibles(paqueteria: string) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/servicio/disponibles/${paqueteria}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  nuevoEnvio(data: any, paqueteria:string) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.post(`/${paqueteria}/label`, this.headers, data).pipe(map((data: any) => {
      return data;
    }));
  }

  getHistorial(paqueteria: string, pagina: number, cantidad: number, inicio: string, fin: string) {
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.get(`/historial/${paqueteria}?pagina=${pagina}&cantidad=${cantidad}&fa_inicio=${inicio}&fa_fin=${fin}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  getHistorialUsuario(paqueteria: string, pagina: number, cantidad: number, inicio: string, fin: string, idasociado: number, file: number, tipo:string, tracking:string) {
    this.auth.activate();
    this.headers['Authorization'] = localStorage.getItem('token');
    if(file == 1){
      return this.app.file(`/usuario/historial/${paqueteria}?pagina=${pagina}&cantidad=${cantidad}&fa_inicio=${inicio}&fa_fin=${fin}&idasociado=${idasociado}&file=${file}&type=${tipo}&track=${tracking}`, this.headers);
    }
    return this.app.get(`/usuario/historial/${paqueteria}?pagina=${pagina}&cantidad=${cantidad}&fa_inicio=${inicio}&fa_fin=${fin}&idasociado=${idasociado}&file=${file}&type=${tipo}&track=${tracking}`, this.headers).pipe(map((data: any) => {
      return data;
    }));
  }

  newRecoleccion(data:any, paqueteria:string){
    this.auth.activateClient();
    this.headers['Authorization'] = localStorage.getItem('tokenClient') || '';
    return this.app.post(`/${paqueteria}/recoleccion`, this.headers, data).pipe(map((data:any) => {
      return data;
    }));
  }

}
