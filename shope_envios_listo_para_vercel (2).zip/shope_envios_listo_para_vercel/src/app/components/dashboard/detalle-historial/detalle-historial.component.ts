import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { AsociadoService } from 'src/app/services/asociado.service';
import { EnvioService } from 'src/app/services/envio.service';
import { ServiciosService } from 'src/app/services/servicios.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-detalle-historial',
  templateUrl: './detalle-historial.component.html',
  styleUrls: ['./detalle-historial.component.css']
})
export class DetalleHistorialComponent implements OnInit {

  idasociado: any;
  usuario: string = '';
  paqueteria: string = 'estafeta';
  inicio: string = '';
  fin: string = '';
  loading: boolean = false;
  historial: Array<any> = [];
  urlBack: string = environment.urlBack;
  totalPaginas: number;
  totalRegistros: number = 0;
  cantidad: number = 4;
  paginaActiva: number = 1;
  paginas: any[] = [];
  init: boolean = false;
  error: boolean = false;
  errMsg: string = '';
  paqueterias: Array<any> = [];
  type:string = '1';
  tracking:string = '';

  constructor(private active: ActivatedRoute,
    private wsAsociado: AsociadoService,
    private wsEnvio: EnvioService,
    private wsServicio: ServiciosService) {
    this.active.params.subscribe((param) => {
      this.idasociado = param['id'];
    });
  }

  ngOnInit(): void {
    this.wsAsociado.getAsociado(this.idasociado).subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.usuario = data.data.usuario
    })
  }

  cambiarPaqueteria(paqueteria) {
    this.paqueteria = paqueteria;
  }

  getPaqueterias() {
    this.wsServicio.getPaqueteriasAsociado().subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.paqueterias = data.data;
    })
  }

  verEnvios() {
    this.init = false;
    this.getEnvios(1, this.cantidad);
  }

  exportHistorial() {
    this.getEnvios(1, this.cantidad, 1);
  }

  async getEnvios(pagina: number = 1, cantidad, file = 0) {
    this.historial = [];
    this.loading = true;
    this.error = false;
    let tipo = (this.type == '1') ? 'fecha' : 'track';
    let inicioFormat = moment(this.inicio).format('YYYY-MM-DD');
    let finFormat = moment(this.fin).format('YYYY-MM-DD');
    this.wsEnvio.getHistorialUsuario(this.paqueteria, pagina, cantidad, inicioFormat, finFormat, this.idasociado, file, tipo, this.tracking).subscribe((data: any) => {
      // console.log(data)
      this.loading = false;
      if (file == 1) {
        let a = document.createElement('a');
        document.body.appendChild(a);
        let url = URL.createObjectURL(data);
        a.target = '_self';
        a.download = `Historial${this.paqueteria}_${moment().format('YYYY_MM_DD_HH_mm_ss')}`;
        // window.open(this.UrlFileExport);
        a.href = url;
        a.click();
        return;
      }
      if (!data.ok) {
        this.error = true;
        this.errMsg = data.message;
        this.paginas = [];
        return;
      }
      for (let i in data.data) {
        data.data[i].editar = false;
      }
      this.historial = data.data;
      if (this.init == false) {
        this.init = true;
        this.totalPaginas = Math.ceil(data.total / this.cantidad);
        this.totalRegistros = data.total;
        // console.log(this.totalPaginas)
        this.paginas = [];
        this.paginaActiva = 1;
      } else {
        return;
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if (i > 5) {
          return;
        }
        this.paginas.push(i);
      }
    });
  }

  async verPagina(pagina) {
    if (this.paginaActiva == pagina) {
      return;
    }
    this.paginaActiva = pagina;
    await this.getEnvios(pagina, this.cantidad);
    if (this.totalPaginas <= 5) {
      return;
    }
    this.paginas = [];
    if (pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1) {
      for (let i = pagina - 2; i <= pagina + 2; i++) {
        this.paginas.push(i);
      }
    }
    if (pagina >= 3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1) {
      for (let i = pagina - 3; i <= pagina + 1; i++) {
        this.paginas.push(i);
      }
    }
    if (pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1) {
      for (let i = pagina - 1; i <= pagina + 3; i++) {
        this.paginas.push(i);
      }
    }

    if (pagina == this.totalPaginas && this.totalPaginas > 5) {
      for (let i = pagina - 4; i <= pagina; i++) {
        this.paginas.push(i);
      }
    }

    if (pagina == 1 && this.totalPaginas > 5) {
      for (let i = pagina; i <= pagina + 4; i++) {
        this.paginas.push(i);
      }
    }

  }

}
