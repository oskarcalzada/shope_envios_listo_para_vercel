  
import { Route } from '@angular/router';
import { AuthGuardService } from '../../../auth/auth-guard.service';
import { AsociadosComponent } from '../asociados/asociados.component';
import { CargosComponent } from '../cargos/cargos.component';
import { ComprobantesDashComponent } from '../comprobantes-dash/comprobantes-dash.component';
import { ConfServiciosComponent } from '../conf-servicios/conf-servicios.component';
import { CuentasComponent } from '../cuentas/cuentas.component';
import { DetalleHistorialComponent } from '../detalle-historial/detalle-historial.component';
import { EstadoCuentaDashComponent } from '../estado-cuenta/estado-cuenta.component';
import { HistorialComponent } from '../historial/historial.component';
import { InicioDashComponent } from '../inicio/inicio.component';
import { LtlComponent } from '../ltl/ltl.component';
import { ServiciosComponent } from '../servicios/servicios.component';
import { UsuariosComponent } from '../usuarios/usuarios.component';


export const MENU_ROUTES: Route[] = [
    {path: 'usuarios', component: UsuariosComponent, canActivate: [AuthGuardService]},
    {path: 'servicios', component: ServiciosComponent, canActivate: [AuthGuardService]},
    {path: 'inicio', component: InicioDashComponent, canActivate: [AuthGuardService]},
    // {path: 'info', component: InfoComponent, canActivate: [AuthGuardService]},
    {path: 'clientes', component: AsociadosComponent, canActivate: [AuthGuardService]},
    {path: 'comprobantes', component: ComprobantesDashComponent, canActivate: [AuthGuardService]},
    {path: 'configurar-servicios/:id', component: ConfServiciosComponent, canActivate: [AuthGuardService]},
    {path: 'estado-cuenta/:id', component: EstadoCuentaDashComponent, canActivate: [AuthGuardService]},
    {path: 'historial', component: HistorialComponent, canActivate: [AuthGuardService]},
    {path: 'historial/:id', component: DetalleHistorialComponent, canActivate: [AuthGuardService]},
    {path: 'cuentas', component: CuentasComponent, canActivate: [AuthGuardService]},
    {path: 'ltl', component: LtlComponent, canActivate: [AuthGuardService]},
    {path: 'cargos', component: CargosComponent, canActivate: [AuthGuardService]},
    {path: '', redirectTo: '/dashboard/menu/inicio', pathMatch: 'full'}
];