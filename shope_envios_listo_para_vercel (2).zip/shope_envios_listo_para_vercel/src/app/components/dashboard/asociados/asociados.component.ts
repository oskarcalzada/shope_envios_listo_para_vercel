import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { AsociadoService } from 'src/app/services/asociado.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-asociados',
  templateUrl: './asociados.component.html',
  styleUrls: ['./asociados.component.css']
})
export class AsociadosComponent implements OnInit {

  cantidad:number = 4;
  asociados:any[] = [];
  init:boolean = false;
  totalPaginas: number = 0;
  paginas: any[] = [];
  paginaActiva:number = 1;
  search: string = '';
  tipo: string = '';
  loading:boolean = false;
  loadingFile: boolean = false;

  constructor(private route:Router,
    private wsAsociado:AsociadoService
    ) { }

  ngOnInit(): void {
  }

  buscar(text, tipo){
    this.init = false;
    this.search = text;
    this.tipo = tipo;
    this.getAsociados();
  }

  async getAsociados(pagina = 1) {
    console.log(this.search);
    this.asociados = [];
    this.loading = true;
    this.wsAsociado.searchAsociado(this.search, this.tipo, pagina, this.cantidad).subscribe((data: any) => {
      this.loading = false;
      if (!data.ok) {
        return;
      }
      this.asociados = data.data;
      console.log(this.asociados);
      if(this.init == false){
        this.paginaActiva = 1;
        this.init = true;
        this.totalPaginas = Math.ceil(data.total / this.cantidad);
        console.log(this.totalPaginas)
        this.paginas = [];
      }else{
        return;
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if(i > 5){
          return;
        }
        this.paginas.push(i);
      }
    });
  }

  async verPagina(pagina) {
    if(this.paginaActiva == pagina){
      return;
    }
    this.paginaActiva = pagina;
    await this.getAsociados(pagina);
    if(this.totalPaginas <= 5){
      return;
    }
    this.paginas = [];
    if(pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina-2; i <= pagina + 2; i++){
        this.paginas.push(i);
      }
    }
    if(pagina >=3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1){
      for(let i = pagina - 3; i <= pagina + 1; i++){
        this.paginas.push(i);
      }
    }
    if(pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina - 1; i <= pagina + 3; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == this.totalPaginas && this.totalPaginas > 5){
      for(let i = pagina - 4; i <= pagina; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == 1 && this.totalPaginas > 5){
      for(let i = pagina; i <= pagina + 4; i++){
        this.paginas.push(i);
      }
    }

  }

  conf(id:number){
    this.route.navigate(['/dashboard/menu/configurar-servicios', id]);
  }

  activar(idasociado:number){
    Swal.fire({
      icon: 'info',
      title: 'Al activar el asociado se genera una contraseña ramdom y se notifica al cliente',
      allowOutsideClick: false,
      showDenyButton: true,
      denyButtonText: 'Cancelar',
      confirmButtonText: 'Aceptar',
    }).then((result:any) => {
      if(result.isConfirmed){
        this.wsAsociado.activarAsociado(idasociado).subscribe((data:any) => {
          console.log(data);
          if(!data.ok){
            Swal.fire({
              icon: 'error',
              title: 'No se logro activar al cliente',
              allowOutsideClick: false,
              confirmButtonText: 'Aceptar',
            })
            return;
          }
          Swal.fire({
            icon: 'success',
            title: 'Cliente activado correctamente',
            allowOutsideClick: false,
            confirmButtonText: 'Aceptar',
          });
          let i = this.asociados.findIndex(element => element.id_asociado == idasociado);
          this.asociados[i].activo = 1;
        })
      }
    });
  }

  api(event, idasociado){
    console.log(event.checked);
    let status = event.checked ? 1 : 0;
    this.wsAsociado.setApi(status, idasociado).subscribe((data:any) => {
      if(!data.ok){
        return 
      }
      let i = this.asociados.findIndex(element => element.id_asociado == idasociado);
      this.asociados[i].api = status;
    })
  }

  kpis(event, idasociado){
    console.log(event.checked);
    let status = event.checked ? 1 : 0;
    this.wsAsociado.setKpis(status, idasociado).subscribe((data:any) => {
      if(!data.ok){
        return 
      }
      let i = this.asociados.findIndex(element => element.id_asociado == idasociado);
      this.asociados[i].kpis = status;
    })
  }

  plugin(event, idasociado){
    console.log(event.checked);
    let status = event.checked ? 1 : 0;
    this.wsAsociado.setPlugins(status, idasociado).subscribe((data:any) => {
      if(!data.ok){
        return 
      }
      let i = this.asociados.findIndex(element => element.id_asociado == idasociado);
      this.asociados[i].plugins = status;
    })
  }

  generate(event, idasociado){
    console.log(event.checked);
    let status = event.checked ? 1 : 0;
    this.wsAsociado.setGenerate(status, idasociado).subscribe((data:any) => {
      if(!data.ok){
        return; 
      }
      let i = this.asociados.findIndex(element => element.id_asociado == idasociado);
      this.asociados[i].generacion_file = status;
    })
  }

  getClientesFile(){
    this.loadingFile = true;
    this.wsAsociado.getClientesFile().subscribe((data:any) => {
      this.loadingFile = false;
      let a = document.createElement('a');
      document.body.appendChild(a);
      let url = URL.createObjectURL(data);
      a.target = '_self';
      a.download = `clientes_${moment().format('YYYYMMDDHHmmss')}`;
      a.href = url;
      a.click();
    });
  }

}
