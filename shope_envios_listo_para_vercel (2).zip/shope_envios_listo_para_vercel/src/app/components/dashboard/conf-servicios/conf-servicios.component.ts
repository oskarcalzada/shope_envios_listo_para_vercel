import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServiciosService } from 'src/app/services/servicios.service';
import * as moment from 'moment';
import { CuentasService } from 'src/app/services/cuentas.service';
import { MatDialog } from '@angular/material/dialog';
import { SubirConfiguracionComponent } from '../../dialogs/subir-configuracion/subir-configuracion.component';

@Component({
  selector: 'app-conf-servicios',
  templateUrl: './conf-servicios.component.html',
  styleUrls: ['./conf-servicios.component.css']
})
export class ConfServiciosComponent implements OnInit {

  servicios:any[] = [];
  serviciosC:any[] = [];
  aux:any = null;
  idasociado:number;
  loading:boolean = false;
  cuentas:any;

  constructor(private wsServicios: ServiciosService,
    private activate:ActivatedRoute,
    private wsCuenta: CuentasService,
    private dialog: MatDialog) { 
      this.activate.params.subscribe((params) => {
        console.log(params);
        this.idasociado = params['id'];
      })
    }

  ngOnInit() {
    this.getServicios();
    this.getServiciosCustom();
  }

  getServicios(){
    this.wsServicios.getAllServicios().subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      this.servicios = data.data;
      // console.log(this.servicios)
    });
  }

  getServiciosCustom(){
    this.wsServicios.getServiceCustom(this.idasociado).subscribe((data:any) => {
      // console.log(data);
      if(!data.ok){
        return;
      }
      this.serviciosC = data.data;
    });
  }

  select(serv){
    console.log('cambio', serv)

    this.aux = this.servicios.find(element => element.id_servicio == serv);
    this.wsCuenta.getCuentas(1, 10000, '', this.aux.paqueteria).subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      this.cuentas = data.data;
    });
    // console.log(this.aux)
  }

  agregarServ(precio, fecha, idcuenta){
    fecha = moment(fecha, "DD/MM/YYYY");
    console.log(this.aux, precio, fecha);
    let sendData = {
      idasociado: this.idasociado,
      id_servicio: this.aux.id_servicio,
      precio,
      fecha: moment(fecha).format('YYYY-MM-DD'),
      idcuenta
    }
    this.loading = true;
    this.wsServicios.setServiceCustom(sendData).subscribe((data:any) => {
      this.loading = false;
      console.log(data);
      if(!data.ok){
        return;
      }
      this.getServiciosCustom();
    });
  }

  deleteServicio(idservicio){
    this.wsServicios.deleteServicio(this.idasociado, idservicio).subscribe((data:any) => {
      if(!data.ok){
        return
      }
      this.getServiciosCustom();
    });
  }

  abrirConfiguracion(){
    const dialogRef = this.dialog.open(SubirConfiguracionComponent, {
      width: '800px',
      data: {
        idasociado: this.idasociado
      }
    });

    dialogRef.afterClosed().subscribe((data:any) => {
      this.getServiciosCustom();
    });
  }

}
