import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CuentasService } from 'src/app/services/cuentas.service';
import { EditCuentaComponent } from '../../dialogs/edit-cuenta/edit-cuenta.component';

@Component({
  selector: 'app-cuentas',
  templateUrl: './cuentas.component.html',
  styleUrls: ['./cuentas.component.css']
})
export class CuentasComponent implements OnInit {

  paqueteria:string = 'estafeta';
  carga:boolean = false;
  cuentas: any[] = [];
  totalPaginas: number;
  cantidad: number = 4;
  paginaActiva: number = 1;
  paginas: any[] = [];
  search: string = '';
  init: boolean = false;
  loading: boolean = false;
  editar: boolean = false;
  timer:any;

  constructor(private wsCuenta: CuentasService,
    private dialog: MatDialog) { }

  ngOnInit(): void {
    this.cambiarPaqueteria('estafeta')
  }

  cambiarPaqueteria(paqueteria){
    this.paqueteria = paqueteria;
    this.carga = true;
    this.init = false;
    this.getCuentas(1, '');
  }

  async getCuentas(pagina: number = 1, search: string = '') {
    this.cuentas = [];
    this.wsCuenta.getCuentas(pagina, this.cantidad, search, this.paqueteria).subscribe((data: any) => {
      console.log(data);
      if (!data.ok) {
        return;
      }
      for(let i in data.data){
        data.data[i].editar = false;
      }
      this.cuentas = data.data;
      if(this.init == false){
        this.init = true;
        this.totalPaginas = Math.ceil(data.total / this.cantidad);
        console.log(this.totalPaginas)
        this.paginas = [];
      }else{
        return;
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if(i > 5){
          return;
        }
        this.paginas.push(i);
      }
    });
  }

  async verPagina(pagina) {
    if(this.paginaActiva == pagina){
      return;
    }
    this.paginaActiva = pagina;
    await this.getCuentas(pagina, this.search);
    if(this.totalPaginas <= 5){
      return;
    }
    this.paginas = [];
    if(pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina-2; i <= pagina + 2; i++){
        this.paginas.push(i);
      }
    }
    if(pagina >=3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1){
      for(let i = pagina - 3; i <= pagina + 1; i++){
        this.paginas.push(i);
      }
    }
    if(pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina - 1; i <= pagina + 3; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == this.totalPaginas && this.totalPaginas > 5){
      for(let i = pagina - 4; i <= pagina; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == 1 && this.totalPaginas > 5){
      for(let i = pagina; i <= pagina + 4; i++){
        this.paginas.push(i);
      }
    }

  }

  nuevaCuenta(){
    const dialogRef = this.dialog.open(EditCuentaComponent, {
      width: '800px',
      data: {
        cuenta: {},
        paqueteria: this.paqueteria,
        tipo: 'nuevo'
      }
    });

    dialogRef.afterClosed().subscribe((data:any) => {
      if(data === undefined){
        return;
      }
      if(!data.ok){
        return;
      }
      this.init = false;
      this.getCuentas(1);
    });

  }

  editCuenta(item){
    const dialogRef = this.dialog.open(EditCuentaComponent, {
      width: '800px',
      data: {
        cuenta: item,
        paqueteria: this.paqueteria,
        tipo: 'editar'
      }
    });

    dialogRef.afterClosed().subscribe((data:any) => {
      if(data === undefined){
        return;
      }
      if(!data.ok){
        return;
      }
      let index = this.cuentas.findIndex(element => element.id_cuenta == item.id_cuenta);
      this.cuentas[index] = data.data;
    });
  }

  deleteCuenta(id:number){
    this.wsCuenta.deleteCuenta(id).subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      let index = this.cuentas.findIndex(element => element.id_cuenta == id);
      this.cuentas.splice(index, 1);
    })
  }


}
