import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UserService } from 'src/app/services/user.service';
import { SetUsuarioComponent } from '../../dialogs/set-usuario/set-usuario.component';

@Component({
  selector: 'app-usuarios',
  templateUrl: './usuarios.component.html',
  styleUrls: ['./usuarios.component.css']
})
export class UsuariosComponent implements OnInit {

  users: any[] = [];
  totalPaginas: number;
  cantidad: number = 4;
  paginaActiva: number = 1;
  paginas: any[] = [];
  search: string = '';
  init: boolean = false;
  isChecked: boolean;
  timer:any;
  
  constructor(private wsUsers:UserService,
    private dialog: MatDialog) { }

  ngOnInit() {
    this.getUsers(1, this.cantidad);
  }

  searchUser(){
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      // this.timer = 
      this.init = false;
      this.getUsers(1, this.cantidad, this.search);
    }, 500);
  }

  async getUsers(pagina: number = 1, cantidad, search: string = '') {
    this.users = [];
    this.wsUsers.getUsers(pagina, cantidad, search).subscribe((data: any) => {
      console.log(data)
      if (!data.ok) {
        return;
      }
      this.users = data.data;
      if(this.init == false){
        this.init = true;
        this.totalPaginas = Math.ceil(data.total / this.cantidad);
        console.log(this.totalPaginas)
        this.paginaActiva = 1;
        this.paginas = [];
      }else{
        return;
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if(i > 5){
          return;
        }
        this.paginas.push(i);
      }
    });
  }

  async verPagina(pagina) {
    if(this.paginaActiva == pagina){
      return;
    }
    this.paginaActiva = pagina;
    await this.getUsers(pagina, this.cantidad, this.search);
    if(this.totalPaginas <= 5){
      return;
    }
    this.paginas = [];
    if(pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina-2; i <= pagina + 2; i++){
        this.paginas.push(i);
      }
    }
    if(pagina >=3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1){
      for(let i = pagina - 3; i <= pagina + 1; i++){
        this.paginas.push(i);
      }
    }
    if(pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina - 1; i <= pagina + 3; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == this.totalPaginas && this.totalPaginas > 5){
      for(let i = pagina - 4; i <= pagina; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == 1 && this.totalPaginas > 5){
      for(let i = pagina; i <= pagina + 4; i++){
        this.paginas.push(i);
      }
    }

  }

  newUsuario(){
    const dialogRef = this.dialog.open(SetUsuarioComponent, {
      width: '800px',
      data: {
        view: 'newUsuario',
      }
    });

    dialogRef.afterClosed().subscribe(result => {

    });
  }

  editUsuario(user:any){
    const dialogRef = this.dialog.open(SetUsuarioComponent, {
      width: '800px',
      data: {
        view: 'editUsuario',
        user
      }
    });

    dialogRef.afterClosed().subscribe((data:any) => {
      if(data.username){
        this.getUsers(this.paginaActiva, this.cantidad, this.search)
      }
    });
  }

  status(event, idusuario){
    let activo = (event.checked) ? 1 : 0;
    this.wsUsers.status(idusuario, activo).subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      let i = this.users.findIndex(element => element.id_usuario == idusuario);
      this.users[i].activo = activo;
    })
  }

}
