import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ZonasService } from 'src/app/services/zonas.service';
import Swal from 'sweetalert2';
import { PruebaCotizadorComponent } from '../../dialogs/prueba-cotizador/prueba-cotizador.component';

@Component({
  selector: 'app-ltl',
  templateUrl: './ltl.component.html',
  styleUrls: ['./ltl.component.css']
})
export class LtlComponent implements OnInit {

  zonas: Array<any>;
  loading: boolean = false;

  constructor(private wsZona: ZonasService,
    private dialog: MatDialog) { }

  ngOnInit(): void {
    this.getZonas();
  }

  getZonas() {
    this.wsZona.getZonas().subscribe((data: any) => {
      this.loading = true;
      if (!data.ok) {
        return;
      }
      this.zonas = data.data;
    });
  }

  modificar(idZona: number, precio: any) {
    if (precio == "" || precio == 0) {
      Swal.fire({
        icon: 'error',
        title: 'El precio no es valido'
      });
      return;
    }
    this.wsZona.modificarPrecio(idZona, precio).subscribe((data: any) => {
      if (!data.ok) {
        Swal.fire({
          icon: 'error',
          title: data.message
        })
        return;
      }
      Swal.fire({
        icon: 'success',
        title: 'El precio se modifico correctamente'
      })
    });
  }

  abrirPrueba(){
    const dialogRef = this.dialog.open(PruebaCotizadorComponent, {
      width: '600px'
    })
  }

}
