  
import { Route } from '@angular/router';
import { LoginUserComponent } from './login-user/login-user.component';
import { MenuComponent } from './menu/menu.component';
import { AuthGuardLoginService } from 'src/app/auth/auth-guard-login.service';
import { MENU_ROUTES } from './menu/menu.routes';
import { AuthGuardService } from 'src/app/auth/auth-guard.service';



export const ROUTES_DASH: Route[] = [
    { path: 'login', component: LoginUserComponent, canActivate: [AuthGuardLoginService] },
    { path: 'menu', component: MenuComponent, children: MENU_ROUTES, canActivate: [AuthGuardService]},
    { path: '**', redirectTo: 'login', pathMatch: 'full' }
];