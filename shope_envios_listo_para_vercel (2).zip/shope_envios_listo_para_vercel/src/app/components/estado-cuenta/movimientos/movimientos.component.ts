import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CotizadorService } from 'src/app/services/cotizador.service';
import { ComprobanteComponent } from '../../dialogs/comprobante/comprobante.component';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';

@Component({
  selector: 'app-movimientos',
  templateUrl: './movimientos.component.html',
  styleUrls: ['./movimientos.component.css']
})
export class MovimientosComponent implements OnInit, OnChanges {

  loading:boolean = false;
  movimientos:Array<any> = [];
  totalPaginas: number;
  totalRegistros:number = 0;
  cantidad: number = 4;
  paginaActiva: number = 1;
  paginas: any[] = [];
  init: boolean = false;
  error: boolean = false;
  errMsg:string = '';

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';

  @Input() nuevoPedido:number = 0;

  constructor(private wsCotizador: CotizadorService,
    private dialog:MatDialog,
    private toastCtrl: MatSnackBar) { }

  ngOnInit(): void {
    this.getMovimientos(1, this.cantidad);
  }

  ngOnChanges(){
    this.getMovimientos(1, this.cantidad);
  }


  async getMovimientos(pagina: number = 1, cantidad) {
    this.movimientos = [];
    this.loading = true;
    this.error = false;
    this.wsCotizador.getMovimientos(pagina, cantidad).subscribe((data: any) => {
      console.log(data)
      this.loading = false;
      if (!data.ok) {
        this.error = true;
        this.errMsg = data.message;
        this.paginas = [];
        return;
      }
      for(let i in data.data){
        data.data[i].editar = false;
      }
      this.movimientos = data.data;
      if(this.init == false){
        this.init = true;
        this.totalPaginas = Math.ceil(data.total / this.cantidad);
        this.totalRegistros = data.total;
        console.log(this.totalPaginas)
        this.paginas = [];
        this.paginaActiva = 1;
      }else{
        return;
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if(i > 5){
          return;
        }
        this.paginas.push(i);
      }
    });
  }

  async verPagina(pagina) {
    if(this.paginaActiva == pagina){
      return;
    }
    this.paginaActiva = pagina;
    await this.getMovimientos(pagina, this.cantidad);
    if(this.totalPaginas <= 5){
      return;
    }
    this.paginas = [];
    if(pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina-2; i <= pagina + 2; i++){
        this.paginas.push(i);
      }
    }
    if(pagina >=3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1){
      for(let i = pagina - 3; i <= pagina + 1; i++){
        this.paginas.push(i);
      }
    }
    if(pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina - 1; i <= pagina + 3; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == this.totalPaginas && this.totalPaginas > 5){
      for(let i = pagina - 4; i <= pagina; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == 1 && this.totalPaginas > 5){
      for(let i = pagina; i <= pagina + 4; i++){
        this.paginas.push(i);
      }
    }

  }

  enviarComprobante(id_estado:number){
    const dialogRef = this.dialog.open(ComprobanteComponent, {
      width: '800px',
      data: {
        id: id_estado
      }
    });
    
    dialogRef.afterClosed().subscribe((data:any) => {
      if(!data.ok){
        return;
      }
      let i = this.movimientos.findIndex(element => element.id_estado == id_estado);
      this.movimientos[i].id_comprobante = data.id;
      this.movimientos[i].status_com = 'PENDIENTE';
      this.msgToast('El comprobante se envio correctamente');
    });
    
  }

  msgToast(message:string){
    this.toastCtrl.open(message, 'Ok', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 7000
    });
  }

  verReferencia(link: string){
    window.open(link, '_blank')
  }

}
