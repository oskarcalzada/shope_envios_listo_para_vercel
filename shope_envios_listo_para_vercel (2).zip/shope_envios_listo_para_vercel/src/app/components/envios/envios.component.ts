import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { EnvioService } from 'src/app/services/envio.service';
import { ServiciosService } from 'src/app/services/servicios.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-envios',
  templateUrl: './envios.component.html',
  styleUrls: ['./envios.component.css']
})
export class EnviosComponent implements OnInit {

  paqueteria:string = 'estafeta';
  inicio: string = '';
  fin: string = '';
  loading:boolean = false;
  historial:Array<any> = [];
  urlBack:string = environment.urlBack;
  totalPaginas: number;
  totalRegistros:number = 0;
  cantidad: number = 4;
  paginaActiva: number = 1;
  paginas: any[] = [];
  init: boolean = false;
  error: boolean = false;
  errMsg:string = '';
  paqueterias:Array<any> = [];

  constructor(private wsEnvio: EnvioService,
    private wsServicio: ServiciosService) { }

  ngOnInit(): void {
    this.getPaqueterias();
  }

  cambiarPaqueteria(paqueteria:string){
    this.paqueteria = paqueteria;
  }

  getPaqueterias(){
    this.wsServicio.getPaqueteriasAsociado().subscribe((data:any) => {
      if(!data.ok){ 
        return;
      } 
      this.paqueterias = data.data;
    })
  }

  verEnvios(){
    this.getEnvios(1, this.cantidad);
  }

  async getEnvios(pagina: number = 1, cantidad) {
    this.historial = [];
    this.loading = true;
    this.error = false;
    let inicioFormat = moment(this.inicio).format('YYYY-MM-DD');
    let finFormat = moment(this.fin).format('YYYY-MM-DD');
    this.wsEnvio.getHistorial(this.paqueteria, pagina, cantidad, inicioFormat, finFormat).subscribe((data: any) => {
      console.log(data)
      this.loading = false;
      if (!data.ok) {
        this.error = true;
        this.errMsg = data.message;
        this.paginas = [];
        return;
      }
      for(let i in data.data){
        data.data[i].editar = false;
      }
      this.historial = data.data;
      if(this.init == false){
        this.init = true;
        this.totalPaginas = Math.ceil(data.total / this.cantidad);
        this.totalRegistros = data.total;
        console.log(this.totalPaginas)
        this.paginas = [];
        this.paginaActiva = 1;
      }else{
        return;
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if(i > 5){
          return;
        }
        this.paginas.push(i);
      }
    });
  }

  async verPagina(pagina) {
    if(this.paginaActiva == pagina){
      return;
    }
    this.paginaActiva = pagina;
    await this.getEnvios(pagina, this.cantidad);
    if(this.totalPaginas <= 5){
      return;
    }
    this.paginas = [];
    if(pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina-2; i <= pagina + 2; i++){
        this.paginas.push(i);
      }
    }
    if(pagina >=3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1){
      for(let i = pagina - 3; i <= pagina + 1; i++){
        this.paginas.push(i);
      }
    }
    if(pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina - 1; i <= pagina + 3; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == this.totalPaginas && this.totalPaginas > 5){
      for(let i = pagina - 4; i <= pagina; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == 1 && this.totalPaginas > 5){
      for(let i = pagina; i <= pagina + 4; i++){
        this.paginas.push(i);
      }
    }

  }

}
