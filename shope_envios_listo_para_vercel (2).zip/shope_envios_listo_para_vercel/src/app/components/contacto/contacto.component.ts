import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MailService } from 'src/app/services/mail.service';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {

  forma:FormGroup;
  isLoading: boolean = false;
  msgOk: string = '';

  constructor(private wsMail: MailService) {
    this.forma = new FormGroup({
      nombre: new FormControl('',[Validators.required, Validators.maxLength(50)]),
      email: new FormControl('',[Validators.required, Validators.email]),
      comentario: new FormControl('',[Validators.required, Validators.maxLength(250)]),
    })
  }

  ngOnInit(): void {
  }

  enviarDatos(){
      this.isLoading = true;
      console.log(this.forma.value)
      this.wsMail.contactar(this.forma.value).subscribe((data:any) => {
        this.isLoading = false;
        if(!data.ok){
          return;
        }
        this.forma.reset();
        this.msgOk = data.message;
      });
  }

}
