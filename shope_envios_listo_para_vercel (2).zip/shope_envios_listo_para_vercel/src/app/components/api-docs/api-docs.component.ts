import { MediaMatcher } from '@angular/cdk/layout';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { share } from 'rxjs/operators';
import { AuthenticatedService } from 'src/app/auth/authenticated.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-api-docs',
  templateUrl: './api-docs.component.html',
  styleUrls: ['./api-docs.component.css']
})
export class ApiDocsComponent implements OnInit {

  mobileQuery: MediaQueryList;
  activeFragment = this.route.fragment.pipe(share());

  private _mobileQueryListener: () => void;
  user: any;
  options: string = '';
  options2: string = '';
  public active_fragment: BehaviorSubject<string> = new BehaviorSubject('');
  private fragment: string;

  constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher,
    public wsLogin: LoginService,
    private auth: AuthenticatedService,
    private route: ActivatedRoute) {
    this.mobileQuery = media.matchMedia('(max-width: 980px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    if (this.auth.activateClient()) {
      this.user = JSON.parse(localStorage.getItem('userClient') || '');
    }
    this.route.fragment.subscribe((frag) => {
      this.active_fragment.next(frag);
      this.fragment = frag;
    });
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    try {
      document.querySelector('#' + this.fragment).scrollIntoView();
    } catch (e) { }
  }

  resInformacion() {
    return {
      ok: true,
      data: {
        nombre: 'Name and last name',
        email: 'email@domain.com',
        usuario: 'user',
        saldo: 1212,
        credito: 1212,
      }
    }
  }

  resDisponibles() {
    return {
      ok: true,
      data: [
        {
          id_servicio: 1,
          paqueteria: "ESTAFETA",
          tipo: "TERRESTRE",
          peso: 1,
          cantidad: "26",
          usadas: "23",
          disponibles: "3"
        },
      ]
    }
  }

  resHistorial() {
    return {
      ok: true,
      total: 17,
      data: [
        {
          id_historial: 20,
          id_asociado: 1,
          remitente: "Name",
          destinatario: "Name",
          tracking: "3005895019595702064080",
          peso: 1,
          id_servicio: 1,
          alto: 10,
          largo: 10,
          ancho: 10,
          seguro: 0,
          status: 0,
          fecha: "2021-06-06T02:54:59.000Z",
          descripcion: "GUIA ELECTRONICA",
          paqueteria: "ESTAFETA",
          tipo: "TERRESTRE"
        }
      ]
    }
  }

  bodyLabel() {
    return {
      servicio: {
        tipo: "TERRESTRE",
        guia: "1"
      },
      remitente: {
        nombre: "Nombre Remitente",
        compania: "Compania Remitente",
        calle: "Calle con numero",
        colonia: "colonia",
        ciudad: "ciudad - municipio o delegación",
        estado: "codigo de 3 digitos",
        telefono: "telefono sin lada",
        cp: "00000",
        nave: "NA999",
        plataforma: "P199",
        email: "aaa@aaa.com (solo 99 minutos)"
      },
      destinatario: {
        nombre: "Nombre Destinatario",
        compania: "Compania Destinatario",
        calle: "Calle con numero",
        colonia: "Colonia",
        ciudad: "Ciudad - municipio o delegación",
        estado: "codigo 3 digitos",
        telefono: "telefono sin lada",
        cp: "00000",
        nave: "NA999",
        plataforma: "P199",
        email: "aaa@aaa.com (solo 99 minutos)"
      },
      paquete: {
        alto: "10",
        ancho: "10",
        largo: "10",
        peso: "1",
        contenido: "contenido de paquete",
        idEmbalaje: "5L3",
        idProducto: "44111507",
        valor: "1540",
        cantidad: "4",
        cantidadPaq: "2"
      },
      adicional: {
        papel: "1",
        recoleccion: "2022-02-01T08:00:00 (solo 99 minutos)"
      }
    }
  }

  resLabel() {
    return {
      ok: true,
      data: {
        tracking: "1055895019595702064087",
        label: "https://app.shopeenvios.com/{paqueteria}/label/1055895019595702064087"
      }
    }
  }

  resTracking() {
    return {
      ok: true,
      data: {
        tracking: "280216546448",
        ultimo_evento: "Shipment information sent to FedEx",
        fecha_ultimo_evento: "2021-06-09T05:00:00.000Z",
        tipo_servicio: "FedEx Nacional Economico",
        paquete: {
          peso: {
            value: 5,
            unidades: "KG"
          },
          dimensiones: {
            largo: "33",
            ancho: "23",
            alto: "13",
            unidades: "CM"
          }
        },
        remitente: {
          ciudad: "SANTIAGO YUCUYACHI",
          estado: "OA",
          pais: "Mexico"
        },
        destinatario: {
          ciudad: "MONTERREY",
          estado: "NL",
          pais: "Mexico"
        },
        eventos: [
          {
            fecha: "2021-06-10T00:11:29.000Z",
            descripcion: "Shipment information sent to FedEx"
          }
        ]
      }

    }
  }

  resCobertura() {
    return {
      ok: true,
      data: {
        zona_extendida: false,
        servicios_disponibles: [
          "TERRESTRE",
          "DIA SIG"
        ],
        ocurre: "No"
      }
    }
  }

}
