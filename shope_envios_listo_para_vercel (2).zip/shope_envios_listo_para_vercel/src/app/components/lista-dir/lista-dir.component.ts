import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EditarDireccionesComponent } from '../dialogs/editar-direcciones/editar-direcciones.component'
import { ServiciosService } from 'src/app/services/servicios.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-lista-dir',
  templateUrl: './lista-dir.component.html',
  styleUrls: ['./lista-dir.component.css']
})
export class ListaDirComponent implements OnInit, OnChanges {

  direcciones:Array<any>=[];
  inicio: string = '';
  fin: string = '';
  totalPaginas: number;
  totalRegistros:number = 0;
  loading:boolean = false;
  historial:Array<any> = [];
  paginaActiva: number = 1;
  paginas: any[] = [];
  cantidad: number = 5;
  @Input() recarga:number = 0;
  init: boolean = false;

  constructor(public dialog: MatDialog,private wsServicio: ServiciosService) {
   
  }

  ngOnInit(): void {
     this.allDirecciones(1,this.cantidad);
  }

  ngOnChanges(){
    this.init=false
    this.allDirecciones(1,this.cantidad);
    // console.log("a qui entro el cmabio");
  }



  verDir(id:number){
    this.wsServicio.getDireccionesIdDir(id).subscribe((data:any)=>{
      if (!data.ok) {
        return
      }else{
        console.log(data.data);
        this.openDialog(data.data);
      }
    })
  }
  openDialog(dir:any){
    const dialogRef = this.dialog.open(EditarDireccionesComponent, {
      width: '1000px',
      data: {
        dir
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(result.msg);
     if (result.msg == "Registro Actualizado" || result.msg == "Registro eliminado" ) {
      Swal.fire({
        icon: 'success',
        title: result.msg,
        showConfirmButton: false,
        timer: 2500
        
      })
      this.init=false; 
      this.allDirecciones(this.paginaActiva,this.cantidad);
     }
        
        
     
    });
  }  
  
  allDirecciones(pagina:number =1,cantidad){
    this.direcciones = [];

    this.wsServicio.getDirecciones(pagina,cantidad).subscribe((data:any) => {
      console.log(data.total.total)
      this.loading = false;
      if(!data.ok){
        this.paginas = [];
        return;
      }
      this.direcciones=data.data
      if (this.init ==false) {
        this.init = true;
        this.totalPaginas = Math.ceil(data.total.total / this.cantidad);
        this.totalRegistros = data.total.total;
        console.log(this.totalPaginas)
        this.paginas = [];
        this.paginaActiva = 1;
      }else{
        return
      }
      for (let i = 1; i <= this.totalPaginas; i++) {
        if(i > 5){
          return;
        }
        this.paginas.push(i);
      }
    });
  }    
  
  async verPagina(pagina) {
    if(this.paginaActiva == pagina){
      return;
    }
    this.paginaActiva = pagina;
    await this.allDirecciones(pagina, this.cantidad);
    if(this.totalPaginas <= 5){
      return;
    }
    this.paginas = [];
    if(pagina >= 3 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina-2; i <= pagina + 2; i++){
        this.paginas.push(i);
      }
    }
    if(pagina >=3 && this.totalPaginas > 5 && pagina == this.totalPaginas - 1){
      for(let i = pagina - 3; i <= pagina + 1; i++){
        this.paginas.push(i);
      }
    }
    if(pagina == 2 && this.totalPaginas > 5 && pagina < this.totalPaginas - 1){
      for(let i = pagina - 1; i <= pagina + 3; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == this.totalPaginas && this.totalPaginas > 5){
      for(let i = pagina - 4; i <= pagina; i++){
        this.paginas.push(i);
      }
    }

    if(pagina == 1 && this.totalPaginas > 5){
      for(let i = pagina; i <= pagina + 4; i++){
        this.paginas.push(i);
      }
    }

  }
  onlyDireccion(idDir){
    const dialogRef = this.dialog.open(EditarDireccionesComponent, {
      data: {
        idDir
      }
        

    });
  }
  }


