import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-direcciones',
  templateUrl: './direcciones.component.html',
  styleUrls: ['./direcciones.component.css']
})
export class DireccionesComponent implements OnInit {

  tipo: string
  recarga: number = 0;
  constructor() { }

  ngOnInit(): void {


  }
  dir() {

    console.log("click en mat label");

  }

  recargarTabla(event: any) {
    if (event.ok) {
      this.recarga += 1;
    }
  }

}
