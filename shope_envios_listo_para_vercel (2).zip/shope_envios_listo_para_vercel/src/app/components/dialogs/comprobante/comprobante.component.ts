import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CotizadorService } from 'src/app/services/cotizador.service';

@Component({
  selector: 'app-comprobante',
  templateUrl: './comprobante.component.html',
  styleUrls: ['./comprobante.component.css']
})
export class ComprobanteComponent implements OnInit {

  estaSobreElemento:boolean = false;
  archivos: File | null = null;
  preview:any;
  errMsg:string = '';

  constructor(private dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private wsCotizador: CotizadorService) { }

  ngOnInit(): void {
  }

  cerrar(){
    this.dialogRef.close({ok:false});
  }

  enviar(){
    let formData = new FormData();
    formData.append('id_estado', this.data.id);
    formData.append('comprobante', this.archivos!);
    this.errMsg = '';
    this.wsCotizador.sendComprobante(formData).subscribe((data:any) => {
      console.log(data);
      if(!data.ok){
        this.errMsg = data.message;
        return;
      }
      this.dialogRef.close({ok: true, id: data.data.id_comprobante});
    })
  }

  sobre(event:any){
    console.log(event)
    this.estaSobreElemento = event.ok;
    if(event.file){
      this.archivos = event.file;
      const blob = new Blob([this.archivos!], {type: this.archivos!.type});
      console.log(blob);
      this.preview = URL.createObjectURL(blob);
    }
  }

  borrarImg(){
    this.archivos = null;
  }

}
