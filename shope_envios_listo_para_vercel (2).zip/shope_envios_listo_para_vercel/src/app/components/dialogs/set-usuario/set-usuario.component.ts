import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { UserService } from 'src/app/services/user.service';

interface ErrorValidate{
  [s: string]: boolean
}

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-set-usuario',
  templateUrl: './set-usuario.component.html',
  styleUrls: ['./set-usuario.component.css']
})
export class SetUsuarioComponent implements OnInit {

  estaSobreElemento:boolean = false;
  archivos: File;
  preview:any;
  forma: FormGroup;
  matcher = new MyErrorStateMatcher();
  error:boolean = false;
  msgError:string;
  isEditIn:boolean = false;
  perfiles:any[];

  constructor(public dialogRef: MatDialogRef<SetUsuarioComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private wsUser: UserService) {
      this.getPerfiles()
  }

  ngOnInit() {
    console.log(this.data);
    this.forma = new FormGroup({
      'nombre': new FormControl('', Validators.required),
      'user': new FormControl('', Validators.required, this.validarUserName.bind(this)),
      'email': new FormControl('', [Validators.required, Validators.email]),
      'emailR': new FormControl(''),
      'pass': new FormControl('', Validators.required),
      'passR': new FormControl(''),
      'telefono': new FormControl('', Validators.required),
      'role': new FormControl('', Validators.required)
    });

    if(this.data.view == 'editUsuario'){
      this.forma.get('nombre').setValue(this.data.user.nombre);
      this.forma.get('user').setValue(this.data.user.usuario);
      this.forma.get('user').disable();
      this.forma.get('email').setValue(this.data.user.email);
      this.forma.get('emailR').setValue(this.data.user.email);
      this.forma.get('pass').setValidators([]);
      this.forma.get('passR').setValidators([]);
      this.forma.get('pass').disable();
      this.forma.get('passR').disable();
      this.forma.get('pass').updateValueAndValidity();
      this.forma.get('passR').updateValueAndValidity();
      this.forma.get('telefono').setValue(this.data.user.telefono);
      this.forma.get('role').setValue(this.data.user.role);
      // this.forma.controls['name'].disabled;
    }

    this.forma.controls['emailR'].setValidators([
      Validators.required,
      this.validarEmail.bind(this)
    ]);

    this.forma.controls['passR'].setValidators([
      Validators.required,
      this.validarPass.bind(this)
    ]);
  }



  validarEmail(control: FormControl): ErrorValidate {
    // console.log(this.forma)
    if (control.value !== this.forma.controls['email'].value) {
      return { error: true };
    }

    return null;
  }

  validarPass(control: FormControl): ErrorValidate {

    if (control.value !== this.forma.controls['pass'].value) {
      return { error: true };
    }

    return null;

  }

  validarUserName(control: FormControl): Promise<ErrorValidate> | Observable<ErrorValidate>{
    return new Promise((resolve, reject) => {
      this.wsUser.getUserName(control.value).subscribe((data:any) => {
        console.log(this)
        if(!data.ok){
          resolve({existe: true});
          return;
        }
        resolve(null);
      });
    });
    return null;
  }

  getPerfiles(){
    this.wsUser.getPerfil().subscribe((data:any) => {
      console.log(data);
      if(!data.ok){
        return;
      }
      this.perfiles = data.data;
    })
  }

  addUser() {
    console.log(this.archivos)
    console.log(this.forma.getRawValue())
    let dataSend = {
      name: this.forma.value.nombre,
      username: this.forma.value.user,
      last_name: '',
      email: this.forma.value.email,
      password: this.forma.value.pass,
      role: this.forma.value.role,
      phone: this.forma.value.telefono,
      access: 'correo'
    }
    let formData = new FormData();
    for(let i in dataSend){
      formData.append(i, dataSend[i]);
    }

    formData.append
    if(this.data.view == 'newUsuario'){
      this.wsUser.addUser(formData).subscribe((data:any) => {
  
        this.dialogRef.close({ ...data, status: 'INACTIVE'});
        
      }, (err:any) => {
        this.error = true;
        this.msgError = 'No se logro crear el usuario'
      });
      return;
    }else if(this.data.view == 'editUsuario'){
      dataSend['id'] = this.data.user.id;
      dataSend['username'] = this.forma.getRawValue().user;
      this.wsUser.editUser(dataSend).subscribe((data:any) => {
  
        this.dialogRef.close({ ...dataSend, status: 'INACTIVE'});
        
      }, (err:any) => {
        this.error = true;
        this.msgError = 'No se logro crear el usuario'
      });
      return;
    
    }

  }

}
