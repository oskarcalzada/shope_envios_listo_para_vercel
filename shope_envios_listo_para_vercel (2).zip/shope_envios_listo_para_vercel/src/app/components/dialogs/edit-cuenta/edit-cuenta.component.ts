import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CuentasService } from 'src/app/services/cuentas.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-edit-cuenta',
  templateUrl: './edit-cuenta.component.html',
  styleUrls: ['./edit-cuenta.component.css']
})
export class EditCuentaComponent implements OnInit {

  forma!: FormGroup;
  matcher = new MyErrorStateMatcher();
  loading: boolean = false;

  constructor(public dialogRef: MatDialogRef<EditCuentaComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private wsCuenta: CuentasService) { 
      if(this.data.paqueteria == 'estafeta'){
        this.forma = new FormGroup({
          'nombre': new FormControl({value: this.data.cuenta?.nombre, disabled: (this.data.tipo == 'editar') ? true : false}, Validators.required),
          'id': new FormControl(this.data.cuenta?.id, Validators.required),
          'usuario': new FormControl(this.data.cuenta?.usuario, Validators.required),
          'pass': new FormControl(this.data.cuenta?.pass, Validators.required),
          'num_cuenta': new FormControl(this.data.cuenta?.num_cuenta, Validators.required),
          'num_oficina': new FormControl(this.data.cuenta?.num_oficina, Validators.required)
        });
      }
      if(this.data.paqueteria == 'fedex'){
        this.forma = new FormGroup({
          'nombre': new FormControl({value: this.data.cuenta?.nombre, disabled: (this.data.tipo == 'editar') ? true : false}, Validators.required),
          'key_cuenta': new FormControl(this.data.cuenta?.key_cuenta, Validators.required),
          'pass': new FormControl(this.data.cuenta?.pass, Validators.required),
          'num_cuenta': new FormControl(this.data.cuenta?.num_cuenta, Validators.required),
          'meter_cuenta': new FormControl(this.data.cuenta?.meter_cuenta, Validators.required)
        });
      }
      if(this.data.paqueteria == 'minutes'){
        this.forma = new FormGroup({
          'nombre': new FormControl({value: this.data.cuenta?.nombre, disabled: (this.data.tipo == 'editar') ? true : false}, Validators.required),
          'num_cuenta': new FormControl(this.data.cuenta?.num_cuenta, Validators.required),
          'pass': new FormControl(this.data.cuenta?.pass, Validators.required),
        });
      }

  }

  ngOnInit(): void {
  }

  editarCuenta(){
    this.loading = true;
    if(this.data.tipo == 'nuevo'){
      this.wsCuenta.newCuenta(this.forma.getRawValue(), this.data.paqueteria).subscribe((data:any) => {
        this.loading = false;
        if(!data.ok){
          return;
        }
        this.dialogRef.close({ok: true, data:this.forma.getRawValue()});
      })
      return;
    }

    
    let sendData = {
      ...this.forma.getRawValue(),
      id_cuenta: this.data.cuenta.id_cuenta
    }
    this.wsCuenta.editCuenta(sendData, this.data.paqueteria).subscribe((data:any) => {
      this.loading = false;
      if(!data.ok){
        return;
      }
      this.dialogRef.close({ok: true, data:sendData});
    });
  }



}
