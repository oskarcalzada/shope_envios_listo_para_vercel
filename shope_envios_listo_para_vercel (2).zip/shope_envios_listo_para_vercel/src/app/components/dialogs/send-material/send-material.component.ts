import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { MaterialService } from 'src/app/services/material.service';

@Component({
  selector: 'app-send-material',
  templateUrl: './send-material.component.html',
  styleUrls: ['./send-material.component.css']
})
export class SendMaterialComponent implements OnInit {

  constructor(private dialogRef:MatDialogRef<SendMaterialComponent>,
    @Inject(MAT_DIALOG_DATA) public data:any,
    private wsMaterial:MaterialService,
    private snack: MatSnackBar,
    public wsLogin: LoginService,
    private route:Router) { }

  ngOnInit(): void {
  }

  cerrar(){
    this.dialogRef.close({material: this.data.material});
  }

  borrarMaterial(id:number){
    let i = this.data.material.findIndex(element => element.id_producto == id);
    this.data.material.splice(i, 1);
  }

  sendMaterial(){
    if(!this.wsLogin.loginClient){
      this.dialogRef.close({material: this.data.material});
      this.route.navigate(['/registro']);
    }
    this.wsMaterial.sendMaterial(this.data.material).subscribe((data:any) => {
      console.log(data);
      if(!data.ok){
        return;
      }
      this.msgSnack(data.data.message);
      this.data.material = [];
      this.dialogRef.close({material: this.data.material});
    });
  }

  msgSnack(message:string){
    this.snack.open(message, 'Ok', {
      duration: 4000,
      horizontalPosition: 'end',
      verticalPosition: 'bottom'
    })
  }



}
