import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ZonasService } from 'src/app/services/zonas.service';

@Component({
  selector: 'app-prueba-cotizador',
  templateUrl: './prueba-cotizador.component.html',
  styleUrls: ['./prueba-cotizador.component.css']
})
export class PruebaCotizadorComponent implements OnInit {

  msgError:string = '';
  zona:any;
  loading:boolean = false;

  constructor(private dialogRef:MatDialogRef<PruebaCotizadorComponent>,
    private wsZona:ZonasService) { }

  ngOnInit(): void {
  }

  cerrar(){
    this.dialogRef.close();
  }

  cotizar(origen:string, destino:string){
    this.msgError = '';
    this.loading = false;
    this.wsZona.cotizarZona(origen, destino).subscribe((data:any) => {
      if(!data.ok){
        this.msgError = data.message;
        return;
      }
      this.loading = true;
      this.zona = data.data;
    });
  }

}
