import { Component, Inject, OnInit } from '@angular/core';
import { AsyncValidatorFn, FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { MultiusuarioService } from 'src/app/services/multiusuario.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

interface ErrorValidate{
  [s: string]: boolean
}

@Component({
  selector: 'app-new-multiusuario',
  templateUrl: './new-multiusuario.component.html',
  styleUrls: ['./new-multiusuario.component.css']
})
export class NewMultiusuarioComponent implements OnInit {
  
  forma!: FormGroup;
  matcher = new MyErrorStateMatcher();
  error:boolean = false;
  msgError:string = '';
  isEditIn:boolean = false;
  perfiles!:any[];

  constructor(public dialogRef: MatDialogRef<NewMultiusuarioComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private wsMulti: MultiusuarioService) {
  }

  ngOnInit() {
    console.log(this.data);
    this.forma = new FormGroup({
      'nombre': new FormControl('', Validators.required),
      'usuario': new FormControl('', Validators.required, this.validarUserName.bind(this)),
      'email': new FormControl('', [Validators.required, Validators.email]),
      'emailR': new FormControl(''),
      'pass': new FormControl('', Validators.required),
      'passR': new FormControl(''),
      'servicios': new FormGroup({
        'fedex': new FormControl(''),
        'estafeta': new FormControl(''),
        'minutes': new FormControl(''),
        'dhl': new FormControl(''),
      })
    });

    if(this.data.view == 'editUsuario'){
      this.forma.get('nombre')!.setValue(this.data.user.nombre);
      this.forma.get('usuario')!.setValue(this.data.user.usuario);
      this.forma.get('usuario')!.disable();
      this.forma.get('email')!.setValue(this.data.user.email);
      this.forma.get('emailR')!.setValue(this.data.user.email);
      this.forma.get('pass')!.setValidators([]);
      this.forma.get('passR')!.setValidators([]);
      this.forma.get('pass')!.disable();
      this.forma.get('passR')!.disable();
      this.forma.get('pass')!.updateValueAndValidity();
      this.forma.get('passR')!.updateValueAndValidity();
      this.forma.controls['servicios'].get('fedex')!.setValue(this.data.user.servicios.fedex);
      this.forma.controls['servicios'].get('estafeta')!.setValue(this.data.user.servicios.estafeta);
      this.forma.controls['servicios'].get('minutes')!.setValue(this.data.user.servicios.minutes);
      this.forma.controls['servicios'].get('dhl')!.setValue(this.data.user.servicios.dhl);
      // this.forma.controls['name'].disabled;
    }

    this.forma.controls['emailR'].setValidators([
      Validators.required,
      this.validarEmail.bind(this)
    ]);

    this.forma.controls['passR'].setValidators([
      Validators.required,
      this.validarPass.bind(this)
    ]);
  }



  validarEmail(control: FormControl): ErrorValidate | null {
    // console.log(this.forma)
    if (control.value !== this.forma.controls['email'].value) {
      return { error: true };
    }

    return null;
  }

  validarPass(control: FormControl): ErrorValidate | null {

    if (control.value !== this.forma.controls['pass'].value) {
      return { error: true };
    }

    return null;

  }

  validarUserName(control: FormControl): Promise<ErrorValidate> | Observable<ErrorValidate> {
    return new Promise((resolve, reject) => {
      this.wsMulti.getUserName(control.value).subscribe((data:any) => {
        console.log(this)
        if(!data.ok){
          resolve({existe: true});
          return;
        }
        resolve(null);
      });
    });
    return null;
  }


  addUser() {
    this.msgError = '';
    console.log(this.forma.getRawValue());
    let servicios = [];
    if(this.forma.value.servicios.fedex) servicios.push('FEDEX');
    if(this.forma.value.servicios.estafeta) servicios.push('ESTAFETA');
    if(this.forma.value.servicios.minutes) servicios.push('MINUTES');
    if(this.forma.value.servicios.dhl) servicios.push('DHL');
    let dataSend:any = {
      nombre: this.forma.value.nombre,
      usuario: this.forma.value.usuario,
      email: this.forma.value.email,
      pass: this.forma.value.pass,
      servicios: servicios.join(','),
      activo: 1
    }
    let formData = new FormData();
    for(let i in dataSend){
      formData.append(i, dataSend[i]);
    }

    formData.append
    if(this.data.view == 'newUsuario'){
      this.wsMulti.addMultiUser(formData).subscribe((data:any) => {
        if(!data.ok){
          this.msgError = data.message || data.errs[0]
          return;
        }
        this.dialogRef.close({ ...dataSend});
        
      }, (err:any) => {
        this.error = true;
        this.msgError = 'No se logro crear el usuario'
      });
      return;
    }else if(this.data.view == 'editUsuario'){
      dataSend['id_usuarioad'] = this.data.user.id_usuarioad;
      dataSend['usuario'] = this.forma.getRawValue().usuario;
      this.wsMulti.editMultiUser(dataSend).subscribe((data:any) => {
  
        this.dialogRef.close({ ...dataSend});
        
      }, (err:any) => {
        this.error = true;
        this.msgError = 'No se logro crear el usuario'
      });
      return;
    
    }

  }

}
