import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ServiciosService } from 'src/app/services/servicios.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-new-cargo',
  templateUrl: './new-cargo.component.html',
  styleUrls: ['./new-cargo.component.css']
})
export class NewCargoComponent implements OnInit {
  forma: FormGroup;
  matcher = new MyErrorStateMatcher();
  paqueterias: any[];
  errorNuevo: boolean = false;
  errorMsg: string = '';

  constructor(private wsServicio: ServiciosService,
    public dialogRef: MatDialogRef<NewCargoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.forma = new FormGroup({
      'paqueteria': new FormControl('', Validators.required),
      'descripcion': new FormControl('', Validators.required),
      'costo': new FormControl('', Validators.required),
      'precio': new FormControl('', Validators.required),
    });

    // this.forma.valueChanges.subscribe((data:any) => {
    //   console.log(this.forma)
    // });

  }

  ngOnInit() {
    this.getPaqueterias();
  }

  getPaqueterias() {
    this.wsServicio.getPaqueterias().subscribe((data: any) => {
      console.log(data);
      if (!data.ok) {
        return
      }
      this.paqueterias = data.data;
    })
  }

  agregarServicio() {
    let descripcion = this.forma.value.descripcion;
    let sendData = {
      paqueteria: this.forma.value.paqueteria,
      descripcion,
      costo: this.forma.value.costo,
      precio: this.forma.value.precio,
      activo: "0",
    }
    console.log(sendData);
    this.wsServicio.newCargo(sendData).subscribe((data: any) => {
      console.log(data);
      if (!data.ok) {
        this.errorNuevo = true;
        this.errorMsg = data.message;
        return;
      }
      this.dialogRef.close({ sendData });
    });
  }
}