
import { Component, OnInit,Inject } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ServiciosService } from 'src/app/services/servicios.service';
import { ErrorStateMatcher } from '@angular/material/core';
import { EnvioService } from 'src/app/services/envio.service';

interface ErrorValidate {
  [s: string]: boolean
}
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'true-editar-direcciones',
  templateUrl: './editar-direcciones.component.html',
  styleUrls: ['./editar-direcciones.component.css']
})
export class EditarDireccionesComponent implements OnInit {
  isLinear = false;
  matcher = new MyErrorStateMatcher();
  status: string;
  forma:FormGroup;
  coloniasRemitente: Array<any>;
  
  direcciones: any;
  constructor(public dialogRef: MatDialogRef<EditarDireccionesComponent>,private wsServicio: ServiciosService,private wsEnvio: EnvioService,
    @Inject(MAT_DIALOG_DATA) public data: any
    ) {
      this.forma = new FormGroup({
        'nombre': new FormControl({ value: '', disabled: true }, Validators.required),
        'compania': new FormControl('', Validators.required),
        'calle': new FormControl('', Validators.required),
        'colonia': new FormControl('', Validators.required),
        'ciudad': new FormControl({ value: '', disabled: true }, Validators.required),
        'cp': new FormControl('', Validators.required),
        'estado': new FormControl({ value: '', disabled: true }, Validators.required),
        'telefono': new FormControl('', Validators.required),
        // 'num_int': new FormControl('', Validators.required),
        // 'num_ext': new FormControl('', Validators.required),
        'referencia': new FormControl('', Validators.required),
        'paqueteria': new FormControl('', Validators.required),
        'email': new FormControl('', Validators.required),
        'idir': new FormControl({ value: '', disabled: true }, Validators.required),
      });

      this.forma.get('cp').valueChanges.subscribe((data: any) => {
        this.getCp(data, 'remitente');
      });
     }

  ngOnInit(): void {
    console.log(this.data.dir[0]);
    this.llenarForm(this.data.dir)
  }
  onNoClick(): void {
    this.dialogRef.close({msg:"No paso nada"});
  }
  editar(dataDir:any){
    let sendData = {
      idir: dataDir[0].id_direccion,
    }
    console.log(dataDir[0].calle);
    this.wsServicio.deleteDir(sendData).subscribe((data:any) =>{
      if (!data.ok) {
        return
      }
      this.dialogRef.close({msg:"Registro eliminado"});
    })
    
  }
  guardar(){
    
    let datos = this.forma.getRawValue();
    console.log(datos)
      this.wsServicio.actualizarDir(datos).subscribe((data:any) => {
        // console.log(data);
        if(!data.ok){
          this.dialogRef.close({msg:"No se pudo Actualizar el registro"});
          return;
        }
        if (data.ok) {
          this.dialogRef.close({msg:"Registro Actualizado"});
        }
        this.direcciones = data.data;
        
      });
  }
  llenarForm(data){
    this.forma.get('nombre').setValue(data[0].nombre);
    this.forma.get('referencia').setValue(data[0].referencia);
    // this.forma.get('num_int').setValue(data[0].num_int);
    // this.forma.get('num_ext').setValue(data[0].num_ext);
    this.forma.get('paqueteria').setValue(data[0].paqueteria);
    this.forma.get('compania').setValue(data[0].compania);
    this.forma.get('calle').setValue(data[0].calle);
    this.forma.get('ciudad').setValue(data[0].ciudad);
    this.forma.get('cp').setValue(data[0].cp);
    this.forma.get('colonia').setValue(data[0].colonia);
    this.forma.get('estado').setValue(data[0].estado);
    this.forma.get('telefono').setValue(data[0].telefono);
    this.forma.get('email').setValue(data[0].email);
    this.forma.get('idir').setValue(data[0].id_direccion);
  }
  getCp(cp: string, tipo: string) {
    this.forma.get('ciudad').setValue('');
    this.forma.get('estado').setValue('');
    this.forma.get('colonia').setValue('');
    this.wsEnvio.getCp(cp).subscribe((data: any) => {
      console.log(data)
      if (data.data.error) {
        return;
      }
      if (tipo == 'remitente') {
        this.coloniasRemitente = [];
        this.coloniasRemitente = data.data.codigo_postal.colonias;
        this.forma.get('ciudad').setValue(data.data.codigo_postal.municipio);
        this.forma.get('estado').setValue(data.data.codigo_postal.estado);
      }
      
    });
  }
}
