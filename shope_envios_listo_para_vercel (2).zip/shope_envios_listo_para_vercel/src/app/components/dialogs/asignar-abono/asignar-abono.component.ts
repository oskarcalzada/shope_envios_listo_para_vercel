import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CotizadorService } from 'src/app/services/cotizador.service';
import { ServiciosService } from 'src/app/services/servicios.service';

@Component({
  selector: 'app-asignar-abono',
  templateUrl: './asignar-abono.component.html',
  styleUrls: ['./asignar-abono.component.css']
})
export class AsignarAbonoComponent implements OnInit {

  forma: FormGroup;
  cargos: Array<any> = [];
  loading: boolean = false;
  idasociado!:number;
  msgError:string = '';
  msgOk:string = '';

  constructor(private wsServicio: ServiciosService,
    private wsCotizador:CotizadorService,
    private dialogRef: MatDialogRef<AsignarAbonoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.forma = new FormGroup({
      'precio': new FormControl('', [Validators.required, Validators.min(1)]),
      'referencia': new FormControl('RECARGA DE SALDO', Validators.required),
      'cantidad': new FormControl('', [Validators.required, Validators.min(1)])
    });
  }

  ngOnInit(): void {
    this.loading = true;
    this.idasociado = this.data.idasociado
  }

  asignar() {
    console.log(this.forma);
    let sendData = {
      cantidad: this.forma.value.cantidad,
      forma_pago: 1,
      id_servicio: 0,
      idasociado: this.idasociado,
      monto: this.forma.value.precio,
      status: 1,
      referencia: this.forma.value.referencia,
      tipo: 'ABONO'
    }
    this.msgOk = '';
    this.msgError = '';
    this.wsCotizador.nuevoCargoUser(sendData).subscribe((data:any) => {
      console.log(data);
      if(!data.ok){
        this.msgError = data.message;
        return;
      }
      this.msgOk = 'El cargo fue asignado correctamente'
      this.forma.reset();
    });
  }

  displayFn(cargo: any): string {
    return cargo && cargo.descripcion ? cargo.descripcion : '';
  }

}
