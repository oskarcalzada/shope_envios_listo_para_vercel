import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AsociadoService } from 'src/app/services/asociado.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-edit-asociado',
  templateUrl: './edit-asociado.component.html',
  styleUrls: ['./edit-asociado.component.css']
})
export class EditAsociadoComponent implements OnInit {

  forma: FormGroup;
  matcher = new MyErrorStateMatcher();
  msgError:string = '';
  user:any;
  loading:boolean = false;
  newDatos: any;
  msgSms:string = '';
  smsOk: boolean = false;
  msgCodigo:string = '';
  codigoOk:boolean = false;

  constructor(public dialogRef: MatDialogRef<EditAsociadoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private wsAsociado: AsociadoService) {
      this.user = data;
      console.log('info',this.user)
    }

  ngOnInit(): void {
    this.forma = new FormGroup({
      'nombre': new FormControl(''),
      'telefono': new FormControl(''),
      'rfc': new FormControl(''),
      'password': new FormControl(''),
      'codigo': new FormControl('') 
    });
  }

  enviarDatos(dato:string){
    this.loading = true;
    this.newDatos = this.data.info;
    this.newDatos[dato] = this.forma.value[dato]; 
    this.wsAsociado.setInfoAsociado(this.newDatos).subscribe((data:any) => {
      this.dialogRef.close(this.newDatos);
      this.loading = false; 
    });
  }

  enviarSms(){
    this.wsAsociado.enviarSms(this.data.info.telefono).subscribe((data:any) => {
      if(!data.ok){
        return this.msgSms = data.message;
      }
      this.msgSms = '¡El codigo fue enviado correctamente!';
      this.smsOk = true;
    });
  }

  validarCodigo(codigo){
    this.wsAsociado.validarCodigo(codigo).subscribe((data:any) => {
      if(!data.ok){
        return this.msgCodigo = data.message;
      }
      this.msgCodigo = '¡El codigo se valido correctamente!';
      this.codigoOk = true;
    });
  }

   cerrar(){
     this.dialogRef.close({validar: this.codigoOk});
   }

}
