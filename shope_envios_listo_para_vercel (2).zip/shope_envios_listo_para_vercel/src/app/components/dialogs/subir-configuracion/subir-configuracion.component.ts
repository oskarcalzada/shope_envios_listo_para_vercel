import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { FilesService } from 'src/app/services/files.service';

@Component({
  selector: 'app-subir-configuracion',
  templateUrl: './subir-configuracion.component.html',
  styleUrls: ['./subir-configuracion.component.css']
})
export class SubirConfiguracionComponent implements OnInit {

  estaSobreElemento: boolean = false;
  archivos: File = null;
  errMsg: string = '';
  msgOk: string = '';
  constructor(private dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private wsFile: FilesService) { }

  ngOnInit(): void {
  }

  sobre(event: any) {
    console.log(event)
    this.estaSobreElemento = event.ok;
    if (event.file) {
      this.archivos = event.file;
    }
  }

  borrarImg() {
    this.archivos = null;
  }

  getServicios() {
    this.wsFile.getServicios().subscribe((data: any) => {
      let a = document.createElement('a');
      document.body.appendChild(a);
      let url = URL.createObjectURL(data);
      a.target = '_self';
      a.download = `servicios_disponibles_${moment().format('YYYYMMDDHHmmss')}`;
      a.href = url;
      a.click();
    })
  }

  getFormato() {
    this.wsFile.getFormatoConf().subscribe((data: any) => {
      let a = document.createElement('a');
      document.body.appendChild(a);
      let url = URL.createObjectURL(data);
      a.target = '_self';
      a.download = `formato_${moment().format('YYYYMMDDHHmmss')}`;
      a.href = url;
      a.click();
    })
  }

  subirConfiguracion() {
    this.errMsg = '';
    this.msgOk = '';
    let formData = new FormData();
    formData.append('config', this.archivos);
    this.wsFile.subirConfiguracion(formData, this.data.idasociado).subscribe((data:any) => {
      if(!data.ok){
        this.errMsg = data.message;
        return;
      }
      this.msgOk = 'Los servicios se configuraron correctamente'
      this.archivos = null;
    })
  }

}
