import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AsociadoService } from 'src/app/services/asociado.service';
import Swal from 'sweetalert2';

interface ErrorValidate {
  [s: string]: boolean
}

@Component({
  selector: 'app-view-recuperar',
  templateUrl: './view-recuperar.component.html',
  styleUrls: ['./view-recuperar.component.css']
})
export class ViewRecuperarComponent implements OnInit {

  token: string = '';
  forma: FormGroup;
  msgError: string;

  constructor(private wsAsociado: AsociadoService,
    private active: ActivatedRoute,
    private router: Router) {
    this.active.params.subscribe((params: any) => {
      if (params['token']) {
        this.token = params['token'];
      }
    });

    this.forma = new FormGroup({
      'pass': new FormControl('', Validators.required),
      'pass2': new FormControl('', [Validators.required])
    });

    this.forma.controls['pass2'].setValidators([
      Validators.required,
      this.validarPass.bind(this)
    ]);

  }

  ngOnInit(): void {
    this.wsAsociado.validateToken(this.token).subscribe((data: any) => {
      if (!data.ok) {
        return this.router.navigate(['/menu/login']);
      }
      return null;
    })
  }

  validarPass(control: FormControl): ErrorValidate {
    // console.log(this.forma)
    if (control.value !== this.forma.controls['pass'].value) {
      return { error: true };
    }
    return {};
  }

  recuperar() {
    this.msgError = '';
    if (this.forma.value.pass !== this.forma.value.pass2) {
      this.msgError = 'Las contraseñas no coinciden';
      return
    }
    this.wsAsociado.resetPass(this.token, this.forma.value.pass).subscribe((data: any) => {
      if (!data.ok) {
        this.msgError = data.message;
        return
      }
      Swal.fire({
        icon: 'success',
        title: 'La contraseña fue modificada correctamente',
        confirmButtonText: 'Aceptar',
        allowOutsideClick: false
      }).then((result) => {
        if (result.isConfirmed) {
          this.router.navigate(['/menu/login'])
        }
      })
    })
  }

}
