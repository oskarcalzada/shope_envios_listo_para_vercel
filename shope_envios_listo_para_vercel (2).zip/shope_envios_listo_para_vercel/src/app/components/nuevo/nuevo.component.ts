import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { EnvioService } from 'src/app/services/envio.service';
import { MatDialog } from '@angular/material/dialog';
import { DireccionComponent } from '../dialogs/direccion/direccion.component';
import Swal from 'sweetalert2';
import { configEnvio } from 'src/app/classes/configEnvio';
import { ServiciosService } from 'src/app/services/servicios.service';
import { CreditoService } from 'src/app/services/credito.service';
import { AsociadoService } from 'src/app/services/asociado.service';
import { SatService } from 'src/app/services/sat.service';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import * as moment from 'moment';
import { CotizadorService } from '../../services/cotizador.service';
import { MatSnackBar } from '@angular/material/snack-bar';

interface ErrorValidate {
  [s: string]: boolean
}

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-nuevo',
  templateUrl: './nuevo.component.html',
  styleUrls: ['./nuevo.component.css']
})
export class NuevoComponent implements OnInit {

  isLinear = true;
  matcher = new MyErrorStateMatcher();
  forma: FormGroup;
  loadingCard: boolean = false;
  loadingPay: boolean = false;
  coloniasRemitente: Array<any> = [];
  coloniasDestinatario: Array<any> = [];
  disponibles: Array<any> = [];
  servicios: Array<any> = [];
  paqueterias: Array<any> = [];
  credito: any;
  info: any;
  embalajes: Array<any> = [];
  productos:any = [];
  filteredOptions: Observable<any[]> | undefined;
  timer:any;
  validPhone:boolean = true;
  isMinutes: boolean = false;
  isFedex: boolean = false;
  isEstafeta: boolean = false;
  isDhl: boolean = false;
  loadingDisponibles: boolean = false;
  loadDisponibles: boolean = false;
  typeGenerate: string = 'normal';

  constructor(private wsEnvio: EnvioService,
    private dialog: MatDialog,
    private wsServicio: ServiciosService,
    private wsCredito: CreditoService,
    private wsAsociado: AsociadoService,
    private wsSat: SatService,
    private wsCotizar: CotizadorService,
    private snackCtrl: MatSnackBar) {
    this.forma = new FormGroup({
      'servicio': new FormGroup({
        'paqueteria': new FormControl('', Validators.required),
        'tipo': new FormControl('DIA SIG', Validators.required),
        'guia': new FormControl('', Validators.required)
      }),
      'remitente': new FormGroup({
        'nombre': new FormControl('', Validators.required),
        'compania': new FormControl('', Validators.required),
        'calle': new FormControl('', Validators.required),
        'colonia': new FormControl('', Validators.required),
        'ciudad': new FormControl({ value: '', disabled: true }, Validators.required),
        'cp': new FormControl('', Validators.required),
        'estado': new FormControl({ value: '', disabled: true }, Validators.required),
        'telefono': new FormControl('', Validators.required),
        'referencia': new FormControl(''),
        'rfc': new FormControl(''),
        'nave': new FormControl(''),
        'plataforma': new FormControl(''),
        'email': new FormControl('')
      }),
      'destinatario': new FormGroup({
        'nombre': new FormControl('', Validators.required),
        'compania': new FormControl('', Validators.required),
        'calle': new FormControl('', Validators.required),
        'colonia': new FormControl('', Validators.required),
        'ciudad': new FormControl({ value: '', disabled: true }, Validators.required),
        'cp': new FormControl('', Validators.required),
        'estado': new FormControl({ value: '', disabled: true }, Validators.required),
        'telefono': new FormControl('', Validators.required),
        'referencia': new FormControl(''),
        'rfc': new FormControl(''),
        'nave': new FormControl(''),
        'plataforma': new FormControl(''),
        'email': new FormControl(''),
        'cpValid': new FormControl(false, Validators.requiredTrue)
      }),
      'paquete': new FormGroup({
        'alto': new FormControl('', Validators.required),
        'largo': new FormControl('', Validators.required),
        'ancho': new FormControl('', Validators.required),
        'peso': new FormControl(''),
        'pesov': new FormControl({ value: '', disabled: true }, Validators.required),
        'contenido': new FormControl('', Validators.required),
        'cantidad': new FormControl('', Validators.required),
        'idEmbalaje': new FormControl('', [Validators.required]),
        'idProducto': new FormControl('', Validators.required),
        'valor': new FormControl('', Validators.required),
        'cantidadPaq': new FormControl('2', [Validators.min(2)])
      }),
      'adicional': new FormGroup({
        'papel': new FormControl('', Validators.required),
        'seguro': new FormControl(0),
        'metodo': new FormControl('Web'),
        'fechaRec': new FormControl(''),
        'hora': new FormControl(''),
        'recoleccion': new FormControl('')
      })
    });
    console.log(this.forma)
    this.forma.controls['servicio'].get('paqueteria')!.valueChanges.subscribe((data: any) => {
      this.validateForm(data.toLowerCase());
      this.isMinutes = false;
      this.isEstafeta = false;
      this.isFedex = false;
      this.isDhl = false;
      if(data.toLowerCase() == 'minutes'){
        this.isMinutes = true;
      }
      if(data.toLowerCase() == 'fedex'){
        this.isFedex = true;
      }
      if(data.toLowerCase() == 'estafeta'){
        this.isEstafeta = true;
      }
      if(data.toLowerCase() == 'dhl'){
        this.isDhl = true;
      }
    });

    this.forma.get('paquete')!.valueChanges.subscribe((data: any) => {
      let pesov = (this.forma.controls['paquete'].get('alto')!.value * this.forma.controls['paquete'].get('largo')!.value * this.forma.controls['paquete'].get('ancho')!.value) / 5000;
      this.forma.controls['paquete'].get('pesov')!.setValue(Math.ceil(pesov), { emitEvent: false })
    });

    this.forma.controls['remitente'].get('cp')!.valueChanges.subscribe((data: any) => {
      this.getCp(data, 'remitente');
      console.log(this.forma)
    });

    this.forma.controls['destinatario'].get('cp')!.valueChanges.subscribe((data: any) => {
      this.getCp(data || '', 'destinatario');
    });

    this.forma.controls['paquete'].get('idProducto')!.setValidators([
      Validators.required,
      this.validateProducto.bind(this)
    ]);

    this.getPaqueterias();
  }

  ngOnInit(): void {
    this.validarTelefono();
    this.getCredito();
    this.getAsociado();
    this.getEmbalaje();
    // this.filteredOptions = this.forma.controls['paquete'].get('idProducto').valueChanges.pipe(
    //   startWith(''),
    //   map(value => typeof value === 'string' ? value : value.descripcion),
    //   map((descripcion) => descripcion ? this.productos.slice() : this.productos.slice())
    // );
    this.forma.controls['paquete'].get('idProducto')!.valueChanges.subscribe((data: any) => {
      if(data == null){
        return;
      }
      clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        console.log(data)
        if (data.length >= 3) {
          this.filteredOptions = this.filter(data).pipe(
              startWith(''),
              map(value => typeof value === 'string' ? value : value.descripcion),
              map((descripcion) => descripcion ? this.productos.slice() : this.productos.slice())
            );;
        }
      }, 500);
    })
    // this.validateForm('estafeta');
  }

  validarTelefono(){
    this.wsAsociado.validarTelefono().subscribe((data:any) => {
      console.log(data)
      if(!data.ok){
        this.validPhone = false;
        return;
      }
      this.validPhone = true;
    }, (err) => {
      this.validPhone = false;
    });
  }

  validateProducto(control: FormControl): ErrorValidate{
    if(control.value?.codigo === undefined){
      return {isNoSelect:  true}
    }
    return {};
  }

  validarEmail(control: FormControl): ErrorValidate {
    // console.log(this.forma)
    if (control.value !== this.forma.controls['email'].value) {
      return { error: true };
    }
    return {};
  }

  getAsociado() {
    this.wsAsociado.getAsociadoClient().subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.info = data.data;

      console.log(this.info)
    })
  }

  generar() {
    this.loadingPay = true;
    let codigoProducto = this.forma.getRawValue().paquete.idProducto.codigo;
    this.forma.controls['paquete'].get('idProducto')!.setValue(codigoProducto);
    console.log(this.forma.getRawValue());
    let serv = this.servicios.find(element => element.id_servicio == this.forma.value.servicio.guia);
    this.forma.controls['paquete'].get('peso')!.setValue(serv.peso);
    let messageRec = '';
    if(this.isMinutes && this.forma.value.adicional.fechaRec != '' && this.forma.value.adicional.fechaRec != null && this.forma.value.adicional.hora != '' && this.forma.value.adicional.hora != null){
      const recoleccion = `${moment(this.forma.value.adicional.fechaRec).format('YYYY-MM-DD')}T${this.forma.value.adicional.hora}:00`;
      this.forma.controls['adicional'].get('recoleccion').setValue(recoleccion);
      messageRec = `<p style="text-align: justify" class="fw-bold">Es probable que la recolección no se considere cuado el volumen de paquetes es menor a 3 paquetes por día <br> Se recomienda llevar a un punto de venta</p>`
    }
    this.wsEnvio.nuevoEnvio(this.forma.getRawValue(), this.forma.value.servicio.paqueteria).subscribe((data: any) => {
      this.loadingPay = false;
      console.log(data)
      if (!data.ok) {
        Swal.fire({
          icon: 'error',
          title: 'La guia no fue generada',
          text: `${data.message}`,
        });
        return;
      }
      Swal.fire({
        icon: 'success',
        title: '¡Etiqueta generada correctamente!',
        html: `<h4>Tracking: ${data.data.tracking}</h4>
               <a target="_blank" href="${data.data.label}"><h5>Imprimir</h5></a><br>${messageRec}`,
        allowOutsideClick: false
      });
      this.disponibles = [];
      this.servicios = [];
      this.forma.reset({
        servicio: {
          paqueteria: 'estafeta',
          tipo: 'DIA SIG'
        }
      });
    });
  }


  validateForm(paqueteria: string) {
    this.getDisponibles(paqueteria);
    this.forma.controls['servicio'].get('guia')!.setValue('');
    let form = this.forma.controls;
    let config = configEnvio(paqueteria);
    form['remitente'].get('nombre')!.setValidators(config!.nombre);
    form['remitente'].get('compania')!.setValidators(config!.compania);
    form['remitente'].get('calle')!.setValidators(config!.calle);
    form['remitente'].get('ciudad')!.setValidators(config!.ciudad);
    form['remitente'].get('cp')!.setValidators(config!.cp);
    form['remitente'].get('colonia')!.setValidators(config!.colonia);
    form['remitente'].get('estado')!.setValidators(config!.estado);
    form['remitente'].get('telefono')!.setValidators(config!.telefono);
    form['remitente'].get('referencia')!.setValidators(config!.referencia);
    form['destinatario'].get('nombre')!.setValidators(config!.nombre);
    form['destinatario'].get('compania')!.setValidators(config!.compania);
    form['destinatario'].get('calle')!.setValidators(config!.calle);
    form['destinatario'].get('ciudad')!.setValidators(config!.ciudad);
    form['destinatario'].get('cp')!.setValidators([Validators.required]);
    form['destinatario'].get('colonia')!.setValidators([Validators.required]);
    form['destinatario'].get('estado')!.setValidators([Validators.required]);
    form['destinatario'].get('telefono')!.setValidators(config!.telefono);
    form['destinatario'].get('referencia')!.setValidators(config!.referencia);
    form['paquete'].get('contenido')!.setValidators(config!.contenido);
    if(paqueteria == 'minutes'){
      form['remitente'].get('email')!.setValidators(config!.email);
      form['destinatario'].get('email')!.setValidators(config!.email);
    }
    this.forma.get('remitente')!.updateValueAndValidity();
    this.forma.get('destinatario')!.updateValueAndValidity();
    this.forma.get('paquete')!.updateValueAndValidity();
  }

  getDisponibles(paqueteria: string) {
    console.log(paqueteria)
    this.disponibles = [];
    this.loadingDisponibles = true;
    this.loadDisponibles = false;
    this.wsEnvio.getDisponibles(paqueteria).subscribe((data: any) => {
      console.log(data);
      this.loadingDisponibles = false;
      this.loadDisponibles = true;
      if (!data.ok) {
        return;
      }
      this.disponibles = data.data;
      console.log('disponibles', this.disponibles);
      this.getTipo('DIA SIG');
    });
  }

  getTipo(tipo: string) {
    this.servicios = [];
    this.servicios = this.disponibles.filter((element: any) => element.tipo == tipo && element.disponibles > 0);
    console.log('servicios', this.servicios, this.disponibles);
    if(tipo == 'LTL'){
      this.forma.controls['remitente'].get('nave').setValidators([Validators.required]);
      this.forma.controls['remitente'].get('plataforma').setValidators([Validators.required]);
      this.forma.controls['destinatario'].get('nave').setValidators([Validators.required]);
      this.forma.controls['destinatario'].get('plataforma').setValidators([Validators.required]);
      this.forma.get('remitente').updateValueAndValidity();
      this.forma.get('destinatario').updateValueAndValidity();
    }else{
      this.forma.controls['remitente'].get('nave').clearValidators();
      this.forma.controls['remitente'].get('plataforma').clearValidators();
      this.forma.controls['destinatario'].get('nave').clearValidators();
      this.forma.controls['destinatario'].get('plataforma').clearValidators();
      this.forma.get('remitente').updateValueAndValidity();
      this.forma.get('destinatario').updateValueAndValidity();
    }
  }

  getCp(cp: string, tipo: string) {
    this.forma.controls[tipo].get('ciudad')!.setValue('', { emitEvent: false });
    this.forma.controls[tipo].get('estado')!.setValue('', { emitEvent: false });
    this.forma.controls[tipo].get('colonia')!.setValue('', { emitEvent: false });
    this.wsEnvio.getCp(cp).subscribe((data: any) => {
      console.log(data)
      if (data.data.error) {
        return;
      }
      if (tipo == 'remitente') {
        this.coloniasRemitente = [];
        this.coloniasRemitente = data.data.colonias;
        this.forma.controls[tipo].get('ciudad')!.setValue( data.data.colonias[0]?.ciudad);
        this.forma.controls[tipo].get('estado')!.setValue( data.data.colonias[0]?.estado);
      }
      if (tipo == 'destinatario') {
        this.forma.controls[tipo].get('cpValid').setValue(false);
        this.coloniasDestinatario = [];
        this.coloniasDestinatario = data.data.colonias;
        this.forma.controls[tipo].get('ciudad')!.setValue( data.data.colonias[0]?.ciudad);
        this.forma.controls[tipo].get('estado')!.setValue( data.data.colonias[0]?.estado);
        if(cp.length == 5){
          this.wsCotizar.getCobertura(this.forma.controls['remitente'].get('cp').value, cp, this.forma.controls['servicio'].get('paqueteria').value).subscribe((data:any) => {
            console.log(data);
            if(!data.ok){
              this.forma.controls[tipo].get('cpValid').setValue(false);
              this.msgSnack(`No hay cobertura disponible para el codigo: ${cp}`)
              return;
            }
            this.forma.controls[tipo].get('cpValid').setValue(true);
            if(data.data.zona_extendida){
              this.msgSnack(`El codigo ${cp} cuenta con zona extendida:`)
              return;
            }
            if(data.data.ocurre){
              this.msgSnack(`Ocurre: ${data.data.ocurre}`)
              return;
            }

          });
        }
      }
    });
  }

  buscarDireccion(tipo: string) {
    const dialogRef = this.dialog.open(DireccionComponent, {
      width: '800px',
      data: {
        paqueteria: this.forma.value.servicio.paqueteria
      }
    });

    dialogRef.afterClosed().subscribe((data: any) => {
      console.log(data);
      if (!data.ok) {
        return;
      }
      this.llenarDatos(tipo, data.direccion);
    });
  }

  llenarDatos(tipo: string, data: any) {
    console.log(data.nombre)
    this.forma.controls[tipo].get('nombre')!.setValue(data.nombre);
    this.forma.controls[tipo].get('compania')!.setValue(data.compania);
    this.forma.controls[tipo].get('calle')!.setValue(data.calle);
    this.forma.controls[tipo].get('telefono')!.setValue(data.telefono);
    this.forma.controls[tipo].get('cp')!.setValue(data.cp);
  }

  getPaqueterias() {
    this.wsServicio.getPaqueteriasAsociado().subscribe((data: any) => {
      console.log('paqueteria', data)
      if (!data.ok) {
        return;
      }
      this.paqueterias = data.data;
    });
  }

  getCredito() {
    this.wsCredito.getSaldoCredito().subscribe((data: any) => {
      if (!data.ok) {
        console.log('credito', this.credito)
        return;
      }
      this.credito = data.data;
    });
  }

  getEmbalaje() {
    this.wsSat.getEmbalajes().subscribe((data: any) => {
      console.log(data)
      if (!data.ok) {
        return;
      }
      this.embalajes = data.data;
    });
  }

  getPorductos(search: string) {
    this.wsSat.getProductos(search).subscribe((data: any) => {
      console.log(data)
      if (!data.ok) {
        return;
      }
      this.productos = data.data;
    });
  }

  displayFn(producto: any): string {
    return producto && producto.descripcion ? producto.descripcion : '';
  }

  filter(value: string) {
    const filterValue = value.toLowerCase();
    // return this.productos.filter(cargo => cargo.descripcion.toLowerCase().includes(filterValue));
    return this.wsSat.getProductos(value).pipe(map((data: any) => {

      this.productos = (data.data !== undefined) ? data.data : [{id_producto: 0, descripcion: '', codigo: ''}]; 
      return this.productos;
    }));
  }

  msgSnack(message:string){
    this.snackCtrl.open(message, 'Ok', {
      horizontalPosition: 'end',
      verticalPosition: 'top',
      duration: 4000
    })
  }

  cambiarTipo(tipo){
    this.typeGenerate = tipo;
  }

}
