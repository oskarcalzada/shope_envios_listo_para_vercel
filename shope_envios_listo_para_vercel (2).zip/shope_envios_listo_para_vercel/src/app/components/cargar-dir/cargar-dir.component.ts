import { Component, EventEmitter, OnInit, Output } from '@angular/core';

import Swal from 'sweetalert2';
import { ServiciosService } from 'src/app/services/servicios.service';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-cargar-dir',
  templateUrl: './cargar-dir.component.html',
  styleUrls: ['./cargar-dir.component.css']
})
export class CargarDirComponent  {
  fileName = '';
  fileToUpload: File | null = null;
  urlDescarga :string =( `../data/direcciones/`)
 urlformato:string=environment.urlBack
  @Output() termino: EventEmitter<any> = new EventEmitter();

  constructor(private wsService:ServiciosService) { }

  

  onFileSelected(event) {

    const file:File = event.target.files[0];
    console.log(file);
    if (file) {
     
     
    let formData = new FormData();
    
    formData.append('archivo', file);
    this.wsService.cargarDir(formData).subscribe((data:any) =>{
      console.log(data);
        if(!data.ok){
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.message,
           })
          return;
        }
        this.termino.emit({ok: true});
        Swal.fire({
          icon: 'success',
          title: data.message,
          text: data.registros,
          showConfirmButton: false,
          timer: 3000
          
        })
    })
        this.fileName = file.name;
        


        // const formData = new FormData();

        // formData.append("thumbnail", file);
        // console.log(formData)
        // const upload$ = this.http.post("http://localhost:4200/menu/mis-direcciones", formData);


        // upload$.subscribe();
    }
}



}
