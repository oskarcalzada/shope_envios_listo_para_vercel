import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { LoginService } from 'src/app/services/login.service';
import { RecuperarComponent } from '../recuperar/recuperar.component';
declare const gapi: any;
declare const FB: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  forma: FormGroup;
  msgError: string = '';

  private scope = [
    'profile',
    'email',
    'https://www.googleapis.com/auth/plus.me',
  ].join(' ');

  auth2: any;

  constructor(private wsLogin: LoginService,
    private dialogRef: MatDialog) {
    this.forma = new FormGroup({
      'usuario': new FormControl('', Validators.required),
      'pass': new FormControl('', Validators.required)
    });
  }

  ngOnInit(): void {
    (window as any).fbAsyncInit = function () {
      FB.init({
        appId: '329210015864404',
        cookie: true,
        xfbml: true,
        version: 'v3.1'
      });
      FB.AppEvents.logPageView();
    };

    (function (d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) { return; }
      js = d.createElement(s); js.id = id;
      js.src = "https://connect.facebook.net/es_ES/sdk.js";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
  }

  ingresar() {
    console.log(this.forma.value);
    this.msgError = '';
    this.wsLogin.ingresar(this.forma.value.usuario, this.forma.value.pass).subscribe((data: any) => {
      console.log('data', data);
      if (!data.ok) {
        this.msgError = data.message;
        return
      }
      this.msgError = '';
      this.wsLogin.guardarSesion(data.data);
    });
  }

  recuperar() {
    const dialog = this.dialogRef.open(RecuperarComponent, {
      width: '600px'
    });
  }

  googleInit() {
    gapi.load('auth2', () => {
      this.auth2 = gapi.auth2.init({
        client_id: '189077492143-oc7qc4q90f96dtg8minu3fvvehk9s495.apps.googleusercontent.com',
        cookiepolicy: 'single_host_origin',
        scope: this.scope
      });
      document.getElementById('googleBtn').click();
    });
  }

  loginGoogle(btn){
    gapi.load('auth2', () => {
      this.auth2 = gapi.auth2.init({
        client_id: '189077492143-oc7qc4q90f96dtg8minu3fvvehk9s495.apps.googleusercontent.com',
        cookiepolicy: 'single_host_origin',
        scope: this.scope
      });
      this.attachSignin(btn);
    });
  }

  async attachSignin(element) {
    let result = await new Promise((resolve, reject) => {
      this.auth2.attachClickHandler(element, {},
        (googleUser) => {
          resolve(googleUser.getAuthResponse().id_token);
        }, (error) => {
          console.log(JSON.stringify(error, undefined, 2));
        });
    });
    this.msgError = '';
    this.wsLogin.validarRegistro({}, result).subscribe((data: any) => {
      console.log('result', data.message);
      if (!data.ok) {
        this.msgError = data.message;
        return;
      }
      if (data.type == 'newUser') {
        localStorage.setItem('userNew', JSON.stringify(data.data));
        window.location.href = "/menu/registrar";
      } else {
        localStorage.removeItem('userNew');
        console.log(data) 
        this.wsLogin.guardarSesion(data.data)
      }
    });
  }

  ngAfterViewInit() {
    this.googleInit();
  }

  async loginFacebook() {
    console.log("submit login to facebook");
    // FB.login();
    let result: any = await new Promise((resolve, reject) => {
      FB.login((response) => {
        console.log('submitLogin', response);
        if (response.authResponse) {
          resolve({ ok: true })
        }
        else {
          console.log('User login failed');
        }
      }, { scope: 'public_profile,email' });
    });
    if (!result.ok) {
      return;
    }
    this.getDataFacebook();
  }

  async getDataFacebook() {
    let result: any = await new Promise((resolve, reject) => {
      let result = FB.api(
        '/me',
        'GET',
        { "fields": "id,email,picture,name" },
        (response) => {
          let usuario = {
            id: response.id,
            nombre: response.name,
            img: response.picture.data.url,
            email: response.email,
            type: 'facebook'
          }
          resolve(usuario);
        }
      );
    });
    this.msgError = '';
    this.wsLogin.validarRegistro(result, '').subscribe((data: any) => {
      console.log('result', data);
      if (!data.ok) {
        this.msgError = data.message;
        return;
      }
      if (data.type == 'newUser') {
        localStorage.setItem('userNew', JSON.stringify(data.data));
        window.location.href = "/menu/registrar";
      } else {
        console.log(data)
        this.wsLogin.guardarSesion(data.data)
      }
    });
  }


}
