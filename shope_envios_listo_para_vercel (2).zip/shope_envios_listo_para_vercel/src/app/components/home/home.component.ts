import {Component, HostListener, OnDestroy, OnInit} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AvisosComponent } from '../dialogs/avisos/avisos.component';
import * as AOS from 'aos';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {
  images = [
    '../../../assets/img/partner1.png',
    '../../../assets/img/partner2.png',
    '../../../assets/img/partner3.png',
    '../../../assets/img/partner4.png',
    '../../../assets/img/partner5.png',
    '../../../assets/img/partner6.png'
  ];

  firstGroupImages = this.images.slice(0, 4);
  tamanoSlide = 25;
  currentSlide = 0;
  duration: number = 1500;

  imgPath: string = './assets/img/promo-abril.jpeg';
  resolucionPequena: boolean = false;
  timer: any;

  constructor(private dialog: MatDialog) {
    this.onResize(event);
  }

  ngOnInit(): void {
    // setTimeout(() => {
    //   this.getAviso();
    // }, 1000);

    AOS.init({
      duration: this.duration,
      once: true
    });

    this.startAutoPlay();
  }

  ngOnDestroy() {
    clearInterval(this.timer);
  }

  getAviso() {
    const dialogRef = this.dialog.open(AvisosComponent, {
      width: '600px',
      data: {
        img: this.imgPath
      }
    })
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    if (window.innerWidth <= 768) {
      this.resolucionPequena = true;
      this.tamanoSlide = 100;
      this.duration = 1000;
      return;
    }
    if (window.innerWidth <= 1200) {
      this.resolucionPequena = true;
      this.tamanoSlide = 33.3333;
      this.duration = 1000;
      return;
    }
    this.resolucionPequena = false;
    this.tamanoSlide = 25;
  }

  startAutoPlay(): void {
    const intervalo = 5000;
    this.timer = setInterval(() => this.nextSlide(), intervalo);
  }

  nextSlide(): void {
    this.currentSlide++;

    // Si llega al final, reinicia el carrusel sin transición
    if (this.currentSlide === this.images.length) {
      setTimeout(() => {
        this.currentSlide = 0;
        this.updateCarouselStyle(false);
      }, 500);
    } else {
      this.updateCarouselStyle(true);
    }
  }

  // Función para actualizar el estilo del carrusel con o sin transición
  updateCarouselStyle(withTransition: boolean): void {
    const carouselSlides = document.querySelector('.carousel-slides') as HTMLElement;
    carouselSlides.style.transition = withTransition ? 'transform 0.5s ease' : 'none';
    carouselSlides.style.transform = `translateX(-${this.currentSlide * 25}%)`;
  }

}
