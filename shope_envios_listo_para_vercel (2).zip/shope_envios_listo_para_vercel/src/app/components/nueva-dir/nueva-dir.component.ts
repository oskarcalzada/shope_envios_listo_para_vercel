import { Component, EventEmitter, OnInit,Output } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { EnvioService } from 'src/app/services/envio.service';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { ServiciosService } from 'src/app/services/servicios.service';

interface ErrorValidate {
  [s: string]: boolean
}
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-nueva-dir',
  templateUrl: './nueva-dir.component.html',
  styleUrls: ['./nueva-dir.component.css']
})
export class NuevaDirComponent implements OnInit {
  @Output() termino: EventEmitter<any> = new EventEmitter();
  isLinear = false;
  matcher = new MyErrorStateMatcher();
  forma: FormGroup;
 
 
  coloniasRemitente: Array<any>;
  coloniasDestinatario: Array<any>;
  disponibles: Array<any> = [];
  servicios: Array<any> = [];
  paqueterias:Array<any> = [];
  direcciones:Array<any> = [];
  

  constructor(private wsEnvio: EnvioService,
    private dialog: MatDialog,
    private wsServicio: ServiciosService) {
    this.forma = new FormGroup({
        'nombre': new FormControl('', Validators.required),
        'compania': new FormControl('', Validators.required),
        'calle': new FormControl('', Validators.required),
        'colonia': new FormControl('', Validators.required),
        'ciudad': new FormControl({ value: '', disabled: true }, Validators.required),
        'cp': new FormControl('', Validators.required),
        'estado': new FormControl({ value: '', disabled: true }, Validators.required),
        'telefono': new FormControl('', Validators.required),
        'paqueteria': new FormControl('',Validators.required)
      });

      this.forma.get('cp').valueChanges.subscribe((data: any) => {
      this.getCp(data, 'remitente');
    });

    
    
  }

  ngOnInit(): void {
  }
  guardar(){
    // console.log(this.forma.getRawValue());
    let datos = this.forma.getRawValue();
    console.log(datos)
      this.wsServicio.guardarDir(datos).subscribe((data:any) => {
        console.log(data);
        if(!data.ok){
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: data.message,
           })
          return;
        }
        else{
          Swal.fire({
            icon: 'success',
            title: data.message,
            showConfirmButton: false,
            timer: 1500
            
          })
          this.direcciones = data.data;
          this.termino.emit({ok: true});
        }
    
      });
  }
  getTipo(tipo: string) {
    this.servicios = [];
    this.servicios = this.disponibles.filter((element: any) => element.tipo == tipo && element.disponibles > 0);
  }

  getCp(cp: string, tipo: string) {
    this.forma.get('ciudad').setValue('');
    this.forma.get('estado').setValue('');
    this.forma.get('colonia').setValue('');
    this.wsEnvio.getCp(cp).subscribe((data: any) => {
      console.log(data)
      if (data.data.error) {
        return;
      }
      if (tipo == 'remitente') {
        this.coloniasRemitente = [];
        this.coloniasRemitente = data.data.colonias;
        this.forma.get('ciudad').setValue(data.data.colonias[0]?.ciudad);
        this.forma.get('estado').setValue(data.data.colonias[0]?.estado);
      }
      if (tipo == 'destinatario') {
        this.coloniasDestinatario = [];
        this.coloniasDestinatario = data.data.colonias;
        this.forma.get('ciudad').setValue(data.data.colonias[0]?.ciudad);
        this.forma.get('estado').setValue(data.data.colonias[0]?.estado);
      }
    });
  }

 

  


}
