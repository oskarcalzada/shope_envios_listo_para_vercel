import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { EnvioService } from 'src/app/services/envio.service';
import { ServiciosService } from 'src/app/services/servicios.service';
import Swal from 'sweetalert2';
import { DireccionComponent } from '../dialogs/direccion/direccion.component';
import { CotizadorService } from '../../services/cotizador.service';
import { MatSnackBar } from '@angular/material/snack-bar';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-recoleccion',
  templateUrl: './recoleccion.component.html',
  styleUrls: ['./recoleccion.component.css']
})
export class RecoleccionComponent implements OnInit {

  paqueterias: Array<any> = [];
  paqueteria: string = 'estafeta';
  matcher = new MyErrorStateMatcher();
  forma: FormGroup;
  coloniasRemitente: any;
  paquetes: FormArray = new FormArray([]);
  loading: boolean = false;
  isPaquete:boolean = true;

  constructor(private wsServicio: ServiciosService,
    private wsEnvio: EnvioService,
    private dialog: MatDialog,
    private wsCotizar: CotizadorService,
    private snackCtrl: MatSnackBar) {
    this.forma = new FormGroup({
      'fecha': new FormControl('', Validators.required),
      'hora': new FormControl('', Validators.required),
      'cierre': new FormControl('', Validators.required),
      'tipo': new FormControl('', Validators.required),
      'direccion': new FormGroup({
        'nombre': new FormControl('', [Validators.required, Validators.maxLength(25)]),
        'compania': new FormControl('', [Validators.required, Validators.maxLength(25)]),
        'calle': new FormControl('', [Validators.required, Validators.maxLength(30)]),
        'cp': new FormControl('', Validators.required),
        'colonia': new FormControl('', Validators.required),
        'ciudad': new FormControl({ value: '', disabled: true }, Validators.required),
        'estado': new FormControl({ value: '', disabled: true }, Validators.required),
        'telefono': new FormControl('', Validators.required),
        'referencia': new FormControl('', Validators.required),
        'email': new FormControl('', [Validators.required, Validators.email]),
        'num_ext': new FormControl('', Validators.required),
        'cpValid': new FormControl('', Validators.requiredTrue)
      }),
      'paquetes': this.paquetes
    });


    this.forma.get('paquetes').valueChanges.subscribe(data => {
      if (this.forma.value.paquetes.length > 0) {
        for (let i in this.forma.get('paquetes')['controls']) {
          console.log(this.forma.get('paquetes')['controls'][i])
          let pesoV = (Number(this.forma.get('paquetes')['controls'][i].get('largo').value) * Number(this.forma.get('paquetes')['controls'][i].get('alto').value) * Number(this.forma.get('paquetes')['controls'][i].get('ancho').value)) / 5000
          this.forma.get('paquetes')['controls'][i].get('pesov').setValue(Math.ceil(pesoV), { emitEvent: false });
        }
      }
    });

    this.forma.controls['direccion'].get('cp').valueChanges.subscribe((data: any) => {
      this.getCp(data);
    });

    this.forma.valueChanges.subscribe((data:any) => {
      console.log(this.forma);
    })

  }

  ngOnInit(): void {
    this.getPaqueterias();
    this.addPaquete();
    console.log(this.paquetes)
  }

  cambiarPaqueteria(paqueteria: string) {
    this.paqueteria = paqueteria;
    if(this.paqueteria == 'estafeta'){
      this.isPaquete = true;
      this.forma.get('tipo').setValidators([Validators.required]);
      this.forma.get('tipo').updateValueAndValidity();
    }else{
      this.isPaquete = false;
      this.forma.get('tipo').clearValidators();
      this.forma.get('tipo').setValue('normal');
      this.forma.get('tipo').updateValueAndValidity();
    }
  }

  getPaqueterias() {
    this.wsServicio.getPaqueteriasAsociado().subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      
      this.paqueterias = data.data;
      this.paqueterias = this.paqueterias.filter((paq:any) => paq.descripcion != 'MINUTES');
      // this.paqueterias = this.paqueterias.filter(element => element.descripcion.toLowerCase() != 'estafeta');
      console.log(this.paqueterias)
    })
  }

  addPaquete() {
    if (this.paquetes.controls.length >= 50) {
      return;
    }
    this.paquetes.push(
      (new FormGroup({
        'tipo': new FormControl('PKG', Validators.required),
        'largo': new FormControl('', Validators.required),
        'alto': new FormControl('', Validators.required),
        'ancho': new FormControl('', Validators.required),
        'peso': new FormControl('', Validators.required),
        'pesov': new FormControl({ value: '0', disabled: true }),
        'cantidad': new FormControl('1')
      })) as FormGroup
    )
  }

  deletePaquete(index) {
    this.paquetes.removeAt(index);
  }

  setPaquete(index) {
    if (index == 0) {
      this.addPaquete();
    } else {
      this.deletePaquete(index);
    }
  }

  noWeekends = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    let day2 = moment(d);
    return day !== 0 && day2.isAfter(moment().subtract(1, 'day').startOf('day'));
  }

  generarRecoleccion() {
    let sendData = this.forma.getRawValue();
    sendData.fecha = moment(sendData.fecha).format('YYYY-MM-DD');
    console.log(sendData);
    this.loading = true;
    this.wsEnvio.newRecoleccion(sendData, this.paqueteria).subscribe((data:any) => {
      console.log(data);
      this.loading = false;
      if(!data.ok){
        Swal.fire({
          icon: 'error',
          title: 'No se logro agendar la recolección',
          text: `${data.message}`,
        });
        return;
      }
      Swal.fire({
        icon: 'success',
        title: 'La recolección se genero correctamente',
        text: `Codigo de recolección: ${data.codigo}`,
      });
      this.forma.reset();
      for(let i in this.paquetes){
        let index:any = i;
        this.paquetes.removeAt(index);
      }
      this.addPaquete();
    });
  }

  getCp(cp: string) {
    this.forma.controls['direccion'].get('ciudad').setValue('');
    this.forma.controls['direccion'].get('estado').setValue('');
    this.forma.controls['direccion'].get('colonia').setValue('');
    this.wsEnvio.getCp(cp).subscribe((data: any) => {
      console.log(data)
      if (data.data.error) {
        return;
      }
        this.coloniasRemitente = [];
        this.coloniasRemitente = data.data.colonias;
        this.forma.controls['direccion'].get('ciudad').setValue(data.data.colonias[0]?.ciudad);
        this.forma.controls['direccion'].get('estado').setValue(data.data.colonias[0]?.estado);
        this.forma.controls['direccion'].get('cpValid').setValue(false);
        if(cp.length == 5){
          this.wsCotizar.getCobertura('54435', cp, this.paqueteria).subscribe((data:any) => {
            console.log(data);
            if(!data.ok){
              this.forma.controls['direccion'].get('cpValid').setValue(false);
              this.msgSnack(`No hay cobertura disponible para el codigo: ${cp}`)
              return;
            }
            // if(data.data.ocurre){
            //   this.msgSnack(`ocurre: ${data.data.ocurre}`)
            //   return;
            // }
            if(data.data.zona_extendida){
              this.msgSnack(`El codigo ${cp} cuenta con zona extendida:`)
              return;
            }
            this.forma.controls['direccion'].get('cpValid').setValue(true);
          });
        }
    });
  }

  buscarDireccion() {
    const dialogRef = this.dialog.open(DireccionComponent, {
      width: '800px',
      data: {
        paqueteria: this.paqueteria
      }
    });

    dialogRef.afterClosed().subscribe((data: any) => {
      console.log(data);
      if (!data.ok) {
        return;
      }
      this.llenarDatos(data.direccion);
    });
  }

  llenarDatos(data: any) {
    console.log(data.nombre)
    this.forma.controls['direccion'].get('nombre').setValue(data.nombre);
    this.forma.controls['direccion'].get('compania').setValue(data.compania);
    this.forma.controls['direccion'].get('calle').setValue(data.calle);
    this.forma.controls['direccion'].get('telefono').setValue(data.telefono);
    this.forma.controls['direccion'].get('cp').setValue(data.cp);
  }

  msgSnack(message:string){
    this.snackCtrl.open(message, 'Ok', {
      horizontalPosition: 'end',
      verticalPosition: 'top',
      duration: 4000
    })
  }

}
