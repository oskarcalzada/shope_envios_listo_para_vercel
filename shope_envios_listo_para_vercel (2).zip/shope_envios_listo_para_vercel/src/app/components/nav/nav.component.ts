import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { AuthenticatedService } from 'src/app/auth/authenticated.service';
import { AsociadoService } from 'src/app/services/asociado.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  mobileQuery: MediaQueryList;
  sidebar: boolean = false;
  private _mobileQueryListener: () => void;
  user: any;
  options: string = '';
  options2: string = '';
  info: any;
  fabOpen:boolean = false;

  constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher,
    private route: Router,
    public wsLogin: LoginService,
    private auth: AuthenticatedService,
    private wsAsociado: AsociadoService) {
    this.mobileQuery = media.matchMedia('(max-width: 1250px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  ngOnInit() {
    this.getAsociado();
  }

  getAsociado() {
    this.wsAsociado.getAsociadoClient().subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.info = data.data;
      console.log(this.info)
    })
  }

  salir() {
    localStorage.removeItem('userClient');
    localStorage.removeItem('tokenClient')
    // this.route.navigate(['/inicio']);
    window.location.reload();
  }

  toggleDarkTheme(): void {
    document.querySelector('.body').classList.toggle('dark-theme');
  }

  actionFab(){
    this.fabOpen = !this.fabOpen;
    console.log('fab' ,this.fabOpen)
    if(this.fabOpen){
      document.querySelector('.fab-mini').classList.add('animate__fadeInUp');
      document.querySelector('.fab-mini').classList.remove('animate__fadeOutDown');
      return;
    }
    document.querySelector('.fab-mini').classList.remove('animate__fadeInUp');
    document.querySelector('.fab-mini').classList.add('animate__fadeOutDown');
  }

}
