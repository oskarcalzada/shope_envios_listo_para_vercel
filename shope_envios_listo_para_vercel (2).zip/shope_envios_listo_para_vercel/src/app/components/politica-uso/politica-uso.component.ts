import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-politica-uso',
  templateUrl: './politica-uso.component.html',
  styleUrls: ['./politica-uso.component.css']
})
export class PoliticaUsoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
