import { Component, Input } from '@angular/core';
import * as moment from 'moment';
import { ReportesService } from '../../../services/reportes.service';

@Component({
  selector: 'app-destinos-mas-utilizados',
  templateUrl: './destinos-mas-utilizados.component.html',
  styleUrls: ['./destinos-mas-utilizados.component.css']
})
export class DestinosMasUtilizadosComponent {
  @Input() inicio: string;
  @Input() fin: string;

  loading: boolean = false;
  mejoresDestinos: Array<any> = [];

  constructor(private wsReportes: ReportesService) {
  }

  ngOnChanges() {
    this.getdestinosMasUtilizados();    
  }

  getdestinosMasUtilizados() {
    let inicioFormat = moment(this.inicio).format('YYYY-MM-DD');
    let finFormat = moment(this.fin).format('YYYY-MM-DD');
    this.wsReportes.getMejoresDestinos(inicioFormat, finFormat).subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.mejoresDestinos = data.data;
      this.loading = true;
    });
  }
}
