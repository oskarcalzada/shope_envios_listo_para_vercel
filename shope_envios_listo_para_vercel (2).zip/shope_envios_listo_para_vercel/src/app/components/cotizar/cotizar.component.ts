import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AsociadoService } from 'src/app/services/asociado.service';
import { CotizadorService } from 'src/app/services/cotizador.service';
import { CreditoService } from 'src/app/services/credito.service';
import Swal from 'sweetalert2';
import { ComprarComponent } from '../dialogs/comprar/comprar.component';
import { EnvioService } from "../../services/envio.service";
import { LoginService } from "../../services/login.service";
import { LoginComponent } from "../login/login.component";
import { gsap } from 'gsap';

@Component({
  selector: 'app-cotizar',
  templateUrl: './cotizar.component.html',
  styleUrls: ['./cotizar.component.css']
})
export class CotizarComponent implements OnInit {

  @ViewChild('svgContainer', { static: true }) svgContainer: ElementRef;

  viewPaquete: boolean = false;
  forma: FormGroup;
  loading: boolean = false;
  servicios: Array<any> = [];
  saldo: number = 0;
  info: any;
  credito: any;
  dataCotizador: any;
  coloniasRemitente: any[];
  coloniasDestino: any[];


  constructor(private wsCotizador: CotizadorService,
    private dialog: MatDialog,
    private wsCredito: CreditoService,
    private router: Router,
    private wsAsociado: AsociadoService,
    private wsEnvio: EnvioService,
    public wsLogin: LoginService,) {
    this.forma = new FormGroup({
      'origen': new FormControl('', Validators.required),
      'destino': new FormControl('', Validators.required),
      'tipo': new FormControl('Documento', Validators.required),
      'alto': new FormControl('10'),
      'largo': new FormControl('10'),
      'ancho': new FormControl('10'),
      'peso': new FormControl('1'),
      'pesov': new FormControl({ value: '0', disabled: true }),
    });

    this.forma.get('tipo').valueChanges.subscribe((data: any) => {
      if (data == 'Paquete') {
        this.forma.get('alto').setValidators(Validators.required);
        this.forma.get('largo').setValidators(Validators.required);
        this.forma.get('ancho').setValidators(Validators.required);
        this.forma.get('peso').setValidators(Validators.required);
        this.forma.get('alto').setValue('');
        this.forma.get('largo').setValue('');
        this.forma.get('ancho').setValue('');
        this.forma.get('peso').setValue('');
        this.forma.get('pesov').setValue('');
        this.forma.updateValueAndValidity();
      } else {
        this.forma.get('alto').setValue('10');
        this.forma.get('largo').setValue('10');
        this.forma.get('ancho').setValue('10');
        this.forma.get('peso').setValue('1');
        this.forma.get('pesov').setValue('1');
      }
      console.log(this.forma);
    });

    this.forma.valueChanges.subscribe((data: any) => {
      let pesov = (this.forma.value.alto * this.forma.value.largo * this.forma.value.ancho) / 5000;
      this.forma.get('pesov').setValue(Math.ceil(pesov), { emitEvent: false });
      console.log(this.forma.value.pesov)
    });

    this.forma.get('origen').valueChanges.subscribe((value: string) => {
      if (value.length < 5) {
        return;
      }
      this.getColonias('remitente', value);
    });

    this.forma.get('destino').valueChanges.subscribe((value: string) => {
      if (value.length < 5) {
        return;
      }
      this.getColonias('destinatario', value);
    });

  }

  ngOnInit(): void {
    this.getAsociado();
    this.getCredito();
    for (let i = 0; i < 6; i++) {
      this.createAnimatedBox(i);
    }
  }

  getAsociado() {
    this.wsAsociado.getAsociadoClient().subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      this.info = data.data;

      console.log(this.info)
    })
  }

  async getSaldo() {
    await new Promise((resolve) => {
      this.wsCotizador.getSaldo().subscribe((data: any) => {
        console.log(data)
        if (!data.ok) {
          return;
        }
        this.saldo = data.data.disponible;
        resolve({ ok: true });
      });
    });
  }

  tipoPaq(event: any) {
    console.log(event)
    if (event.value == 'Paquete') {
      this.viewPaquete = true;
      return;
    }
    this.viewPaquete = false;
  }

  cotizar() {
    if (!this.wsLogin.loginClient) {
      this.cotizarGeneral();
      return
    }
    console.log(this.forma.value);
    this.loading = true;
    this.servicios = [];
    const sendData = {
      ...this.forma.getRawValue(),
      origen: this.forma.value.origen.split('-')[0].trim(),
      destino: this.forma.value.destino.split('-')[0].trim(),
    }
    console.log('cot', sendData);
    this.wsCotizador.getServicios(sendData).subscribe((data: any) => {
      this.loading = false;
      if (!data.ok) {
        return;
      }
      this.servicios = data.data.servicios;
      this.dataCotizador = data.data;
      console.log(data)
    });
  }

  cotizarGeneral() {
    this.loading = true;
    this.servicios = [];
    const sendData = {
      ...this.forma.getRawValue(),
      origen: this.forma.value.origen.split('-')[0].trim(),
      destino: this.forma.value.destino.split('-')[0].trim(),
    }
    console.log('cot', sendData);
    this.wsCotizador.getServiciosGenerales(sendData).subscribe((data: any) => {
      this.loading = false;
      if (!data.ok) {
        return;
      }
      this.servicios = data.data.servicios;
      this.dataCotizador = data.data;
      console.log(data)
    });
  }

  getCredito() {
    this.wsCredito.getSaldoCredito().subscribe((data: any) => {
      if (!data.ok) {
        console.log('credito', this.credito)
        return;
      }
      this.credito = data.data;
    });
  }

  async comprar(id_servicio, cantidad) {
    if (cantidad <= 0 || cantidad >= 100) {
      Swal.fire({
        icon: 'error',
        title: `La cantidad no es valida`,
      });
      return;
    }
    if (!this.wsLogin.loginClient) {
      this.router.navigate(['/menu/login']);
      return;
    }
    await this.getSaldo();
    let servicio = this.servicios.find(element => element.id_servicio == id_servicio);
    let sendData = {
      cantidad,
      monto: servicio.precio,
      tipo: 'CARGO',
      id_servicio: servicio.id_servicio,
      status: 1
    };
    let dialogRef = this.dialog.open(ComprarComponent, {
      width: '500px',
      data: sendData
    });

    dialogRef.afterClosed().subscribe((data: any) => {
      if (!data.ok && !data.requerido) {
        return;
      }
      if (!data.ok && data.requerido) {
        Swal.fire({
          icon: 'error',
          title: `${data.message}`,
          html: `<h4>Monto requerido: ${data.requerido}</h4>`,
        });
        return;
      }
      Swal.fire({
        icon: 'success',
        title: `¡Se acredito tu compra!`,
        html: `<h4>ID Movimiento: ${data.id_movimiento}</h4>`,
        showCancelButton: true,
        cancelButtonText: `Seguir Cotizando`,
        confirmButtonText: 'Generar Guía',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#4BC92F',
      }).then((result: any) => {
        if (result.isConfirmed) {
          this.router.navigate(['/menu/nuevo'])
        }
      });
    });

    // Swal.fire({
    //   html: `<h4>¿Continuar con la compra de servicio?</h4>
    //   <h5><b>Saldo Disponible</b>: ${this.saldo}</h5>
    //   <h5><b>Precio</b>: ${(sendData.cantidad * sendData.monto)}
    //   `,
    //   showDenyButton: true,
    //   confirmButtonText: `Continuar`,
    //   denyButtonText: `Cancelar`,
    // }).then((result) => {
    //   if (result.isConfirmed) {
    //     this.wsCotizador.nuevoCargo(sendData).subscribe((data: any) => {
    //       console.log(data);
    //       if (!data.ok) {
    //         Swal.fire({
    //           icon: 'error',
    //           title: `${data.message}`,
    //           html: `<h4>Monto requerido: ${data.requerido}</h4>`,
    //         });
    //         return;
    //       }
    //       Swal.fire({
    //         icon: 'success',
    //         title: `¡Se acredito tu compra!`,
    //         html: `<h4>ID Movimiento: ${data.data.id_movimiento}</h4>`,
    //       });
    //     });
    //   }
    // });
  }

  getColonias(type: string, cp: string) {
    this.wsEnvio.getCp(cp).subscribe((data: any) => {
      if (!data.ok) {
        return;
      }
      if (type == 'remitente') {
        this.coloniasRemitente = data.data.colonias;
        return;
      }
      this.coloniasDestino = data.data.colonias;
      return;
    }
    );
  }

  calculateBoxSize(): number {
    const windowWidth = window.innerWidth;
    const scaleFactor = Math.min(windowWidth / 1200, 1);

    return 80 * scaleFactor;
  }

  createAnimatedBox(index: number): void {
    const svg = this.svgContainer.nativeElement;
    const boxSize = this.calculateBoxSize();
    const spacing = -10 * (boxSize / 100);
    const totalWidth = (3 * boxSize) + (2 * spacing);
    const xOffset = () => (svg.clientWidth - totalWidth) / 2;
    let xPos;
    const duration = 0.7;
    let delay = index * 0.2;
    const imagePath = '../../../assets/img/caja_shope.png';

    if (index < 3) {
      xPos = () => xOffset() + index * (boxSize + spacing);
    } else {
      delay += 0.7;
      xPos = () => xOffset() + (index - 2.5) * (boxSize + spacing);
    }

    if (index === 5) {
      delay += 0.7;
      xPos = () => xOffset() + boxSize + spacing;
    }

    const box = document.createElementNS("http://www.w3.org/2000/svg", "image");
    box.setAttribute("x", xPos().toString());
    box.setAttribute("y", (-boxSize).toString());
    box.setAttribute("width", boxSize.toString());
    box.setAttribute("height", boxSize.toString());
    box.setAttribute("href", imagePath);
    svg.appendChild(box);

    let finalY;
    if (index < 3) {
      finalY = svg.clientHeight - boxSize;
    } else if (index < 5) {
      finalY = svg.clientHeight - (1.7 * boxSize);
    } else {
      finalY = svg.clientHeight - (2.4 * boxSize);
    }

    setTimeout(() => {
      gsap.delayedCall(delay, () => {
        gsap.to(box, {
          y: finalY,
          opacity: 1,
          duration: duration,
          ease: "inOut"
        });
      });      
    }, 1000);

  }
}
