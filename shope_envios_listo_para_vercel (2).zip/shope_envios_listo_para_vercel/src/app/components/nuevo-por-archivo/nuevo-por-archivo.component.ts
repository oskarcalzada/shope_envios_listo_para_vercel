import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { FilesService } from '../../services/files.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-nuevo-por-archivo',
  templateUrl: './nuevo-por-archivo.component.html',
  styleUrls: ['./nuevo-por-archivo.component.css']
})
export class NuevoPorArchivoComponent implements OnInit {

  paqueteria: string = 'fedex';
  archivo: any = null;
  isFile: boolean;
  fileName: string = '';
  totalLabels: number = 0;
  labels: any[] = [];
  loading: boolean = false;

  constructor(private wsFile: FilesService) { }

  ngOnInit(): void {
  }

  changePaqueteria(paqueteria: string){
    this.paqueteria = paqueteria;
  }

  sobre(event: any) {
    console.log(event)
    this.resetForm();
    if (event.file) {
      this.archivo = event.file;
    }
  }

  getCatalogos(){
    this.wsFile.getCatalogosGeneracion(this.paqueteria).subscribe((data: any) => {
      let a = document.createElement('a');
      document.body.appendChild(a);
      let url = URL.createObjectURL(data);
      a.target = '_self';
      a.download = `catalogo_${moment().format('YYYYMMDDHHmmss')}`;
      a.href = url;
      a.click();
    })
  }

  getFormatoGeneracion(){
    this.wsFile.getFormatoGeneracion(this.paqueteria).subscribe((data: any) => {
      let a = document.createElement('a');
      document.body.appendChild(a);
      let url = URL.createObjectURL(data);
      a.target = '_self';
      a.download = `formato_${moment().format('YYYYMMDDHHmmss')}`;
      a.href = url;
      a.click();
    })
  }

  uploadFile(){
    const sendData = new FormData();
    sendData.append('config', this.archivo);
    this.isFile = false;
    this.wsFile.uploadFileLabel(sendData, this.paqueteria).subscribe((data:any) => {
      if(!data.ok){
        Swal.fire({
          icon: 'error',
          title: data.message,
          confirmButtonColor: '#2090f1',
          confirmButtonText: 'Aceptar'
        })
        return;
      }
      this.isFile = true;
      this.fileName = data.fileName;
      this.totalLabels = data.total;
    });
  }

  createLabels(){
    const sendData = {
      file: this.fileName
    }
    this.loading = true;
    this.wsFile.generarGuia(sendData, this.paqueteria).subscribe((data:any) => {
      this.loading = false;
      this.fileName = '';
      if(!data.ok){
        Swal.fire({
          icon: 'error',
          title: data.message,
          confirmButtonColor: '#2090f1',
          confirmButtonText: 'Aceptar'
        });
        this.labels = data.data;
        return;
      }
      this.labels = data.data;
    })  
  }

  openLabel(label){
    window.open(label, '_blank');
  }

  resetForm(){
    this.isFile = false;
    this.labels = [];
    this.archivo = null;
    this.totalLabels = 0;
    this.fileName = '';
  }

}
