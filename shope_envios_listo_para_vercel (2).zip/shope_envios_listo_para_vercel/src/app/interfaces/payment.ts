

export interface PaymentCard{
    card_number: string;
    holder_name: string;
    expiration_year: string;
    expiration_month: string;
    cvv: string;
    amount: number;
    description: string;
}

export interface PaymentCash{
    amount: number;
    description: string;
}