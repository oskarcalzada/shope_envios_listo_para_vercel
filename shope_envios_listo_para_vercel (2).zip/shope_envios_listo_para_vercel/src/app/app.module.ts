import { NgModule, LOCALE_ID } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { registerLocaleData } from '@angular/common';
import { NgxChartsModule } from '@swimlane/ngx-charts';

import localeMX from '@angular/common/locales/es-MX';

registerLocaleData(localeMX, 'es-MX');

import { AppComponent } from './app.component';
import { APP_ROUTES } from './app.routing';
import { HomeComponent } from './components/home/home.component';
import { NavComponent } from './components/nav/nav.component';
import { FooterComponent } from './components/footer/footer.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material.module';
import { RegistrarComponent } from './components/registrar/registrar.component';
import { LoginComponent } from './components/login/login.component';
import { ApiComponent } from './components/api/api.component';
import { CotizarComponent } from './components/cotizar/cotizar.component';
import { NuevoComponent } from './components/nuevo/nuevo.component';
import { DireccionesComponent } from './components/direcciones/direcciones.component';
import { RastreoComponent } from './components/rastreo/rastreo.component';
import { RecoleccionComponent } from './components/recoleccion/recoleccion.component';
import { EstadoCuentaComponent } from './components/estado-cuenta/estado-cuenta.component';
import { EnviosComponent } from './components/envios/envios.component';
import { NumbersOnlyDirective } from './directives/numbers-only.directive';
import { EstadoPipe } from './pipes/estado.pipe';
import { ImgPaqPipe } from './pipes/img-paq.pipe';
import { TimePipe } from './pipes/time.pipe';
import { StatusPipe } from './pipes/status.pipe';
import { NgFilesDirective } from './directives/ng-files.directive';
import { NgDropFilesDirective } from './directives/ng-drop-files.directive';
import { DomseguroPipe } from './pipes/domseguro.pipe';
import { TextcutPipe } from './pipes/textcut.pipe';
import { ZonaextPipe } from './pipes/zonaext.pipe';
import { DescripcionPipe } from './pipes/descripcion.pipe';
import { ReexpedicionPipe } from './pipes/reexpedicion.pipe';
import { NgDropFilesXlsDirective } from './directives/ng-drop-files-xls.directive';
import { NgFilesXlsDirective } from './directives/ng-files-xls.directive';
import { DisabledPaqPipe } from './pipes/disabled-paq.pipe';
import { JwtModule } from '@auth0/angular-jwt';
import { HttpClientModule } from '@angular/common/http';
import { DireccionComponent } from './components/dialogs/direccion/direccion.component';
import { RecargaSaldoComponent } from './components/dialogs/recarga-saldo/recarga-saldo.component';
import { ComprobanteComponent } from './components/dialogs/comprobante/comprobante.component';
import { SetUsuarioComponent } from './components/dialogs/set-usuario/set-usuario.component';
import { NewServicioComponent } from './components/dialogs/new-servicio/new-servicio.component';
import { InfoMaterialComponent } from './components/dialogs/info-material/info-material.component';
import { SendMaterialComponent } from './components/dialogs/send-material/send-material.component';
import { ComprarComponent } from './components/dialogs/comprar/comprar.component';
import { EditCuentaComponent } from './components/dialogs/edit-cuenta/edit-cuenta.component';
import { PruebaCotizadorComponent } from './components/dialogs/prueba-cotizador/prueba-cotizador.component';
import { NewCargoComponent } from './components/dialogs/new-cargo/new-cargo.component';
import { AsignarCargoComponent } from './components/dialogs/asignar-cargo/asignar-cargo.component';
import { SubirConfiguracionComponent } from './components/dialogs/subir-configuracion/subir-configuracion.component';
import { NewMultiusuarioComponent } from './components/dialogs/new-multiusuario/new-multiusuario.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RecuperarComponent } from './components/recuperar/recuperar.component';
import { AvisoPrivacidadComponent } from './components/aviso-privacidad/aviso-privacidad.component';
import { PoliticaUsoComponent } from './components/politica-uso/politica-uso.component';
import { MovimientosComponent } from './components/estado-cuenta/movimientos/movimientos.component';
import { CreditoComponent } from './components/estado-cuenta/credito/credito.component';
import { InicioDashComponent } from './components/dashboard/inicio/inicio.component';
import { LoginUserComponent } from './components/dashboard/login-user/login-user.component';
import { MenuComponent } from './components/dashboard/menu/menu.component';
import { AsociadosComponent } from './components/dashboard/asociados/asociados.component';
import { ServiciosComponent } from './components/dashboard/servicios/servicios.component';
import { UsuariosComponent } from './components/dashboard/usuarios/usuarios.component';
import { ComprobantesDashComponent } from './components/dashboard/comprobantes-dash/comprobantes-dash.component';
import { ConfServiciosComponent } from './components/dashboard/conf-servicios/conf-servicios.component';
import { HistorialComponent } from './components/dashboard/historial/historial.component';
import { DetalleHistorialComponent } from './components/dashboard/detalle-historial/detalle-historial.component';
import { CuentasComponent } from './components/dashboard/cuentas/cuentas.component';
import { LtlComponent } from './components/dashboard/ltl/ltl.component';
import { CargosComponent } from './components/dashboard/cargos/cargos.component';
import { ViewRecuperarComponent } from './components/view-recuperar/view-recuperar.component';
import { EstadoCuentaDashComponent } from './components/dashboard/estado-cuenta/estado-cuenta.component';
import { NuevaDirComponent } from './components/nueva-dir/nueva-dir.component';
import { CargarDirComponent } from './components/cargar-dir/cargar-dir.component';
import { ListaDirComponent } from './components/lista-dir/lista-dir.component';
import { EditarDireccionesComponent } from './components/dialogs/editar-direcciones/editar-direcciones.component';
import { InfoAsociadoComponent } from './components/info-asociado/info-asociado.component';
import { EditAsociadoComponent } from './components/dialogs/edit-asociado/edit-asociado.component';
import { AvisosComponent } from './components/dialogs/avisos/avisos.component';
import { ApiDocsComponent } from './components/api-docs/api-docs.component';
import { MultiusuariosComponent } from './components/multiusuarios/multiusuarios.component';
import { AsignarAbonoComponent } from './components/dialogs/asignar-abono/asignar-abono.component';
import { ColorPackPipe } from './pipes/color-pack.pipe';
import { ContactoComponent } from './components/contacto/contacto.component';
import { PreguntasComponent } from './components/preguntas/preguntas.component';
import { ReportesComponent } from './components/reportes/reportes.component';
import { DestinosMasUtilizadosComponent } from './components/reportes/destinos-mas-utilizados/destinos-mas-utilizados.component';
import { GuiasPorEstadoComponent } from './components/reportes/guias-por-estado/guias-por-estado.component';
import { GuiasTotalesComponent } from './components/reportes/guias-totales/guias-totales.component';
import { NuevoPorArchivoComponent } from './components/nuevo-por-archivo/nuevo-por-archivo.component';
import { IConfig, NgxMaskModule } from 'ngx-mask';
import { RecoleccionesPendientesComponent } from './components/reportes/recolecciones-pendientes/recolecciones-pendientes.component';

export function getToken() {
  return JSON.parse(localStorage.getItem('user') || '').token;
}

const maskConfig: Partial<IConfig> = {
  validation: false,
};

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavComponent,
    FooterComponent,
    RegistrarComponent,
    LoginComponent,
    ApiComponent,
    CotizarComponent,
    NuevoComponent,
    DireccionesComponent,
    RastreoComponent,
    RecoleccionComponent,
    EstadoCuentaComponent,
    EnviosComponent,
    NumbersOnlyDirective,
    EstadoPipe,
    ImgPaqPipe,
    TimePipe,
    StatusPipe,
    NgFilesDirective,
    NgDropFilesDirective,
    DomseguroPipe,
    TextcutPipe,
    ZonaextPipe,
    DescripcionPipe,
    ReexpedicionPipe,
    NgDropFilesXlsDirective,
    NgFilesXlsDirective,
    DisabledPaqPipe,
    DireccionComponent,
    RecargaSaldoComponent,
    ComprobanteComponent,
    SetUsuarioComponent,
    NewServicioComponent,
    InfoMaterialComponent,
    SendMaterialComponent,
    ComprarComponent,
    EditCuentaComponent,
    PruebaCotizadorComponent,
    NewCargoComponent,
    AsignarCargoComponent,
    SubirConfiguracionComponent,
    NewMultiusuarioComponent,
    RecuperarComponent,
    AvisoPrivacidadComponent,
    PoliticaUsoComponent,
    MovimientosComponent,
    CreditoComponent,
    InicioDashComponent,
    LoginUserComponent,
    MenuComponent,
    AsociadosComponent,
    ServiciosComponent,
    UsuariosComponent,
    ComprobantesDashComponent,
    ConfServiciosComponent,
    EstadoCuentaDashComponent,
    HistorialComponent,
    DetalleHistorialComponent,
    CuentasComponent,
    LtlComponent,
    CargosComponent,
    ViewRecuperarComponent,
    NuevaDirComponent,
    CargarDirComponent,
    ListaDirComponent,
    EditarDireccionesComponent,
    InfoAsociadoComponent,
    EditAsociadoComponent,
    AvisosComponent,
    ApiDocsComponent,
    MultiusuariosComponent,
    AsignarAbonoComponent,
    ColorPackPipe,
    ContactoComponent,
    PreguntasComponent,
    ReportesComponent,
    NuevoPorArchivoComponent,
    DestinosMasUtilizadosComponent,
    GuiasPorEstadoComponent,
    GuiasTotalesComponent,
    RecoleccionesPendientesComponent
  ],
  imports: [
    BrowserModule,
    APP_ROUTES,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: getToken
      }
    }),
    HttpClientModule,
    NgxChartsModule,
    NgxMaskModule.forRoot(maskConfig)
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'es-MX' }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
