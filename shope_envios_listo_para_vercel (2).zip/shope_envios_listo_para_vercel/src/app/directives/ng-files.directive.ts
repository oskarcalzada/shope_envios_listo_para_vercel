import { ChangeDetectorRef, Directive, EventEmitter, forwardRef, Output } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

@Directive({
  selector: '[appNgFiles]',
  host: {
    "(change)": "onChange($event.target.files)",
    "(blur)": "onTouched()"
  },
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => NgFilesDirective),
      multi: true
    }
  ]
})
export class NgFilesDirective {

  value:any;
  @Output() subir:EventEmitter<any> = new EventEmitter();
  onChange = (data:any) => {
    console.log(data);
    if(data[0] === undefined){
      return;
    }
    if(!this._esImagen(data[0].type)){
      return;
    }
    this.subir.emit(data);
    return;
  };
  onTouched = () => {};

  constructor(private _cdr:ChangeDetectorRef) {
    console.log('funciona?')
  }

  writeValue(value:any){}
  registerOnChange(fn: any){this.onChange = fn;}
  registerOnTouched(fn:any){this.onTouched = fn;}

  private _esImagen(tipoArchivo: string): boolean {
    return (tipoArchivo === '' || tipoArchivo === undefined) ? false : tipoArchivo.startsWith('image');
  }

}
