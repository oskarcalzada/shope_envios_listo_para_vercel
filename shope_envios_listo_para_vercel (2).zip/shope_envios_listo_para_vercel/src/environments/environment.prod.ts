export const environment = {
  production: true,
  urlBack: 'https://app.shopeenvios.com',
};
